import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, ScatterChart, Scatter, ZAxis, Legend, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts";

// ============================================================
// CIPHER - Event Revenue Intelligence Platform (v2)
// Each module has a distinct, purpose-built layout
// ============================================================

// --- BRAND ---
const C = {
  ink: "#1A1A1A", inkLight: "#2D2A2E", inkMid: "#3D3A3E",
  coral: "#CC6B85", coralHover: "#B85C75", coralSoft: "rgba(204,107,133,0.07)",
  navy: "#252336", navyLight: "#342F48", navySoft: "rgba(37,35,54,0.06)",
  rose: "#E4ADBA", roseDeep: "#D690A0", roseSoft: "rgba(228,173,186,0.12)",
  blush: "#F0D4DC", blushLight: "#F8F7F8",
  petal: "#FAFAF8", white: "#FFFFFF",
  warmGray: "#64636A", warmGrayLight: "#95949A",
  border: "#E6E5E8", borderLight: "#F0EFF2",
  green: "#2D8A56", greenSoft: "rgba(45,138,86,0.07)",
  amber: "#9A7B20", amberSoft: "rgba(200,150,50,0.07)",
};
const CHART_COLORS = [C.coral, C.navy, C.rose, C.navyLight, C.blush, "#8A8990", C.roseDeep];

// --- SEED DATA (same core data, enhanced) ---
const EVENTS = [
  { id:"ev1", name:"HIMSS 2025", type:"Conference", location:"Orlando, FL", date:"2025-03-10", status:"Completed", spend:185000, meetings:47, accounts:32, pipeInfluenced:2800000, pipeSourced:920000, oppsAccelerated:8, revenue:1450000, roi:87, region:"Southeast", format:"Sponsored", quarter:"Q1", notes:"Strongest healthcare event. Key executive meetings secured with 4 enterprise targets. Booth traffic exceeded expectations by 40%.", rec:"Renew Platinum sponsorship. Secure larger booth space and add a speaking session for thought leadership.", trend:[30,42,55,68,75,82,87] },
  { id:"ev2", name:"HLTH 2025", type:"Conference", location:"Las Vegas, NV", date:"2025-10-20", status:"Planned", spend:142000, meetings:38, accounts:28, pipeInfluenced:1950000, pipeSourced:680000, oppsAccelerated:5, revenue:890000, roi:72, region:"West", format:"Sponsored", quarter:"Q4", notes:"Growing conference with strong digital health presence.", rec:"Maintain sponsorship. Focus pre-event outreach on target accounts.", trend:[20,28,35,42,50,60,72] },
  { id:"ev3", name:"RSAC 2025", type:"Conference", location:"San Francisco, CA", date:"2025-04-28", status:"Completed", spend:210000, meetings:52, accounts:41, pipeInfluenced:3400000, pipeSourced:1200000, oppsAccelerated:12, revenue:2100000, roi:94, region:"West", format:"Sponsored", quarter:"Q2", notes:"Top-performing event of the year. CISO-level meetings with 6 Fortune 500 targets.", rec:"Increase investment. Add executive dinner and CISO roundtable.", trend:[40,52,60,72,80,88,94] },
  { id:"ev4", name:"Dreamforce", type:"Conference", location:"San Francisco, CA", date:"2025-09-16", status:"Completed", spend:175000, meetings:44, accounts:35, pipeInfluenced:2200000, pipeSourced:750000, oppsAccelerated:7, revenue:1100000, roi:78, region:"West", format:"Sponsored", quarter:"Q3", notes:"Broad audience but less targeted than vertical conferences.", rec:"Reduce sponsorship tier. Focus on hosted meetings.", trend:[25,35,45,55,62,70,78] },
  { id:"ev5", name:"Executive Dinner - NYC", type:"Hosted Dinner", location:"New York, NY", date:"2025-05-15", status:"Completed", spend:28000, meetings:12, accounts:12, pipeInfluenced:1800000, pipeSourced:520000, oppsAccelerated:4, revenue:780000, roi:96, region:"Northeast", format:"Hosted", quarter:"Q2", notes:"Highest ROI event. Intimate format drove deep executive conversations.", rec:"Replicate format quarterly. Target different Tier 1 accounts each time.", trend:[60,70,78,85,90,93,96] },
  { id:"ev6", name:"ASU+GSV Summit", type:"Summit", location:"San Diego, CA", date:"2025-04-06", status:"Completed", spend:95000, meetings:29, accounts:22, pipeInfluenced:1400000, pipeSourced:480000, oppsAccelerated:3, revenue:620000, roi:68, region:"West", format:"Attended", quarter:"Q2", notes:"EdTech-focused. Good for K-12 and higher-ed segments.", rec:"Attend but reduce sponsorship. Focus on targeted side meetings.", trend:[18,25,32,40,48,58,68] },
  { id:"ev7", name:"ViVE 2025", type:"Conference", location:"Nashville, TN", date:"2025-02-16", status:"Completed", spend:110000, meetings:34, accounts:26, pipeInfluenced:1650000, pipeSourced:590000, oppsAccelerated:5, revenue:720000, roi:74, region:"Southeast", format:"Sponsored", quarter:"Q1", notes:"Emerging healthcare innovation event.", rec:"Increase presence. Growing fast and competitor presence was light.", trend:[22,30,38,48,56,65,74] },
  { id:"ev8", name:"CIO Roundtable - Chicago", type:"Hosted Dinner", location:"Chicago, IL", date:"2025-06-12", status:"Completed", spend:18000, meetings:8, accounts:8, pipeInfluenced:950000, pipeSourced:320000, oppsAccelerated:3, revenue:410000, roi:91, region:"Midwest", format:"Hosted", quarter:"Q2", notes:"Small but mighty. Every attendee was a decision-maker.", rec:"Run monthly in different metro areas. Low cost, high impact.", trend:[50,60,68,75,82,87,91] },
  { id:"ev9", name:"Customer Advisory Board", type:"CAB", location:"Austin, TX", date:"2025-07-22", status:"Completed", spend:45000, meetings:15, accounts:15, pipeInfluenced:1100000, pipeSourced:0, oppsAccelerated:6, revenue:890000, roi:82, region:"South", format:"Hosted", quarter:"Q3", notes:"Renewal and expansion focused. No new sourced pipeline but significant acceleration.", rec:"Continue bi-annually. Add product roadmap feedback session.", trend:[30,40,50,58,65,74,82] },
];

const ACCOUNTS = [
  { id:"acc1", name:"Meridian Health Systems", industry:"Healthcare", segment:"Enterprise", arr:"$1M–$5M", owner:"Sarah Chen", target:true, tier:"Tier 1", events:["ev1","ev3","ev5"], meetings:8, stage:"Accelerated", competitor:"Optum", notes:"Strong executive champion. CFO attended NYC dinner.", health:92 },
  { id:"acc2", name:"Apex Financial Group", industry:"Financial Services", segment:"Enterprise", arr:"$500K–$1M", owner:"Marcus Rivera", target:true, tier:"Tier 1", events:["ev3","ev4"], meetings:5, stage:"Engaged", competitor:"Palo Alto Networks", notes:"CISO evaluating platform. Competitive displacement opportunity.", health:68 },
  { id:"acc3", name:"NovaTech Solutions", industry:"Technology", segment:"Mid-Market", arr:"$100K–$500K", owner:"Jordan Park", target:true, tier:"Tier 2", events:["ev1","ev7"], meetings:4, stage:"Pipeline", competitor:"None", notes:"Interested in analytics module. Budget approval expected Q3.", health:55 },
  { id:"acc4", name:"Cascade Learning", industry:"Education", segment:"Mid-Market", arr:"$100K–$500K", owner:"Sarah Chen", target:true, tier:"Tier 2", events:["ev6"], meetings:3, stage:"Early Stage", competitor:"Canvas", notes:"K-12 district with 45K students.", health:35 },
  { id:"acc5", name:"Summit Healthcare Partners", industry:"Healthcare", segment:"Enterprise", arr:"$1M–$5M", owner:"Marcus Rivera", target:true, tier:"Tier 1", events:["ev1","ev5","ev8","ev9"], meetings:11, stage:"Closing", competitor:"Epic", notes:"In final negotiations. CAB attendance strengthened relationship.", health:96 },
  { id:"acc6", name:"Ironclad Security", industry:"Cybersecurity", segment:"Enterprise", arr:"$500K–$1M", owner:"Jordan Park", target:true, tier:"Tier 1", events:["ev3"], meetings:6, stage:"Accelerated", competitor:"CrowdStrike", notes:"Fast-moving evaluation. RSAC meetings were pivotal.", health:78 },
  { id:"acc7", name:"Pacific Mutual Insurance", industry:"Insurance", segment:"Enterprise", arr:"$500K–$1M", owner:"Sarah Chen", target:false, tier:"Tier 3", events:["ev4"], meetings:2, stage:"Stalled", competitor:"Guidewire", notes:"Interest but budget constraints.", health:22 },
  { id:"acc8", name:"BrightPath Education", industry:"Education", segment:"Mid-Market", arr:"$100K–$500K", owner:"Marcus Rivera", target:true, tier:"Tier 2", events:["ev6","ev9"], meetings:4, stage:"Pipeline", competitor:"Blackboard", notes:"Superintendent is a champion.", health:52 },
  { id:"acc9", name:"Vanguard Medical", industry:"Healthcare", segment:"Mid-Market", arr:"$100K–$500K", owner:"Jordan Park", target:true, tier:"Tier 2", events:["ev7"], meetings:2, stage:"Early Stage", competitor:"None", notes:"Newly engaged at ViVE. High potential.", health:30 },
  { id:"acc10", name:"Atlas Cloud Infrastructure", industry:"Technology", segment:"Enterprise", arr:"$1M–$5M", owner:"Sarah Chen", target:true, tier:"Tier 1", events:["ev3","ev4","ev5"], meetings:9, stage:"Accelerated", competitor:"AWS", notes:"CTO and VP Eng both engaged. Multi-threaded opportunity.", health:85 },
];

const OPPORTUNITIES = [
  { id:"opp1", name:"Meridian - Platform License", account:"Meridian Health Systems", accId:"acc1", stage:"Negotiation", amount:1200000, owner:"Sarah Chen", source:"Event Sourced", sourceEvent:"HIMSS 2025", evId:"ev1", accel:"Accelerated", close:"2025-08-30", confidence:85, events:["ev1","ev3","ev5"], notes:"First engaged at HIMSS. Executive dinner accelerated to negotiation." },
  { id:"opp2", name:"Apex - Security Suite", account:"Apex Financial Group", accId:"acc2", stage:"Evaluation", amount:750000, owner:"Marcus Rivera", source:"Event Sourced", sourceEvent:"RSAC 2025", evId:"ev3", accel:"On Track", close:"2025-10-15", confidence:60, events:["ev3","ev4"], notes:"CISO met at RSAC. Running competitive eval." },
  { id:"opp3", name:"NovaTech - Analytics", account:"NovaTech Solutions", accId:"acc3", stage:"Discovery", amount:280000, owner:"Jordan Park", source:"Event Sourced", sourceEvent:"HIMSS 2025", evId:"ev1", accel:"Early", close:"2025-12-01", confidence:35, events:["ev1","ev7"], notes:"Interested in analytics. Budget pending." },
  { id:"opp4", name:"Summit - Enterprise Expansion", account:"Summit Healthcare Partners", accId:"acc5", stage:"Closing", amount:2100000, owner:"Marcus Rivera", source:"Existing Account", sourceEvent:"Exec Dinner NYC", evId:"ev5", accel:"Accelerated", close:"2025-07-31", confidence:92, events:["ev1","ev5","ev8","ev9"], notes:"Major expansion. CAB sealed the deal." },
  { id:"opp5", name:"Ironclad - Platform Deal", account:"Ironclad Security", accId:"acc6", stage:"Proposal", amount:680000, owner:"Jordan Park", source:"Event Sourced", sourceEvent:"RSAC 2025", evId:"ev3", accel:"Accelerated", close:"2025-09-15", confidence:70, events:["ev3"], notes:"Fast-moving. RSAC was the catalyst." },
  { id:"opp6", name:"Pacific Mutual - Platform", account:"Pacific Mutual Insurance", accId:"acc7", stage:"Stalled", amount:520000, owner:"Sarah Chen", source:"Event Influenced", sourceEvent:"Dreamforce", evId:"ev4", accel:"Stalled", close:"2026-02-28", confidence:20, events:["ev4"], notes:"Budget constraints. Re-engage after fiscal year." },
  { id:"opp7", name:"Atlas Cloud - Infra Suite", account:"Atlas Cloud Infrastructure", accId:"acc10", stage:"Negotiation", amount:1800000, owner:"Sarah Chen", source:"Event Influenced", sourceEvent:"RSAC 2025", evId:"ev3", accel:"Accelerated", close:"2025-08-15", confidence:80, events:["ev3","ev4","ev5"], notes:"Multi-threaded. CTO and VP Eng championing." },
  { id:"opp8", name:"BrightPath - Education Suite", account:"BrightPath Education", accId:"acc8", stage:"Discovery", amount:190000, owner:"Marcus Rivera", source:"Event Sourced", sourceEvent:"ASU+GSV", evId:"ev6", accel:"Early", close:"2025-11-30", confidence:40, events:["ev6","ev9"], notes:"Superintendent champion. Board approval needed." },
];

const MEETINGS = [
  { id:"m1", contact:"Dr. Lisa Chen", role:"CFO", company:"Meridian Health Systems", accId:"acc1", event:"HIMSS 2025", evId:"ev1", date:"2025-03-11", owner:"Sarah Chen", type:"Executive Briefing", priority:"Critical", outcome:"Follow-up scheduled", notes:"Deep dive on platform ROI. CFO impressed with analytics.", next:"Send custom ROI analysis", signals:"Asked about implementation timeline", objections:"Epic EHR integration concerns", competitor:"Optum", summary:"Highly productive. CFO is economic buyer.", urgency:"High", status:"Completed", sentiment:92 },
  { id:"m2", contact:"James Morrison", role:"CISO", company:"Apex Financial Group", accId:"acc2", event:"RSAC 2025", evId:"ev3", date:"2025-04-29", owner:"Marcus Rivera", type:"Discovery", priority:"High", outcome:"Demo requested", notes:"CISO actively evaluating. Current stack outdated.", next:"Schedule technical demo", signals:"Budget allocated for Q3. Board pressure to modernize.", objections:"Migration complexity", competitor:"Palo Alto Networks", summary:"Strong discovery. Clear pain points and budget authority.", urgency:"High", status:"In Progress", sentiment:78 },
  { id:"m3", contact:"Maria Santos", role:"VP Engineering", company:"Atlas Cloud Infrastructure", accId:"acc10", event:"RSAC 2025", evId:"ev3", date:"2025-04-30", owner:"Sarah Chen", type:"Technical Deep Dive", priority:"High", outcome:"POC approved", notes:"VP Eng wants proof of concept. Strong technical fit.", next:"Set up POC environment by May 15", signals:"Team already tested API docs. Very engaged.", objections:"Needs to prove performance at scale", competitor:"AWS (incumbent)", summary:"Technical validation. VP Eng is strong champion.", urgency:"Medium", status:"Completed", sentiment:85 },
  { id:"m4", contact:"Robert Kim", role:"CEO", company:"Summit Healthcare Partners", accId:"acc5", event:"Executive Dinner - NYC", evId:"ev5", date:"2025-05-15", owner:"Marcus Rivera", type:"Executive Dinner", priority:"Critical", outcome:"Verbal commitment", notes:"CEO committed to expanding partnership. Finalize by Q3 end.", next:"Send expansion proposal with pricing tiers", signals:"Unprompted: increasing budget allocation for our platform", objections:"None - relationship strong", competitor:"None", summary:"Pivotal dinner. CEO verbal commit to 3-year expansion.", urgency:"Critical", status:"Completed", sentiment:98 },
  { id:"m5", contact:"Dr. Amy Wu", role:"CIO", company:"Summit Healthcare Partners", accId:"acc5", event:"CIO Roundtable - Chicago", evId:"ev8", date:"2025-06-12", owner:"Marcus Rivera", type:"Roundtable", priority:"High", outcome:"Advocacy confirmed", notes:"CIO spoke positively to other attendees. Strongest advocate.", next:"Include in case study program", signals:"Volunteered as reference customer", objections:"None", competitor:"Displaced competitor last year", summary:"CIO is brand advocate. Summit is flagship.", urgency:"Medium", status:"Completed", sentiment:95 },
  { id:"m6", contact:"Tom Hartley", role:"Superintendent", company:"BrightPath Education", accId:"acc8", event:"ASU+GSV Summit", evId:"ev6", date:"2025-04-07", owner:"Marcus Rivera", type:"Discovery", priority:"Medium", outcome:"Interest confirmed", notes:"Looking for unified platform. Currently using 4 tools.", next:"Send district-level case studies", signals:"Frustrated with vendor fragmentation", objections:"Board approval - timeline is Q4", competitor:"Blackboard (unhappy)", summary:"Good discovery. Longer cycle due to procurement.", urgency:"Low", status:"In Progress", sentiment:62 },
  { id:"m7", contact:"Sarah Blackwell", role:"CTO", company:"Atlas Cloud Infrastructure", accId:"acc10", event:"Executive Dinner - NYC", evId:"ev5", date:"2025-05-15", owner:"Sarah Chen", type:"Executive Dinner", priority:"Critical", outcome:"Multi-year discussion", notes:"CTO discussed 3-year infrastructure roadmap alignment.", next:"Prepare multi-year proposal", signals:"Asked about enterprise licensing and volume discounts", objections:"Long-term roadmap alignment concerns", competitor:"AWS contract up for renewal", summary:"Strategic dinner. CTO sees us as long-term partner.", urgency:"High", status:"In Progress", sentiment:88 },
  { id:"m8", contact:"Elena Volkov", role:"VP Product", company:"Ironclad Security", accId:"acc6", event:"RSAC 2025", evId:"ev3", date:"2025-04-29", owner:"Jordan Park", type:"Product Demo", priority:"High", outcome:"Trial approved", notes:"VP Product impressed with threat detection. Wants 30-day trial.", next:"Provision trial environment", signals:"Asked about API docs and custom integrations", objections:"CrowdStrike contract through Q4", competitor:"CrowdStrike (gaps in cloud)", summary:"Strong demo. Trial will be key differentiator.", urgency:"High", status:"Completed", sentiment:82 },
];

const COMPETITORS = [
  { id:"c1", name:"Optum Analytics", events:["ev1","ev7"], booth:true, talks:2, theme:"AI healthcare insights", announce:"Predictive analytics for hospitals", traffic:"High", threat:"High", notes:"Aggressive at HIMSS. Targeting same enterprise accounts.", color:"#E85D3A" },
  { id:"c2", name:"Palo Alto Networks", events:["ev3"], booth:true, talks:3, theme:"Zero trust, cloud-native security", announce:"Cortex XSIAM 3.0", traffic:"Very High", threat:"Critical", notes:"Dominant RSAC presence. Running competitive displacement campaigns.", color:"#D42F2F" },
  { id:"c3", name:"CrowdStrike", events:["ev3"], booth:true, talks:4, theme:"Endpoint protection, managed detection", announce:"Charlotte AI expansion", traffic:"Very High", threat:"High", notes:"Strong but less aggressive on competitive targeting. Focus on expansion.", color:"#E86830" },
  { id:"c4", name:"Canvas (Instructure)", events:["ev6"], booth:true, talks:1, theme:"Unified learning, AI grading", announce:"Canvas AI Studio", traffic:"Medium", threat:"Medium", notes:"Established EdTech. Less innovative but strong install base.", color:"#C09840" },
  { id:"c5", name:"Blackboard", events:["ev6"], booth:true, talks:0, theme:"Enterprise learning management", announce:"None significant", traffic:"Low", threat:"Low", notes:"Declining. Multiple attendees mentioned switching.", color:"#888" },
];

const INSIGHTS = [
  { id:"i1", type:"performance", title:"RSAC delivers 3.2x more pipeline than average", body:"$3.4M influenced vs $1.8M average. Increase RSAC investment for next year.", priority:"high", metric:"$3.4M", metricLabel:"Pipeline", delta:"+62%" },
  { id:"i2", type:"efficiency", title:"Hosted dinners: 4x ROI efficiency of conferences", body:"93.5 avg ROI at $23K vs conferences at 79.8 avg ROI at $153K. Scale intimate formats.", priority:"high", metric:"93.5", metricLabel:"Avg ROI", delta:"+17%" },
  { id:"i3", type:"trend", title:"Cost per meeting dropped 12% QoQ", body:"Q2 averaged $2,847/meeting vs Q1's $3,235. Pre-event outreach strategy is working.", priority:"medium", metric:"$2,847", metricLabel:"Per Meeting", delta:"-12%" },
  { id:"i4", type:"alert", title:"Palo Alto aggressively targeting 3 pipeline accounts", body:"Competitive displacement campaigns observed at RSAC. Brief sales team immediately.", priority:"critical", metric:"3", metricLabel:"At-Risk Accounts", delta:"Urgent" },
  { id:"i5", type:"trend", title:"Healthcare events in H1 = strongest pipeline", body:"HIMSS + ViVE combined $4.45M influenced. Concentrate healthcare budget in H1.", priority:"medium", metric:"$4.45M", metricLabel:"Combined", delta:"+28%" },
  { id:"i6", type:"efficiency", title:"CABs accelerate but don't source", body:"Customer Advisory Board: $0 sourced but 6 opps accelerated. Use strategically for negotiation-stage deals.", priority:"medium", metric:"6", metricLabel:"Opps Accelerated", delta:"100%" },
];

// --- UTILS ---
const fmt = n => { if (n >= 1e6) return `$${(n/1e6).toFixed(1)}M`; if (n >= 1e3) return `$${(n/1e3).toFixed(0)}K`; return `$${n}`; };
const fmtN = n => { if (n >= 1e6) return `${(n/1e6).toFixed(1)}M`; if (n >= 1e3) return `${(n/1e3).toFixed(0)}K`; return `${n}`; };
const totals = {
  spend: EVENTS.reduce((s,e)=>s+e.spend,0),
  meetings: EVENTS.reduce((s,e)=>s+e.meetings,0),
  accounts: EVENTS.reduce((s,e)=>s+e.accounts,0),
  pipeInf: EVENTS.reduce((s,e)=>s+e.pipeInfluenced,0),
  pipeSrc: EVENTS.reduce((s,e)=>s+e.pipeSourced,0),
  oppsAcc: EVENTS.reduce((s,e)=>s+e.oppsAccelerated,0),
  revenue: EVENTS.reduce((s,e)=>s+e.revenue,0),
};

// --- SVG ICON SYSTEM ---
const Icon = ({name, size=16, color="currentColor"}) => {
  const icons = {
    dashboard: <><rect x="3" y="3" width="7" height="7" rx="1.5" fill={color} opacity=".8"/><rect x="12" y="3" width="7" height="4" rx="1.5" fill={color} opacity=".5"/><rect x="3" y="12" width="7" height="4" rx="1.5" fill={color} opacity=".5"/><rect x="12" y="9" width="7" height="7" rx="1.5" fill={color} opacity=".8"/></>,
    events: <><rect x="4" y="5" width="14" height="13" rx="2" stroke={color} strokeWidth="1.8" fill="none"/><path d="M4 10h14" stroke={color} strokeWidth="1.5"/><path d="M8 3v4M14 3v4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/></>,
    accounts: <><circle cx="11" cy="8" r="3.5" stroke={color} strokeWidth="1.8" fill="none"/><path d="M4 19c0-3.5 3.1-6.5 7-6.5s7 3 7 6.5" stroke={color} strokeWidth="1.8" fill="none" strokeLinecap="round"/></>,
    opportunities: <><path d="M11 3l2.5 5h5.5l-4.5 3.5 1.5 5.5-5-3.5-5 3.5 1.5-5.5L3 8h5.5z" stroke={color} strokeWidth="1.7" fill="none" strokeLinejoin="round"/></>,
    meetings: <><rect x="3" y="6" width="16" height="12" rx="2" stroke={color} strokeWidth="1.8" fill="none"/><path d="M3 10h16" stroke={color} strokeWidth="1.3"/><circle cx="8" cy="14" r="1.2" fill={color}/><circle cx="14" cy="14" r="1.2" fill={color}/></>,
    competitors: <><path d="M11 4v14M4 11h14" stroke={color} strokeWidth="1.8" strokeLinecap="round"/><circle cx="11" cy="11" r="7" stroke={color} strokeWidth="1.8" fill="none"/></>,
    reports: <><rect x="4" y="3" width="14" height="16" rx="2" stroke={color} strokeWidth="1.8" fill="none"/><path d="M8 8h6M8 11h6M8 14h3" stroke={color} strokeWidth="1.5" strokeLinecap="round"/></>,
    insights: <><path d="M11 4a7 7 0 0 1 4.5 12.4L11 20l-4.5-3.6A7 7 0 0 1 11 4z" stroke={color} strokeWidth="1.8" fill="none"/><circle cx="11" cy="10.5" r="2" fill={color} opacity=".6"/></>,
    settings: <><circle cx="11" cy="11" r="3" stroke={color} strokeWidth="1.8" fill="none"/><path d="M11 2v2.5M11 17.5v2.5M2 11h2.5M17.5 11h2.5M4.9 4.9l1.8 1.8M15.3 15.3l1.8 1.8M4.9 17.1l1.8-1.8M15.3 6.7l1.8-1.8" stroke={color} strokeWidth="1.5" strokeLinecap="round"/></>,
    search: <><circle cx="10" cy="10" r="6" stroke={color} strokeWidth="1.8" fill="none"/><path d="M14.5 14.5L19 19" stroke={color} strokeWidth="1.8" strokeLinecap="round"/></>,
    globe: <><circle cx="11" cy="11" r="8" stroke={color} strokeWidth="1.7" fill="none"/><path d="M3 11h16M11 3c-2 2.5-3 5-3 8s1 5.5 3 8c2-2.5 3-5 3-8s-1-5.5-3-8" stroke={color} strokeWidth="1.3" fill="none"/></>,
    pin: <><path d="M11 2C7.7 2 5 4.7 5 8c0 4.5 6 11 6 11s6-6.5 6-11c0-3.3-2.7-6-6-6z" stroke={color} strokeWidth="1.7" fill="none"/><circle cx="11" cy="8" r="2" fill={color} opacity=".6"/></>,
    calendar: <><rect x="4" y="5" width="14" height="13" rx="2" stroke={color} strokeWidth="1.7" fill="none"/><path d="M4 9.5h14M8 3v4M14 3v4" stroke={color} strokeWidth="1.5" strokeLinecap="round"/></>,
    performance: <><path d="M4 17l4-5 3 2.5 5.5-8" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/><circle cx="17" cy="6" r="2" fill={color} opacity=".6"/></>,
    efficiency: <><path d="M11 3l1.8 5.5h5.8l-4.7 3.4 1.8 5.5L11 14l-4.7 3.4 1.8-5.5L3.4 8.5h5.8z" fill={color} opacity=".15" stroke={color} strokeWidth="1.5"/></>,
    trend: <><path d="M4 14l4-3 4 2 5-7" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/><path d="M14 6h4v4" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none"/></>,
    alert: <><path d="M11 4L3 18h16L11 4z" stroke={color} strokeWidth="1.8" fill="none" strokeLinejoin="round"/><path d="M11 10v3" stroke={color} strokeWidth="2" strokeLinecap="round"/><circle cx="11" cy="15.5" r="0.8" fill={color}/></>,
    calculator: <><rect x="4" y="3" width="14" height="16" rx="2" stroke={color} strokeWidth="1.8" fill="none"/><path d="M7 7h8" stroke={color} strokeWidth="1.5" strokeLinecap="round"/><circle cx="8" cy="11" r=".8" fill={color}/><circle cx="11" cy="11" r=".8" fill={color}/><circle cx="14" cy="11" r=".8" fill={color}/><circle cx="8" cy="14.5" r=".8" fill={color}/><circle cx="11" cy="14.5" r=".8" fill={color}/><circle cx="14" cy="14.5" r=".8" fill={color}/></>,
    compare: <><rect x="3" y="5" width="7" height="12" rx="1.5" stroke={color} strokeWidth="1.7" fill="none"/><rect x="12" y="5" width="7" height="12" rx="1.5" stroke={color} strokeWidth="1.7" fill="none"/><path d="M6.5 9h-1M6.5 12h-1M15.5 9h-1M15.5 12h-1" stroke={color} strokeWidth="1.3" strokeLinecap="round"/></>,
    journey: <><circle cx="4" cy="11" r="2" stroke={color} strokeWidth="1.5" fill="none"/><circle cx="18" cy="11" r="2" stroke={color} strokeWidth="1.5" fill="none"/><path d="M6 11h2.5c1.5 0 2-3 4-3s2.5 3 4 3H19" stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round"/></>,
    budget: <><circle cx="11" cy="11" r="8" stroke={color} strokeWidth="1.7" fill="none"/><path d="M11 7v8M8.5 9.2c0-1.2 1.1-2.2 2.5-2.2s2.5.8 2.5 2c0 1.5-2.5 1.5-2.5 3 0 1.2 1.1 2 2.5 2s2.5-1 2.5-2.2" stroke={color} strokeWidth="1.5" strokeLinecap="round" fill="none"/></>,
    sword: <><path d="M5 17L15 7M15 7l2-4 2 2-4 2M5 17l-2 2 2 2M8 15l-1.5 1.5" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg" style={{flexShrink:0}}>{icons[name]||null}</svg>;
};

const InsightIcon = ({type, size=28}) => {
  const colors = {performance:C.coral, efficiency:C.amber, trend:C.roseDeep, alert:C.coral};
  const col = colors[type]||C.warmGray;
  return <div style={{width:size,height:size,borderRadius:6,background:`${col}15`,display:"flex",alignItems:"center",justifyContent:"center"}}><Icon name={type} size={size*0.6} color={col}/></div>;
};
const css = `
@import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Outfit:wght@400;500;600;700;800&display=swap');

*{margin:0;padding:0;box-sizing:border-box}
:root{
  --ink:${C.ink};--ink-light:${C.inkLight};--coral:${C.coral};--coral-h:${C.coralHover};
  --rose:${C.rose};--rose-deep:${C.roseDeep};--blush:${C.blush};--blush-l:${C.blushLight};
  --petal:${C.petal};--wg:${C.warmGray};--wgl:${C.warmGrayLight};
  --bdr:${C.border};--bdr-l:${C.borderLight};--green:${C.green};--amber:${C.amber};
  --serif:'Instrument Serif',Georgia,serif;
  --sans:'Outfit',-apple-system,sans-serif;
  --r:10px;--r2:14px;--r3:18px;
  --sh:0 1px 2px rgba(26,26,26,0.03),0 1px 3px rgba(26,26,26,0.02);
  --sh2:0 2px 8px rgba(26,26,26,0.04),0 8px 24px rgba(26,26,26,0.04);
  --sh3:0 8px 32px rgba(26,26,26,0.06),0 2px 8px rgba(26,26,26,0.03);
}
body{font-family:var(--sans);color:var(--ink);background:var(--petal);-webkit-font-smoothing:antialiased;font-weight:500}

/* ---- Layout ---- */
.app{display:flex;min-height:100vh;background:linear-gradient(155deg,#FAF9F7 0%,#F4F2EF 30%,#F7F5F3 60%,#FAFAF8 100%);position:relative}
.app::before{content:'';position:fixed;inset:0;background:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.035'/%3E%3C/svg%3E");pointer-events:none;z-index:0}
.app>*{position:relative;z-index:1}
.side{width:224px;min-width:224px;background:linear-gradient(180deg,#FEFEFE 0%,#FAF9F7 100%);position:fixed;top:0;left:0;bottom:0;z-index:50;display:flex;flex-direction:column;border-right:1px solid var(--bdr-l)}
.side-brand{padding:22px 20px 18px;border-bottom:1px solid var(--bdr-l)}
.side-brand h1{font-family:var(--serif);font-size:24px;color:var(--ink);letter-spacing:-.3px}
.side-brand h1 i{color:var(--coral);font-style:italic}
.side-brand p{font-size:9.5px;color:var(--wgl);text-transform:uppercase;letter-spacing:1.5px;margin-top:3px}
.side-nav{flex:1;padding:14px 10px;overflow-y:auto}
.side-lbl{font-size:9px;text-transform:uppercase;letter-spacing:1.5px;color:var(--wgl);padding:14px 10px 5px;font-weight:600}
.side-item{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;font-size:13px;font-weight:500;color:var(--wg);cursor:pointer;transition:all .18s;margin-bottom:1px;position:relative}
.side-item:hover{color:var(--ink);background:var(--petal)}
.side-item.on{color:var(--coral);background:rgba(204,107,133,.05);font-weight:600}
.side-item.on::before{content:'';position:absolute;left:0;top:50%;transform:translateY(-50%);width:3px;height:18px;background:var(--coral);border-radius:0 3px 3px 0;box-shadow:0 0 8px rgba(204,107,133,.3)}
.side-item.on .si{color:var(--coral)}
.si{width:16px;text-align:center;font-size:14px;flex-shrink:0;display:flex;align-items:center;justify-content:center}
.side-foot{padding:14px 16px;border-top:1px solid var(--bdr-l);display:flex;align-items:center;gap:10px}
.side-av{width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,var(--coral),var(--rose-deep));display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff}
.side-fn{font-size:12.5px;font-weight:600;color:var(--ink)}
.side-fr{font-size:10.5px;color:var(--wgl)}

.main{flex:1;margin-left:224px;min-height:100vh}
.topbar{height:56px;background:rgba(255,255,255,.85);backdrop-filter:blur(24px) saturate(1.5);border-bottom:1px solid var(--bdr-l);display:flex;align-items:center;justify-content:space-between;padding:0 32px;position:sticky;top:0;z-index:40}
.topbar-t{font-family:var(--serif);font-size:18px;font-weight:400;color:var(--ink);letter-spacing:-.2px}
.topbar-r{display:flex;gap:8px;align-items:center}
.searchbox{display:flex;align-items:center;gap:7px;background:var(--petal);border:1px solid var(--bdr);border-radius:8px;padding:6px 12px;font-size:12px;color:var(--wgl);cursor:pointer;min-width:200px;transition:all .18s}
.searchbox:hover{border-color:var(--rose);box-shadow:0 0 0 3px rgba(228,173,186,.1)}
.tbtn{padding:6px 14px;border-radius:8px;font-size:12px;font-weight:600;border:1px solid var(--bdr);background:#fff;cursor:pointer;font-family:var(--sans);transition:all .15s}
.tbtn:hover{border-color:var(--coral);color:var(--coral);box-shadow:0 0 0 3px rgba(204,107,133,.06)}
.tbtn:active{transform:scale(.97)}
.tbtn-p{background:linear-gradient(135deg,var(--coral),var(--coral-h));color:#fff;border-color:transparent;box-shadow:0 2px 8px rgba(204,107,133,.2)}
.tbtn-p:hover{background:linear-gradient(135deg,var(--coral-h),#9E4A62);border-color:transparent;color:#fff;box-shadow:0 4px 12px rgba(204,107,133,.3)}

.pg{padding:28px 32px 48px;max-width:1380px}
.pg-head{margin-bottom:22px}
.pg-head h2{font-family:var(--serif);font-size:32px;letter-spacing:-.5px;margin-bottom:3px;font-weight:400}
.pg-head p{font-size:14px;color:var(--wg);font-weight:400}

/* ---- Cards & Surfaces ---- */
.card{background:rgba(255,255,255,.92);backdrop-filter:blur(16px) saturate(1.3);border-radius:var(--r2);border:1px solid rgba(230,229,232,.3);transition:all .3s cubic-bezier(.22,.61,.36,1);box-shadow:0 1px 2px rgba(26,26,26,0.02),0 2px 6px rgba(26,26,26,0.02)}
.card:hover{box-shadow:0 4px 16px rgba(26,26,26,.05),0 1px 3px rgba(26,26,26,.02);border-color:rgba(204,107,133,.1)}
.card-p{padding:20px}

/* ---- Badges ---- */
.b{display:inline-flex;align-items:center;padding:2px 9px;border-radius:20px;font-size:10.5px;font-weight:700;letter-spacing:.15px;backdrop-filter:blur(4px)}
.b-coral{background:${C.coralSoft};color:var(--coral)}
.b-green{background:${C.greenSoft};color:var(--green)}
.b-amber{background:${C.amberSoft};color:var(--amber)}
.b-gray{background:rgba(107,96,96,.07);color:var(--wg)}
.b-rose{background:${C.roseSoft};color:var(--rose-deep)}
.b-ink{background:rgba(26,26,26,.06);color:var(--ink)}

/* ---- Sparkline (CSS) ---- */
.spark{display:flex;align-items:flex-end;gap:2px;height:28px}
.spark-bar{width:4px;border-radius:2px;background:var(--coral);opacity:.5;transition:all .2s}
.spark-bar:last-child{opacity:1}

/* ---- Score Ring ---- */
.ring-wrap{position:relative;width:56px;height:56px;flex-shrink:0}
.ring-val{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:700;font-family:var(--sans)}

/* ---- Scrollbar ---- */
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:3px}

/* ---- Back ---- */
.back{font-size:12px;color:var(--wg);cursor:pointer;display:flex;align-items:center;gap:4px;margin-bottom:14px;font-weight:500}
.back:hover{color:var(--coral)}

/* ---- Kanban ---- */
.kanban{display:flex;gap:16px;overflow-x:auto;padding-bottom:8px}
.kanban-col{min-width:260px;flex:1}
.kanban-col-head{font-size:11px;text-transform:uppercase;letter-spacing:.8px;font-weight:600;padding:0 4px 10px;display:flex;align-items:center;justify-content:space-between}
.kanban-col-head span{font-weight:400;color:var(--wgl)}
.kanban-card{background:rgba(255,255,255,.9);backdrop-filter:blur(6px);border:1px solid rgba(230,229,232,.4);border-radius:var(--r);padding:14px;margin-bottom:8px;cursor:pointer;transition:all .2s cubic-bezier(.22,.61,.36,1)}
.kanban-card:hover{box-shadow:0 6px 24px rgba(26,26,26,.08);border-color:rgba(204,107,133,.2);transform:translateY(-2px)}

/* ---- Pipeline Funnel ---- */
.funnel{display:flex;gap:2px;align-items:stretch;height:120px;margin-bottom:24px}
.funnel-stage{flex:1;border-radius:var(--r);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;transition:all .15s;position:relative}
.funnel-stage:hover{transform:translateY(-2px);box-shadow:var(--sh2)}
.funnel-val{font-size:22px;font-weight:700;color:#fff;font-family:var(--sans)}
.funnel-lbl{font-size:10px;color:rgba(255,255,255,.7);text-transform:uppercase;letter-spacing:.5px;margin-top:2px}
.funnel-amt{font-size:11px;color:rgba(255,255,255,.5);margin-top:4px}

/* ---- Timeline ---- */
.timeline{position:relative;padding-left:28px}
.timeline::before{content:'';position:absolute;left:9px;top:6px;bottom:6px;width:2px;background:var(--bdr)}
.tl-item{position:relative;padding:0 0 20px;cursor:pointer}
.tl-dot{position:absolute;left:-23px;top:4px;width:12px;height:12px;border-radius:50%;border:2px solid var(--bdr);background:#fff}
.tl-dot.critical{border-color:var(--coral);background:var(--coral)}
.tl-dot.high{border-color:var(--amber);background:var(--amber)}
.tl-dot.completed{border-color:var(--green);background:var(--green)}

/* ---- War Room ---- */
.threat-matrix{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:14px}
.threat-card{border-radius:var(--r2);border:1px solid rgba(230,229,232,.4);background:rgba(255,255,255,.9);backdrop-filter:blur(6px);overflow:hidden;transition:all .2s cubic-bezier(.22,.61,.36,1)}
.threat-card:hover{box-shadow:0 6px 24px rgba(26,26,26,.08);transform:translateY(-1px)}
.threat-card-top{padding:18px 20px;display:flex;justify-content:space-between;align-items:flex-start}
.threat-bar{height:3px;width:100%}
.threat-card-body{padding:0 20px 18px}
.threat-field{margin-bottom:8px}
.threat-field-l{font-size:9.5px;text-transform:uppercase;letter-spacing:.6px;color:var(--wgl);font-weight:600}
.threat-field-v{font-size:12.5px;line-height:1.5;margin-top:1px}

/* ---- Responsive ---- */
@media(max-width:900px){
  .side{display:none}.main{margin-left:0}
  .kanban{flex-direction:column}.kanban-col{min-width:auto}
  .funnel{flex-direction:column;height:auto}.funnel-stage{height:60px}
}

/* ---- Animations ---- */
@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes slideUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
@keyframes toastIn{from{opacity:0;transform:translateY(12px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes barGrow{from{width:0}to{width:var(--bar-w)}}
@keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
@keyframes glowPulse{0%,100%{box-shadow:0 0 0 0 rgba(204,107,133,0)}50%{box-shadow:0 0 24px 4px rgba(204,107,133,.12)}}
@keyframes scaleIn{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}
@keyframes slideRight{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}
@keyframes dotPulse{0%,100%{transform:scale(1);box-shadow:0 0 0 0 rgba(204,107,133,.3)}50%{transform:scale(1.15);box-shadow:0 0 12px 3px rgba(204,107,133,.15)}}
.fade-up{animation:fadeUp .5s cubic-bezier(.22,.61,.36,1) both}
.scale-in{animation:scaleIn .5s cubic-bezier(.22,.61,.36,1) both}
.slide-r{animation:slideRight .5s cubic-bezier(.22,.61,.36,1) both}
.d1{animation-delay:.05s}.d2{animation-delay:.1s}.d3{animation-delay:.16s}.d4{animation-delay:.22s}
.d5{animation-delay:.28s}.d6{animation-delay:.34s}.d7{animation-delay:.4s}.d8{animation-delay:.46s}
.bar-anim{animation:barGrow .8s cubic-bezier(.22,.61,.36,1) .3s both}
.glow{animation:glowPulse 3s ease-in-out infinite}
.shimmer-bg{background:linear-gradient(90deg,transparent 0%,rgba(204,107,133,.04) 50%,transparent 100%);background-size:200% 100%;animation:shimmer 3s ease-in-out infinite}
.hover-lift{transition:all .3s cubic-bezier(.22,.61,.36,1)}
.hover-lift:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(26,26,26,.08)}

/* ---- Modal ---- */
.modal-overlay{position:fixed;inset:0;background:rgba(13,11,14,.5);backdrop-filter:blur(8px) saturate(1.2);z-index:100;display:flex;align-items:center;justify-content:center;animation:fadeIn .15s ease}
.modal{background:rgba(255,255,255,.97);backdrop-filter:blur(12px);border-radius:var(--r3);width:520px;max-width:92vw;max-height:85vh;overflow-y:auto;box-shadow:0 24px 80px rgba(0,0,0,.18),0 0 0 1px rgba(230,229,232,.3);animation:slideUp .25s cubic-bezier(.22,.61,.36,1)}
.modal-lg{width:680px}
.modal-head{padding:20px 24px 16px;border-bottom:1px solid var(--bdr-l);display:flex;justify-content:space-between;align-items:center}
.modal-head h3{font-family:var(--serif);font-size:18px}
.modal-close{width:28px;height:28px;border-radius:6px;border:none;background:var(--petal);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--wg);transition:all .12s;font-family:var(--sans)}
.modal-close:hover{background:var(--bdr-l);color:var(--ink)}
.modal-body{padding:20px 24px}
.modal-foot{padding:14px 24px 20px;display:flex;justify-content:flex-end;gap:8px;border-top:1px solid var(--bdr-l)}
.form-group{margin-bottom:14px}
.form-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:var(--wgl);margin-bottom:5px;display:block}
.form-input{width:100%;padding:9px 12px;border:1px solid var(--bdr);border-radius:8px;font-size:13px;font-family:var(--sans);font-weight:500;outline:none;transition:border .12s;background:#fff}
.form-input:focus{border-color:var(--coral)}
.form-select{width:100%;padding:9px 12px;border:1px solid var(--bdr);border-radius:8px;font-size:13px;font-family:var(--sans);font-weight:500;outline:none;appearance:none;background:#fff url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%239A9090' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") right 12px center no-repeat;cursor:pointer}
.form-select:focus{border-color:var(--coral)}
.form-textarea{width:100%;padding:9px 12px;border:1px solid var(--bdr);border-radius:8px;font-size:13px;font-family:var(--sans);font-weight:500;outline:none;resize:vertical;min-height:72px;transition:border .12s}
.form-textarea:focus{border-color:var(--coral)}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.modal-btn{padding:8px 18px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--sans);transition:all .12s;border:none}
.modal-btn-p{background:var(--coral);color:#fff}
.modal-btn-p:hover{background:var(--coral-h)}
.modal-btn-s{background:var(--petal);color:var(--wg);border:1px solid var(--bdr)}
.modal-btn-s:hover{border-color:var(--coral);color:var(--coral)}

/* ---- Toast ---- */
.toast-container{position:fixed;bottom:24px;right:24px;z-index:200;display:flex;flex-direction:column;gap:8px}
.toast{padding:12px 18px;border-radius:10px;background:var(--ink);color:#fff;font-size:13px;font-weight:600;box-shadow:var(--sh3);animation:toastIn .25s ease;display:flex;align-items:center;gap:8px;max-width:360px}
.toast-success{background:var(--green)}
.toast-icon{width:18px;height:18px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;flex-shrink:0}

/* ---- Search Modal ---- */
.search-overlay{position:fixed;inset:0;background:rgba(26,26,26,.5);backdrop-filter:blur(6px);z-index:100;display:flex;align-items:flex-start;justify-content:center;padding-top:12vh;animation:fadeIn .12s ease}
.search-modal{background:#fff;border-radius:var(--r2);width:560px;max-width:92vw;box-shadow:var(--sh3);overflow:hidden;animation:slideUp .15s ease}
.search-input-wrap{display:flex;align-items:center;gap:10px;padding:16px 20px;border-bottom:1px solid var(--bdr-l)}
.search-input-wrap input{flex:1;border:none;outline:none;font-size:15px;font-family:var(--sans);font-weight:500;background:transparent}
.search-results{max-height:400px;overflow-y:auto}
.search-result{padding:12px 20px;cursor:pointer;display:flex;align-items:center;gap:12px;transition:background .1s}
.search-result:hover{background:var(--petal)}
.search-result-type{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:var(--wgl);min-width:56px}
.search-result-name{font-size:13.5px;font-weight:600}
.search-result-sub{font-size:11.5px;color:var(--wg);font-weight:500}
.search-empty{padding:32px 20px;text-align:center;color:var(--wgl);font-size:13px;font-weight:500}

/* ---- Note item ---- */
.note-item{padding:12px;background:var(--petal);border-radius:8px;margin-bottom:8px}
.note-item-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px}
.note-item-author{font-size:11px;font-weight:700;color:var(--ink)}
.note-item-time{font-size:10px;color:var(--wgl);font-weight:500}
.note-item-body{font-size:12.5px;color:var(--wg);line-height:1.5;font-weight:500}

/* ---- Action Bar ---- */
.action-bar{display:flex;gap:6px;margin-top:12px}
.action-btn{display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:7px;font-size:11.5px;font-weight:600;cursor:pointer;font-family:var(--sans);transition:all .12s;border:1px solid var(--bdr);background:#fff;color:var(--wg)}
.action-btn:hover{border-color:var(--coral);color:var(--coral);background:var(--petal)}

/* ---- Sync status ---- */
.sync-dot{width:8px;height:8px;border-radius:50%;display:inline-block}
.sync-dot-green{background:var(--green);box-shadow:0 0 6px rgba(45,138,86,.4)}
.sync-dot-amber{background:var(--amber);box-shadow:0 0 6px rgba(200,150,50,.4)}
.sync-dot-gray{background:var(--bdr)}

/* ---- Detail ---- */
.det-hero{background:linear-gradient(135deg,rgba(255,255,255,.96),rgba(250,249,247,.92));backdrop-filter:blur(16px);border-radius:var(--r3);padding:32px;border:1px solid rgba(230,229,232,.3);margin-bottom:22px;box-shadow:0 2px 12px rgba(26,26,26,.02),0 8px 32px rgba(26,26,26,.02)}
.det-hero h2{font-family:var(--serif);font-size:24px;margin-bottom:2px}
.det-meta{display:flex;gap:16px;margin-top:10px;flex-wrap:wrap;font-size:12.5px;color:var(--wg)}
.det-meta b{color:var(--ink);font-weight:600}
.det-grid{display:grid;grid-template-columns:5fr 3fr;gap:16px}
.det-section{background:#fff;border-radius:var(--r2);padding:22px;border:1px solid var(--bdr-l);margin-bottom:14px}
.det-section h3{font-size:14px;font-weight:700;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--bdr-l)}
.det-f{margin-bottom:12px}
.det-fl{font-size:9.5px;text-transform:uppercase;letter-spacing:.5px;color:var(--wgl);font-weight:700;margin-bottom:3px}
.det-fv{font-size:13px;line-height:1.55}
.attr-box{background:var(--blush-l);border-radius:var(--r);padding:16px;border:1px solid var(--blush);margin-top:12px}
.attr-box h4{font-size:12px;font-weight:600;margin-bottom:10px}
.attr-row{display:flex;gap:8px;margin-bottom:7px;font-size:12px}
.attr-type{font-weight:700;min-width:80px}
.attr-def{color:var(--wg);line-height:1.4}

/* ---- Landing ---- */
.land-hero{background:linear-gradient(160deg,#FAFAF8 0%,#F5F4F2 40%,#FFF 70%,#FAFAF8 100%);color:var(--ink);min-height:100vh;display:flex;flex-direction:column;position:relative;overflow:hidden}
.land-hero::before{content:'';position:absolute;top:-20%;right:-10%;width:700px;height:700px;border-radius:50%;background:radial-gradient(circle,rgba(204,107,133,.08) 0%,rgba(228,173,186,.04) 40%,transparent 70%);pointer-events:none;animation:orbFloat 12s ease-in-out infinite}
.land-hero::after{content:'';position:absolute;bottom:-30%;left:20%;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(240,239,242,.12) 0%,transparent 60%);pointer-events:none;animation:orbFloat 15s ease-in-out infinite reverse}
@keyframes orbFloat{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(20px,-30px) scale(1.05)}}
.land-nav{display:flex;align-items:center;justify-content:space-between;padding:20px 48px;position:relative;z-index:2}
.land-nav-b{font-family:var(--serif);font-size:22px;color:var(--ink);cursor:pointer}
.land-nav-b i{color:var(--coral);font-style:italic}
.land-nav-r{display:flex;gap:32px;align-items:center}
.land-nav-l{font-size:13px;color:var(--wg);cursor:pointer;transition:color .2s;font-weight:500;position:relative}
.land-nav-l:hover{color:var(--ink)}
.land-nav-l.active{color:var(--coral);font-weight:700}
.land-nav-l.active::after{content:'';position:absolute;bottom:-4px;left:0;right:0;height:1.5px;background:var(--coral)}
.land-hero-c{flex:1;display:flex;flex-direction:column;justify-content:center;padding:80px 48px;max-width:820px;position:relative;z-index:2}
.land-tag{font-size:10px;text-transform:uppercase;letter-spacing:3px;color:var(--coral);font-weight:700;margin-bottom:24px;display:flex;align-items:center;gap:10px}
.land-tag::before{content:'';width:24px;height:1.5px;background:var(--coral)}
.land-hero-c h1{font-family:var(--serif);font-size:62px;line-height:1.04;letter-spacing:-1.5px;margin-bottom:28px;color:var(--ink)}
.land-hero-c h1 i{color:var(--coral);font-style:italic}
.land-hero-c .sub{font-size:18px;color:var(--wg);line-height:1.65;margin-bottom:40px;max-width:580px;font-weight:400}
.land-ctas{display:flex;gap:12px;align-items:center}
.land-btn{padding:14px 28px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;transition:all .25s cubic-bezier(.22,.61,.36,1);font-family:var(--sans);border:none}
.land-btn-p{background:linear-gradient(135deg,var(--coral),var(--coral-h));color:#fff;box-shadow:0 4px 20px rgba(204,107,133,.25)}
.land-btn-p:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(204,107,133,.35)}
.land-btn-p:active{transform:translateY(0)}
.land-btn-s{background:#fff;color:var(--wg);border:1px solid var(--bdr)}
.land-btn-s:hover{border-color:var(--coral);color:var(--coral)}
.land-sec{padding:100px 48px;position:relative}
.land-sec h2{font-family:var(--serif);font-size:40px;text-align:center;margin-bottom:14px;letter-spacing:-.5px;color:var(--ink)}
.land-sec .sec-sub{font-size:16px;color:var(--wg);text-align:center;max-width:540px;margin:0 auto 56px;line-height:1.65;font-weight:400}
.land-sec-dark{background:linear-gradient(160deg,#252336 0%,#342F48 100%);color:#fff;position:relative;overflow:hidden;border-radius:24px;margin:0 48px;max-width:1100px;margin-left:auto;margin-right:auto}
.land-sec-dark::before{content:'';position:absolute;top:50%;left:50%;width:400px;height:400px;border-radius:50%;background:radial-gradient(circle,rgba(204,107,133,.06) 0%,transparent 70%);transform:translate(-50%,-50%);pointer-events:none}
.land-sec-dark .sec-sub{color:rgba(255,255,255,.35)}
.land-sec-dark h2{color:#fff}
.land-sec-light{background:linear-gradient(180deg,#FAFAF8,#F5F4F2)}
.land-sec-white{background:#fff}
.feat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;max-width:1060px;margin:0 auto}
.feat-card{padding:32px;border-radius:16px;background:#fff;border:1px solid var(--bdr-l);transition:all .3s cubic-bezier(.22,.61,.36,1)}
.feat-card:hover{box-shadow:0 16px 48px rgba(26,26,26,.06);transform:translateY(-6px);border-color:rgba(204,107,133,.2)}
.feat-card-i{margin-bottom:14px;width:40px;height:40px;border-radius:10px;background:rgba(204,107,133,.06);display:flex;align-items:center;justify-content:center}
.feat-card h3{font-size:16px;font-weight:700;margin-bottom:8px;color:var(--ink)}
.feat-card p{font-size:13.5px;color:var(--wg);line-height:1.6;font-weight:500}
.land-sec-dark .feat-card{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.06)}
.land-sec-dark .feat-card:hover{background:rgba(255,255,255,.08);border-color:rgba(204,107,133,.2);box-shadow:0 16px 48px rgba(0,0,0,.15)}
.land-sec-dark .feat-card h3{color:#fff}
.land-sec-dark .feat-card p{color:rgba(255,255,255,.4)}
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:32px;max-width:880px;margin:0 auto 48px;text-align:center}
.stat-v{font-family:var(--serif);font-size:48px;color:var(--coral);letter-spacing:-1.5px;line-height:1}
.stat-l{font-size:12px;color:var(--wg);margin-top:4px;font-weight:500}
.land-sec-dark .stat-v{color:var(--coral)}
.land-sec-dark .stat-l{color:rgba(255,255,255,.3)}
.land-cta-sec{text-align:center;padding:100px 48px;background:linear-gradient(180deg,#FAFAF8,#F4D4DA)}
.land-cta-sec h2{font-family:var(--serif);font-size:40px;color:var(--ink);margin-bottom:14px}
.land-cta-sec p{color:var(--wg);font-size:16px;margin-bottom:32px;font-weight:400}
.land-foot{background:#fff;border-top:1px solid var(--bdr-l);padding:32px 48px;display:flex;justify-content:space-between;align-items:center}
.land-foot-b{font-family:var(--serif);font-size:16px;color:var(--ink)}
.land-foot-b i{color:var(--coral);font-style:italic}
.land-foot-links{display:flex;gap:24px}
.land-foot-link{font-size:12px;color:var(--wgl);cursor:pointer;transition:color .15s;font-weight:500}
.land-foot-link:hover{color:var(--coral)}


/* ---- Login ---- */
.login{min-height:100vh;display:flex}
.login-l{flex:1;background:linear-gradient(160deg,#1C1A2E 0%,#252336 40%,#2E2B40 100%);display:flex;flex-direction:column;justify-content:center;padding:56px;position:relative;overflow:hidden}
.login-l::before{content:'';position:absolute;bottom:-20%;left:-10%;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(204,107,133,.06) 0%,transparent 70%);pointer-events:none}
.login-r{width:440px;background:#fff;display:flex;flex-direction:column;justify-content:center;padding:56px}
.login-brand{font-family:var(--serif);font-size:38px;color:#fff;margin-bottom:20px}
.login-brand i{color:var(--coral);font-style:italic}
.login-tag{font-size:16px;color:rgba(255,255,255,.4);line-height:1.6;max-width:380px;font-weight:400}
.login-r h2{font-family:var(--serif);font-size:22px;margin-bottom:4px}
.login-r p{font-size:13px;color:var(--wg);margin-bottom:24px;font-weight:500}
.login-in{width:100%;padding:11px 14px;border:1px solid var(--bdr);border-radius:8px;font-size:13px;font-family:var(--sans);margin-bottom:12px;outline:none;transition:border .12s;font-weight:500}
.login-in:focus{border-color:var(--coral)}
.login-go{width:100%;padding:11px;background:var(--coral);color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--sans);transition:background .12s;margin-top:4px}
.login-go:hover{background:var(--coral-h)}

/* ---- Product Page ---- */
.prod-hero{background:linear-gradient(160deg,#1C1A2E 0%,#252336 40%,#2E2B40 100%);color:#fff;padding:120px 48px 80px;text-align:center;position:relative;overflow:hidden}
.prod-hero::before{content:'';position:absolute;top:-20%;right:-10%;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(204,107,133,.06) 0%,transparent 70%);pointer-events:none}
.prod-hero h1{font-family:var(--serif);font-size:48px;letter-spacing:-.5px;margin-bottom:14px;line-height:1.1}
.prod-hero h1 i{color:var(--coral);font-style:italic}
.prod-hero .sub{font-size:17px;color:rgba(255,255,255,.45);max-width:580px;margin:0 auto;line-height:1.6;font-weight:400}
.mod-grid{display:grid;grid-template-columns:1fr 1fr;gap:0;max-width:1080px;margin:0 auto}
.mod-card{padding:48px 40px;border:1px solid var(--bdr-l);position:relative;transition:all .2s}
.mod-card:hover{background:var(--blush-l)}
.mod-card-num{font-family:var(--serif);font-size:48px;color:var(--bdr);position:absolute;top:16px;right:24px;line-height:1}
.mod-card h3{font-size:18px;font-weight:700;margin-bottom:8px;display:flex;align-items:center;gap:10px}
.mod-card p{font-size:14px;color:var(--wg);line-height:1.6;font-weight:500}
.mod-card ul{list-style:none;margin-top:14px;display:flex;flex-direction:column;gap:6px}
.mod-card ul li{font-size:13px;color:var(--wg);font-weight:500;padding-left:18px;position:relative}
.mod-card ul li::before{content:'→';position:absolute;left:0;color:var(--coral);font-weight:700}
.how-strip{display:grid;grid-template-columns:repeat(4,1fr);gap:0;max-width:1080px;margin:0 auto}
.how-step{padding:36px 28px;border:1px solid var(--bdr-l);text-align:center;position:relative}
.how-step::after{content:'';position:absolute;top:50%;right:-1px;width:20px;height:2px;background:var(--coral)}
.how-step:last-child::after{display:none}
.how-step-num{width:36px;height:36px;border-radius:50%;background:var(--coral);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;margin-bottom:12px}
.how-step h4{font-size:14px;font-weight:700;margin-bottom:4px}
.how-step p{font-size:12.5px;color:var(--wg);line-height:1.5;font-weight:500}

/* ---- Pricing Page ---- */
.price-hero{background:linear-gradient(160deg,#1C1A2E 0%,#252336 40%,#2E2B40 100%);color:#fff;padding:120px 48px 80px;text-align:center;position:relative;overflow:hidden}
.price-hero h1{font-family:var(--serif);font-size:48px;margin-bottom:14px}
.price-hero h1 i{color:var(--coral);font-style:italic}
.price-hero .sub{font-size:17px;color:rgba(255,255,255,.45);max-width:520px;margin:0 auto;font-weight:400}
.price-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;max-width:1000px;margin:-48px auto 0;position:relative;z-index:2;padding:0 40px}
.price-card{background:rgba(255,255,255,.95);backdrop-filter:blur(8px);border-radius:var(--r2);border:1px solid var(--bdr-l);padding:36px 28px;text-align:center;transition:all .25s cubic-bezier(.22,.61,.36,1);display:flex;flex-direction:column}
.price-card:hover{box-shadow:0 12px 48px rgba(26,26,26,.08);transform:translateY(-4px)}
.price-card.pop{border-color:var(--coral);box-shadow:0 12px 48px rgba(204,107,133,.12);transform:scale(1.03)}
.price-card.pop:hover{transform:scale(1.05);box-shadow:0 16px 56px rgba(204,107,133,.16)}
.price-card-badge{display:inline-block;background:var(--coral);color:#fff;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:1px;padding:3px 12px;border-radius:20px;margin-bottom:14px}
.price-card h3{font-size:18px;font-weight:700;margin-bottom:4px}
.price-card .price-desc{font-size:13px;color:var(--wg);margin-bottom:20px;font-weight:500}
.price-val{font-family:var(--serif);font-size:44px;line-height:1;margin-bottom:4px}
.price-per{font-size:12px;color:var(--wgl);margin-bottom:24px;font-weight:500}
.price-feats{text-align:left;flex:1;margin-bottom:24px}
.price-feat{font-size:13px;padding:7px 0;border-bottom:1px solid var(--bdr-l);display:flex;align-items:center;gap:8px;font-weight:500}
.price-feat .ck{color:var(--green);font-weight:800;font-size:14px}
.price-feat .no{color:var(--bdr);font-weight:800;font-size:14px}
.price-cta{width:100%;padding:12px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--sans);transition:all .15s;border:none}
.price-cta-p{background:var(--coral);color:#fff}
.price-cta-p:hover{background:var(--coral-h)}
.price-cta-s{background:#fff;color:var(--ink);border:1px solid var(--bdr)}
.price-cta-s:hover{border-color:var(--coral);color:var(--coral)}
.faq-grid{max-width:720px;margin:0 auto}
.faq-item{border-bottom:1px solid var(--bdr-l);padding:20px 0;cursor:pointer}
.faq-q{font-size:15px;font-weight:700;display:flex;justify-content:space-between;align-items:center}
.faq-a{font-size:13.5px;color:var(--wg);line-height:1.6;margin-top:10px;font-weight:500}

/* ---- Customers Page ---- */
.cust-hero{background:linear-gradient(160deg,#1C1A2E 0%,#252336 40%,#2E2B40 100%);color:#fff;padding:120px 48px 80px;text-align:center;position:relative;overflow:hidden}
.cust-hero h1{font-family:var(--serif);font-size:48px;margin-bottom:14px}
.cust-hero h1 i{color:var(--coral);font-style:italic}
.cust-hero .sub{font-size:17px;color:rgba(255,255,255,.45);max-width:560px;margin:0 auto;font-weight:400}
.test-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;max-width:1060px;margin:0 auto}
.test-card{background:#fff;border-radius:var(--r2);border:1px solid var(--bdr-l);padding:32px;transition:all .2s}
.test-card:hover{box-shadow:var(--sh3)}
.test-card-quote{font-size:15px;line-height:1.65;color:var(--ink);font-style:italic;margin-bottom:20px;font-weight:500;position:relative;padding-left:20px;border-left:3px solid var(--coral)}
.test-card-person{display:flex;align-items:center;gap:12px}
.test-card-av{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:#fff}
.test-card-name{font-size:13.5px;font-weight:700}
.test-card-role{font-size:12px;color:var(--wg);font-weight:500}
.case-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;max-width:1060px;margin:0 auto}
.case-card{background:#fff;border-radius:var(--r2);border:1px solid var(--bdr-l);overflow:hidden;transition:all .2s;cursor:pointer}
.case-card:hover{box-shadow:var(--sh3);transform:translateY(-2px)}
.case-card-top{padding:28px 28px 0;display:flex;justify-content:space-between;align-items:flex-start}
.case-card-top h3{font-size:17px;font-weight:700;margin-bottom:4px}
.case-card-top .ind{font-size:11px;color:var(--wgl);font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.case-card-body{padding:12px 28px 24px}
.case-card-body p{font-size:13.5px;color:var(--wg);line-height:1.6;margin-bottom:16px;font-weight:500}
.case-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.case-stat{text-align:center;background:var(--petal);border-radius:8px;padding:10px 6px}
.case-stat-v{font-family:var(--serif);font-size:20px;color:var(--coral)}
.case-stat-l{font-size:9.5px;color:var(--wgl);text-transform:uppercase;letter-spacing:.3px;margin-top:1px;font-weight:600}
.logo-strip{display:flex;justify-content:center;gap:48px;align-items:center;flex-wrap:wrap;max-width:900px;margin:0 auto}
.logo-item{font-family:var(--serif);font-size:22px;color:var(--bdr);transition:color .2s;cursor:default}
.logo-item:hover{color:var(--wg)}
.land-nav-l.active{color:#fff;font-weight:700}

@media(max-width:768px){
  .land-hero-c h1{font-size:34px}.feat-grid{grid-template-columns:1fr}
  .stats-row{grid-template-columns:repeat(2,1fr)}.login-l{display:none}.login-r{width:100%}
  .det-grid{grid-template-columns:1fr}
}
`;

// --- SHARED COMPONENTS ---

// Animated counting number
const AnimNum = ({value, prefix="", suffix="", duration=1200, style={}}) => {
  const [display, setDisplay] = useState(0);
  const numVal = typeof value === "number" ? value : parseFloat(String(value).replace(/[^0-9.]/g,""))||0;
  const isFormatted = typeof value === "string";
  useEffect(()=>{
    let start = 0; const startTime = Date.now();
    const tick = () => {
      const elapsed = Date.now()-startTime;
      const progress = Math.min(elapsed/duration,1);
      const eased = 1-Math.pow(1-progress,3);
      setDisplay(Math.round(eased*numVal));
      if(progress<1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  },[numVal,duration]);
  const formatted = isFormatted && numVal>=1000 ? (display>=1000000?"$"+((display/1000000).toFixed(1))+"M":display>=1000?"$"+((display/1000).toFixed(0))+"K":"$"+display) : display;
  return <span style={style}>{prefix}{typeof value==="string"?formatted:display.toLocaleString()}{suffix}</span>;
};

// Animated progress bar
const AnimBar = ({pct, color, height=5, delay=0}) => (
  <div style={{height,borderRadius:height/2,background:color==="light"?C.borderLight:"rgba(255,255,255,.08)",overflow:"hidden"}}>
    <div style={{height:"100%",borderRadius:height/2,background:color==="light"?C.warmGrayLight:color,width:`${pct}%`,animation:`barGrow .8s cubic-bezier(.22,.61,.36,1) ${0.3+delay*0.1}s both`,["--bar-w"]:`${pct}%`,width:0}}/>
  </div>
);

const Tip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (<div style={{background:"linear-gradient(135deg,#252336,#342F48)",color:"#fff",padding:"10px 14px",borderRadius:10,fontSize:11.5,boxShadow:"0 8px 32px rgba(0,0,0,.25),0 0 0 1px rgba(255,255,255,.06) inset",backdropFilter:"blur(12px)"}}>
    <div style={{fontWeight:700,marginBottom:4,letterSpacing:".2px"}}>{label}</div>
    {payload.map((p,i)=>(<div key={i} style={{display:"flex",alignItems:"center",gap:5,marginTop:1}}>
      <span style={{width:7,height:7,borderRadius:"50%",background:p.color,display:"inline-block"}}/>
      <span style={{color:"rgba(255,255,255,.5)"}}>{p.name}:</span>
      <span style={{fontWeight:600}}>{typeof p.value==="number"&&p.value>999?fmt(p.value):p.value}</span>
    </div>))}
  </div>);
};

const ScoreRing = ({score, size=56}) => {
  const r = (size-8)/2, circ = 2*Math.PI*r;
  const color = score>=90?C.green:score>=75?C.amber:score>=60?C.coral:"#888";
  return (<div className="ring-wrap" style={{width:size,height:size}}>
    <svg width={size} height={size}><circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(230,229,232,.3)" strokeWidth="2.5"/>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round"
      strokeDasharray={circ} strokeDashoffset={circ*(1-score/100)} transform={`rotate(-90 ${size/2} ${size/2})`}/></svg>
    <div className="ring-val" style={{color}}>{score}</div>
  </div>);
};

const Spark = ({data, h=28}) => (<div className="spark" style={{height:h}}>
  {data.map((v,i)=><div key={i} className="spark-bar" style={{height:`${(v/Math.max(...data))*100}%`}}/>)}
</div>);

const Badge = ({type, children}) => <span className={`b b-${type}`}>{children}</span>;

const AttrBox = () => (<div className="attr-box">
  <h4 style={{display:"flex",alignItems:"center",gap:6}}><Icon name="search" size={14} color={C.warmGray}/> Attribution Model</h4>
  <div className="attr-row"><span className="attr-type" style={{color:C.green}}>Sourced</span><span className="attr-def">First meaningful touch from event</span></div>
  <div className="attr-row"><span className="attr-type" style={{color:C.coral}}>Influenced</span><span className="attr-def">Event materially impacted progression</span></div>
  <div className="attr-row"><span className="attr-type" style={{color:C.amber}}>Accelerated</span><span className="attr-def">Stage moved faster after event engagement</span></div>
</div>);

// ==================== INTERACTIVE SYSTEM ====================

// Toast notification system
const useToast = () => {
  const [toasts, setToasts] = useState([]);
  const show = useCallback((msg, type="success") => {
    const id = Date.now();
    setToasts(prev => [...prev, {id, msg, type}]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  }, []);
  const ToastContainer = () => toasts.length ? (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.id} className={`toast ${t.type==="success"?"toast-success":""}`}>
          <div className="toast-icon"><svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2.5 2.5L8 3" stroke="#fff" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg></div>
          {t.msg}
        </div>
      ))}
    </div>
  ) : null;
  return { show, ToastContainer };
};

// Modal wrapper
const Modal = ({open, onClose, title, children, large, footer}) => {
  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className={`modal ${large?"modal-lg":""}`} onClick={e=>e.stopPropagation()}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
};

// Global Search
const SearchModal = ({open, onClose, nav}) => {
  const [q, setQ] = useState("");
  if (!open) return null;
  const query = q.toLowerCase();
  const results = [];
  if (query.length > 0) {
    EVENTS.forEach(e => { if (e.name.toLowerCase().includes(query)||e.type.toLowerCase().includes(query)||e.location.toLowerCase().includes(query)) results.push({type:"Event",name:e.name,sub:`${e.type} · ${e.location}`,action:()=>nav("ev-det",e.id)}) });
    ACCOUNTS.forEach(a => { if (a.name.toLowerCase().includes(query)||a.industry.toLowerCase().includes(query)) results.push({type:"Account",name:a.name,sub:`${a.industry} · ${a.segment}`,action:()=>nav("acc-det",a.id)}) });
    OPPORTUNITIES.forEach(o => { if (o.name.toLowerCase().includes(query)||o.account.toLowerCase().includes(query)) results.push({type:"Opp",name:o.name,sub:`${o.account} · ${fmt(o.amount)}`,action:()=>nav("opp-det",o.id)}) });
    MEETINGS.forEach(m => { if (m.contact.toLowerCase().includes(query)||m.company.toLowerCase().includes(query)) results.push({type:"Meeting",name:`${m.contact} - ${m.company}`,sub:`${m.event} · ${m.type}`,action:()=>nav("m-det",m.id)}) });
    COMPETITORS.forEach(c => { if (c.name.toLowerCase().includes(query)) results.push({type:"Competitor",name:c.name,sub:`Threat: ${c.threat}`,action:()=>nav("competitors")}) });
  }
  return (
    <div className="search-overlay" onClick={onClose}>
      <div className="search-modal" onClick={e=>e.stopPropagation()}>
        <div className="search-input-wrap">
          <Icon name="search" size={18} color={C.warmGrayLight}/>
          <input autoFocus placeholder="Search events, accounts, opportunities, meetings..." value={q} onChange={e=>setQ(e.target.value)}/>
          <span style={{fontSize:10,color:C.warmGrayLight,background:C.petal,padding:"3px 7px",borderRadius:4,fontWeight:700}}>ESC</span>
        </div>
        <div className="search-results">
          {query.length===0 && <div className="search-empty">Start typing to search across all modules</div>}
          {query.length>0 && results.length===0 && <div className="search-empty">No results for "{q}"</div>}
          {results.slice(0,10).map((r,i) => (
            <div key={i} className="search-result" onClick={()=>{r.action();onClose();setQ("")}}>
              <span className="search-result-type">{r.type}</span>
              <div><div className="search-result-name">{r.name}</div><div className="search-result-sub">{r.sub}</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Log Meeting Form
const LogMeetingModal = ({open, onClose, toast, eventId}) => {
  const [form, setForm] = useState({contact:"",role:"",company:"",event:eventId||"",type:"Discovery",priority:"High",notes:"",signals:"",next:""});
  const up = (k,v) => setForm(prev=>({...prev,[k]:v}));
  return (
    <Modal open={open} onClose={onClose} title="Log Meeting" large footer={
      <><button className="modal-btn modal-btn-s" onClick={onClose}>Cancel</button>
      <button className="modal-btn modal-btn-p" onClick={()=>{toast("Meeting logged successfully");onClose()}}>Save Meeting</button></>
    }>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Contact Name</label><input className="form-input" value={form.contact} onChange={e=>up("contact",e.target.value)} placeholder="Dr. Lisa Chen"/></div>
        <div className="form-group"><label className="form-label">Title / Role</label><input className="form-input" value={form.role} onChange={e=>up("role",e.target.value)} placeholder="CFO"/></div>
      </div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Company</label><input className="form-input" value={form.company} onChange={e=>up("company",e.target.value)} placeholder="Meridian Health Systems"/></div>
        <div className="form-group"><label className="form-label">Event</label>
          <select className="form-select" value={form.event} onChange={e=>up("event",e.target.value)}>
            <option value="">Select event...</option>
            {EVENTS.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
      </div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Meeting Type</label>
          <select className="form-select" value={form.type} onChange={e=>up("type",e.target.value)}>
            {["Discovery","Executive Briefing","Technical Deep Dive","Product Demo","Executive Dinner","Roundtable","Follow-up"].map(t=><option key={t}>{t}</option>)}
          </select>
        </div>
        <div className="form-group"><label className="form-label">Priority</label>
          <select className="form-select" value={form.priority} onChange={e=>up("priority",e.target.value)}>
            {["Critical","High","Medium","Low"].map(p=><option key={p}>{p}</option>)}
          </select>
        </div>
      </div>
      <div className="form-group"><label className="form-label">Key Notes</label><textarea className="form-textarea" value={form.notes} onChange={e=>up("notes",e.target.value)} placeholder="Meeting summary and key takeaways..."/></div>
      <div className="form-group"><label className="form-label">Buying Signals</label><textarea className="form-textarea" style={{minHeight:48}} value={form.signals} onChange={e=>up("signals",e.target.value)} placeholder="What signals did you pick up?"/></div>
      <div className="form-group"><label className="form-label">Next Steps</label><input className="form-input" value={form.next} onChange={e=>up("next",e.target.value)} placeholder="Schedule follow-up demo..."/></div>
    </Modal>
  );
};

// Add Note Modal
const AddNoteModal = ({open, onClose, toast, target}) => {
  const [note, setNote] = useState("");
  return (
    <Modal open={open} onClose={onClose} title={`Add Note - ${target||""}`} footer={
      <><button className="modal-btn modal-btn-s" onClick={onClose}>Cancel</button>
      <button className="modal-btn modal-btn-p" onClick={()=>{toast("Note saved");onClose();setNote("")}}>Save Note</button></>
    }>
      <div className="form-group"><label className="form-label">Note</label><textarea className="form-textarea" style={{minHeight:100}} value={note} onChange={e=>setNote(e.target.value)} placeholder="Add your observation, insight, or follow-up note..."/></div>
      <div style={{fontSize:11,color:C.warmGrayLight,fontWeight:500}}>Notes are visible to all team members with access to this record.</div>
    </Modal>
  );
};

// Share/Export Modal
const ShareModal = ({open, onClose, toast, title}) => (
  <Modal open={open} onClose={onClose} title={`Share - ${title||""}`} footer={
    <button className="modal-btn modal-btn-s" onClick={onClose}>Close</button>
  }>
    <div style={{display:"flex",flexDirection:"column",gap:10}}>
      {[{l:"Copy Link",d:"Share a direct link to this page",act:"Link copied to clipboard"},
        {l:"Export PDF",d:"Download a formatted PDF report",act:"PDF export started"},
        {l:"Send to Slack",d:"Post a summary to a Slack channel",act:"Sent to #events-intel"},
        {l:"Email Summary",d:"Send a digest to your team",act:"Email sent to team"},
        {l:"Add to Board Report",d:"Include in the next executive report",act:"Added to Q3 Board Report"},
      ].map((opt,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 14px",background:C.petal,borderRadius:8,cursor:"pointer",transition:"all .12s"}}
          onClick={()=>{toast(opt.act);onClose()}}
          onMouseOver={e=>e.currentTarget.style.background=C.blushLight} onMouseOut={e=>e.currentTarget.style.background=C.petal}>
          <div><div style={{fontWeight:700,fontSize:13}}>{opt.l}</div><div style={{fontSize:11.5,color:C.warmGray,fontWeight:500}}>{opt.d}</div></div>
          <Icon name="reports" size={14} color={C.warmGrayLight}/>
        </div>
      ))}
    </div>
  </Modal>
);

// Add Event Modal
const AddEventModal = ({open, onClose, toast}) => {
  const [form, setForm] = useState({name:"",type:"Conference",location:"",date:"",format:"Sponsored",spend:""});
  const up = (k,v) => setForm(prev=>({...prev,[k]:v}));
  return (
    <Modal open={open} onClose={onClose} title="Add Event" large footer={
      <><button className="modal-btn modal-btn-s" onClick={onClose}>Cancel</button>
      <button className="modal-btn modal-btn-p" onClick={()=>{toast("Event created: " + (form.name||"New Event"));onClose()}}>Create Event</button></>
    }>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Event Name</label><input className="form-input" value={form.name} onChange={e=>up("name",e.target.value)} placeholder="HIMSS 2026"/></div>
        <div className="form-group"><label className="form-label">Type</label>
          <select className="form-select" value={form.type} onChange={e=>up("type",e.target.value)}>
            {["Conference","Hosted Dinner","Summit","CAB","Webinar","Roadshow","Other"].map(t=><option key={t}>{t}</option>)}
          </select>
        </div>
      </div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Location</label><input className="form-input" value={form.location} onChange={e=>up("location",e.target.value)} placeholder="Orlando, FL"/></div>
        <div className="form-group"><label className="form-label">Date</label><input className="form-input" type="date" value={form.date} onChange={e=>up("date",e.target.value)}/></div>
      </div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Format</label>
          <select className="form-select" value={form.format} onChange={e=>up("format",e.target.value)}>
            {["Sponsored","Hosted","Attended","Speaking","Exhibiting"].map(f=><option key={f}>{f}</option>)}
          </select>
        </div>
        <div className="form-group"><label className="form-label">Estimated Spend</label><input className="form-input" value={form.spend} onChange={e=>up("spend",e.target.value)} placeholder="$150,000"/></div>
      </div>
    </Modal>
  );
};

// Add Competitor Observation Modal
const AddObservationModal = ({open, onClose, toast}) => {
  const [form, setForm] = useState({competitor:"",event:"",observation:"",threat:"Medium"});
  const up = (k,v) => setForm(prev=>({...prev,[k]:v}));
  return (
    <Modal open={open} onClose={onClose} title="Log Competitor Observation" footer={
      <><button className="modal-btn modal-btn-s" onClick={onClose}>Cancel</button>
      <button className="modal-btn modal-btn-p" onClick={()=>{toast("Observation logged");onClose()}}>Save</button></>
    }>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Competitor</label><input className="form-input" value={form.competitor} onChange={e=>up("competitor",e.target.value)} placeholder="Palo Alto Networks"/></div>
        <div className="form-group"><label className="form-label">Event</label>
          <select className="form-select" value={form.event} onChange={e=>up("event",e.target.value)}>
            <option value="">Select event...</option>
            {EVENTS.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
      </div>
      <div className="form-group"><label className="form-label">Observation</label><textarea className="form-textarea" value={form.observation} onChange={e=>up("observation",e.target.value)} placeholder="What did you observe? Booth presence, messaging, product announcements..."/></div>
      <div className="form-group"><label className="form-label">Threat Level</label>
        <select className="form-select" value={form.threat} onChange={e=>up("threat",e.target.value)}>
          {["Critical","High","Medium","Low"].map(t=><option key={t}>{t}</option>)}
        </select>
      </div>
    </Modal>
  );
};

// Inline action bar for detail pages
const ActionBar = ({onNote, onMeeting, onShare}) => (
  <div className="action-bar">
    {onNote && <button className="action-btn" onClick={onNote}><Icon name="reports" size={12}/> Add Note</button>}
    {onMeeting && <button className="action-btn" onClick={onMeeting}><Icon name="meetings" size={12}/> Log Meeting</button>}
    {onShare && <button className="action-btn" onClick={onShare}><Icon name="globe" size={12}/> Share</button>}
  </div>
);

// ==================== PAGES ====================

// 1. DASHBOARD - Bento grid with hero KPI strip
const Dashboard = ({nav}) => {
  const eventChart = EVENTS.map(e=>({name:e.name.length>14?e.name.slice(0,14)+"…":e.name,inf:e.pipeInfluenced,src:e.pipeSourced,roi:e.roi}));
  const timeline = [{m:"Jan",i:850000,s:290000},{m:"Feb",i:1650000,s:590000},{m:"Mar",i:2800000,s:920000},{m:"Apr",i:4200000,s:1400000},{m:"May",i:6750000,s:2100000},{m:"Jun",i:7700000,s:2420000},{m:"Jul",i:8800000,s:2420000}];
  const typeMix = [{name:"Conference",value:5},{name:"Hosted",value:2},{name:"Summit",value:1},{name:"CAB",value:1}];

  return (<div className="pg">
    {/* 3 Hero KPIs - dramatic with animated numbers */}
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16,marginBottom:22}}>
      <div className="card scale-in d1 glow" style={{padding:"30px 28px",background:"linear-gradient(135deg,#252336,#342F48)",color:"#fff",border:"1px solid rgba(255,255,255,.06)"}}>
        <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:"1.2px",color:"rgba(255,255,255,.3)",fontWeight:700,marginBottom:14}}>Pipeline Influenced</div>
        <div style={{fontFamily:"var(--serif)",fontSize:46,lineHeight:1,letterSpacing:"-1.5px"}}><AnimNum value={totals.pipeInf} prefix="$" suffix="" duration={1400} style={{}}/></div>
        <div style={{fontSize:12,marginTop:12,color:"rgba(255,255,255,.28)",fontWeight:500}}><span style={{color:"#6DD4A0",fontWeight:700}}>↑ 34%</span> vs prior year · {EVENTS.length} events</div>
      </div>
      <div className="card scale-in d2 hover-lift" style={{padding:"30px 28px"}}>
        <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:"1.2px",color:C.warmGrayLight,fontWeight:700,marginBottom:14}}>Influenced Revenue</div>
        <div style={{fontFamily:"var(--serif)",fontSize:46,lineHeight:1,letterSpacing:"-1.5px",color:C.green}}><AnimNum value={totals.revenue} prefix="$" duration={1600}/></div>
        <div style={{fontSize:12,marginTop:12,color:C.warmGray,fontWeight:500}}><span style={{color:C.green,fontWeight:700}}>{(totals.revenue/totals.spend).toFixed(1)}x</span> return on {fmt(totals.spend)} spend</div>
      </div>
      <div className="card scale-in d3 hover-lift" style={{padding:"30px 28px"}}>
        <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:"1.2px",color:C.warmGrayLight,fontWeight:700,marginBottom:14}}>Event Efficiency</div>
        <div style={{fontFamily:"var(--serif)",fontSize:46,lineHeight:1,letterSpacing:"-1.5px",color:C.coral}}><AnimNum value={totals.meetings} duration={1000}/></div>
        <div style={{fontSize:12,marginTop:12,color:C.warmGray,fontWeight:500}}>meetings at <span style={{fontWeight:700}}>{fmt(Math.round(totals.spend/totals.meetings))}</span> avg cost · {totals.accounts} accounts</div>
      </div>
    </div>

    {/* CRM vs Cipher - the hook */}
    <div className="card card-p scale-in d3 shimmer-bg" style={{marginBottom:20}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
        <div><div style={{fontSize:15,fontWeight:700}}>What Your CRM Missed</div><div style={{fontSize:12,color:C.warmGrayLight,fontWeight:500}}>Pipeline attribution: CRM source field vs. Cipher event intelligence</div></div>
        <Badge type="coral">Cipher Exclusive</Badge>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <div style={{background:C.petal,borderRadius:10,padding:20}}>
          <div style={{fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:".6px",color:C.warmGrayLight,marginBottom:12}}>CRM Says (Source Field)</div>
          {[{label:"Inbound / Website",value:"$4.2M",pct:55},{label:"Outbound / SDR",value:"$2.1M",pct:28},{label:"Partner / Referral",value:"$0.9M",pct:12},{label:"Event",value:"$0.4M",pct:5}].map((r,i)=>(
            <div key={i} style={{marginBottom:8}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:12,fontWeight:600,marginBottom:3}}><span>{r.label}</span><span>{r.value} ({r.pct}%)</span></div>
              <AnimBar pct={r.pct} color="light" delay={i}/>
            </div>
          ))}
        </div>
        <div style={{background:"linear-gradient(135deg,#252336,#342F48)",borderRadius:10,padding:20,color:"#fff"}}>
          <div style={{fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:".6px",color:"rgba(255,255,255,.35)",marginBottom:12}}>Cipher Found (Event Influence)</div>
          {[{label:"Event Sourced",value:"$5.5M",pct:35,color:C.coral},{label:"Event Influenced",value:"$6.8M",pct:43,color:C.rose},{label:"Event Accelerated",value:"$2.2M",pct:14,color:C.amber},{label:"No Event Touch",value:"$1.3M",pct:8,color:C.warmGray}].map((r,i)=>(
            <div key={i} style={{marginBottom:8}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:12,fontWeight:600,marginBottom:3}}><span>{r.label}</span><span>{r.value} ({r.pct}%)</span></div>
              <AnimBar pct={r.pct} color={r.color} delay={i}/>
            </div>
          ))}
          <div style={{marginTop:12,padding:"10px 12px",background:"rgba(204,107,133,.12)",borderRadius:8,fontSize:12,lineHeight:1.5,fontWeight:500}}>
            <span style={{fontWeight:800,color:C.coral}}>92% of pipeline</span><span style={{color:"rgba(255,255,255,.5)"}}> had event involvement your CRM missed.</span>
          </div>
        </div>
      </div>
    </div>

    {/* Secondary metrics - compact row */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:10,marginBottom:18}}>
      {[
        {l:"Events",v:EVENTS.length},{l:"Sourced",v:fmt(totals.pipeSrc)},{l:"Opps Accelerated",v:totals.oppsAcc},{l:"Top Event",v:"RSAC · 94"},{l:"Avg Cost/Mtg",v:fmt(Math.round(totals.spend/totals.meetings))}
      ].map((k,i)=>(<div key={i} className={`card fade-up d${i+2}`} style={{padding:"14px 16px"}}>
        <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:".6px",color:C.warmGrayLight,fontWeight:700,marginBottom:4}}>{k.l}</div>
        <div style={{fontFamily:"var(--serif)",fontSize:20,lineHeight:1}}>{k.v}</div>
      </div>))}
    </div>

    {/* Bento Grid - Asymmetric */}
    <div style={{display:"grid",gridTemplateColumns:"3fr 2fr",gap:14,marginBottom:14}}>
      <div className="card card-p fade-up d4">
        <div style={{fontSize:13.5,fontWeight:600,marginBottom:2}}>Pipeline by Event</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:16}}>Sourced vs. influenced pipeline</div>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={eventChart} barGap={2}><CartesianGrid strokeDasharray="3 3" stroke={C.borderLight}/>
            <XAxis dataKey="name" tick={{fontSize:10,fill:C.warmGray}} axisLine={{stroke:C.border}} tickLine={false}/>
            <YAxis tick={{fontSize:10,fill:C.warmGray}} axisLine={false} tickLine={false} tickFormatter={fmtN}/>
            <Tooltip content={<Tip/>}/><Bar dataKey="inf" name="Influenced" fill={C.coral} radius={[4,4,0,0]}/><Bar dataKey="src" name="Sourced" fill={C.rose} radius={[4,4,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="card card-p fade-up d5">
        <div style={{fontSize:13.5,fontWeight:600,marginBottom:2}}>Strategic Insights</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:12}}>Revenue intelligence signals</div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {INSIGHTS.slice(0,4).map(ins=>(<div key={ins.id} style={{padding:"10px 12px",borderRadius:8,border:`1px solid ${ins.priority==="critical"?C.coralSoft:C.borderLight}`,borderLeft:`3px solid ${ins.priority==="critical"?C.coral:ins.priority==="high"?C.amber:C.rose}`,cursor:"pointer",transition:"all .12s"}}
            onMouseOver={e=>e.currentTarget.style.boxShadow="0 2px 8px rgba(0,0,0,.04)"} onMouseOut={e=>e.currentTarget.style.boxShadow="none"}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8}}>
              <div><div style={{fontSize:12.5,fontWeight:600,marginBottom:2,display:"flex",alignItems:"center",gap:6}}><InsightIcon type={ins.type} size={22}/> {ins.title}</div>
              <div style={{fontSize:11,color:C.warmGray,lineHeight:1.4}}>{ins.body}</div></div>
              <div style={{textAlign:"right",flexShrink:0}}><div style={{fontFamily:"var(--serif)",fontSize:18,lineHeight:1}}>{ins.metric}</div>
              <div style={{fontSize:9,color:ins.delta.startsWith("+")?C.green:ins.delta.startsWith("-")?C.coral:C.amber,fontWeight:600}}>{ins.delta}</div></div>
            </div>
          </div>))}
        </div>
      </div>
    </div>

    <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr",gap:14,marginBottom:14}}>
      <div className="card card-p fade-up d5">
        <div style={{fontSize:13.5,fontWeight:600,marginBottom:2}}>Cumulative Pipeline</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:16}}>Influenced & sourced growth - 2025</div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={timeline}><defs>
            <linearGradient id="gi" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={C.coral} stopOpacity={.12}/><stop offset="100%" stopColor={C.coral} stopOpacity={0}/></linearGradient>
            <linearGradient id="gs" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={C.rose} stopOpacity={.12}/><stop offset="100%" stopColor={C.rose} stopOpacity={0}/></linearGradient>
          </defs><CartesianGrid strokeDasharray="3 3" stroke={C.borderLight}/>
            <XAxis dataKey="m" tick={{fontSize:10,fill:C.warmGray}} axisLine={{stroke:C.border}} tickLine={false}/>
            <YAxis tick={{fontSize:10,fill:C.warmGray}} axisLine={false} tickLine={false} tickFormatter={fmtN}/>
            <Tooltip content={<Tip/>}/>
            <Area type="monotone" dataKey="i" name="Influenced" stroke={C.coral} fill="url(#gi)" strokeWidth={2}/>
            <Area type="monotone" dataKey="s" name="Sourced" stroke={C.rose} fill="url(#gs)" strokeWidth={2}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="card card-p fade-up d6">
        <div style={{fontSize:13.5,fontWeight:600,marginBottom:2}}>Event Mix</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:12}}>By format type</div>
        <ResponsiveContainer width="100%" height={180}>
          <PieChart><Pie data={typeMix} cx="50%" cy="50%" innerRadius={48} outerRadius={72} paddingAngle={3} dataKey="value">
            {typeMix.map((_,i)=><Cell key={i} fill={CHART_COLORS[i]}/>)}</Pie>
            <Tooltip content={<Tip/>}/>
          </PieChart>
        </ResponsiveContainer>
        <div style={{display:"flex",flexWrap:"wrap",gap:8,justifyContent:"center",marginTop:8}}>
          {typeMix.map((t,i)=><span key={i} style={{fontSize:10.5,display:"flex",alignItems:"center",gap:4}}>
            <span style={{width:6,height:6,borderRadius:"50%",background:CHART_COLORS[i],display:"inline-block"}}/>{t.name}
          </span>)}
        </div>
      </div>
      <div className="card card-p fade-up d7">
        <div style={{fontSize:13.5,fontWeight:600,marginBottom:2}}>ROI Ranking</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:12}}>Top performing events</div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {[...EVENTS].sort((a,b)=>b.roi-a.roi).slice(0,6).map((e,i)=>(<div key={e.id} style={{display:"flex",alignItems:"center",gap:8,cursor:"pointer"}} onClick={()=>nav("ev-det",e.id)}>
            <span style={{fontSize:10,color:C.warmGrayLight,width:16}}>#{i+1}</span>
            <ScoreRing score={e.roi} size={32}/>
            <div style={{flex:1,minWidth:0}}><div style={{fontSize:12,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{e.name}</div>
            <div style={{fontSize:10,color:C.warmGrayLight}}>{e.type}</div></div>
          </div>))}
        </div>
      </div>
    </div>
  </div>);
};
const EventsPage = ({nav}) => {
  const [filter, setFilter] = useState("All");
  const [viewMode, setViewMode] = useState("cards");
  const types = ["All","Conference","Hosted Dinner","Summit","CAB"];
  const list = filter==="All"?EVENTS:EVENTS.filter(e=>e.type===filter);
  const totalEvSpend = EVENTS.reduce((s,e)=>s+e.spend,0);
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const eventWeeks = {3:4,7:3,9:5,13:4,14:3,16:5,17:4,20:2,24:3,28:2,29:3,37:4,38:3,42:3};
  const weeks = Array.from({length:52},(_,w)=>({week:w,intensity:eventWeeks[w]||0}));

  return (<div className="pg">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:14}}>
      <div className="pg-head" style={{marginBottom:0}}><h2>Events</h2><p>Performance across {EVENTS.length} events - {fmt(totalEvSpend)} total spend</p></div>
      <div style={{display:"flex",gap:8,alignItems:"center"}}>
        <div style={{display:"flex",gap:4}}>{types.map(t=><button key={t} onClick={()=>setFilter(t)}
          style={{padding:"5px 14px",fontSize:11.5,borderRadius:20,border:`1px solid ${filter===t?C.coral:C.border}`,background:filter===t?C.coralSoft:"#fff",color:filter===t?C.coral:C.warmGray,cursor:"pointer",fontFamily:"var(--sans)",fontWeight:600,transition:"all .12s"}}>{t}</button>)}</div>
        <div style={{display:"flex",border:`1px solid ${C.border}`,borderRadius:8,overflow:"hidden"}}>
          {["cards","list","calendar"].map(m=><button key={m} onClick={()=>setViewMode(m)} style={{padding:"5px 10px",fontSize:11,fontWeight:700,border:"none",background:viewMode===m?C.coralSoft:"#fff",color:viewMode===m?C.coral:C.warmGrayLight,cursor:"pointer",fontFamily:"var(--sans)",textTransform:"capitalize"}}>{m}</button>)}
        </div>
      </div>
    </div>

    {viewMode==="calendar" ? (<>
      {/* Heatmap */}
      <div className="card card-p fade-up d1" style={{marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
          <div style={{fontSize:14,fontWeight:700}}>2025 Activity</div>
          <div style={{display:"flex",gap:4,alignItems:"center",fontSize:10,color:C.warmGrayLight,fontWeight:600}}>
            <span>Less</span>{[0,1,2,3,4,5].map(i=><div key={i} style={{width:11,height:11,borderRadius:3,background:i===0?C.borderLight:`rgba(204,107,133,${i*0.2})`}}/>)}<span>More</span>
          </div>
        </div>
        <div style={{display:"flex",gap:2,overflowX:"auto",paddingBottom:6}}>
          {weeks.map(w=><div key={w.week} style={{display:"flex",flexDirection:"column",gap:2}}>
            {[0,1,2,3,4].map(d=><div key={d} style={{width:13,height:13,borderRadius:3,background:w.intensity===0?C.borderLight:`rgba(204,107,133,${Math.min(1,w.intensity*0.2)})`,cursor:"pointer",transition:"transform .1s"}}
              onMouseOver={e=>e.target.style.transform="scale(1.3)"} onMouseOut={e=>e.target.style.transform="scale(1)"}/>)}
          </div>)}
        </div>
        <div style={{display:"flex",marginTop:4}}>{months.map((m,i)=><div key={i} style={{flex:1,fontSize:9,color:C.warmGrayLight,fontWeight:600,textAlign:"center"}}>{m}</div>)}</div>
      </div>
      {/* Event timeline */}
      <div className="card card-p fade-up d2">
        {EVENTS.sort((a,b)=>new Date(a.date)-new Date(b.date)).map((e,i)=>(
          <div key={e.id} style={{display:"flex",gap:14,alignItems:"center",padding:"10px 0",borderBottom:i<EVENTS.length-1?`1px solid ${C.borderLight}`:"none",cursor:"pointer"}} onClick={()=>nav("ev-det",e.id)}>
            <div style={{width:44,textAlign:"center",flexShrink:0}}><div style={{fontSize:17,fontWeight:700,fontFamily:"var(--serif)",lineHeight:1}}>{new Date(e.date).getDate()}</div><div style={{fontSize:9,color:C.warmGrayLight,fontWeight:700,textTransform:"uppercase"}}>{new Date(e.date).toLocaleDateString("en-US",{month:"short"})}</div></div>
            <div style={{width:3,height:32,borderRadius:2,background:e.status==="Completed"?C.green:C.amber,flexShrink:0}}/>
            <div style={{flex:1}}><div style={{fontWeight:700,fontSize:13}}>{e.name}</div><div style={{fontSize:11,color:C.warmGray,fontWeight:500}}>{e.location} · {e.type}</div></div>
            <div style={{textAlign:"right"}}><div style={{fontSize:12,fontWeight:700}}>{fmt(e.spend)}</div><div style={{fontSize:10,color:C.warmGrayLight,fontWeight:500}}>{e.meetings} meetings</div></div>
            <Badge type={e.status==="Completed"?"green":"amber"}>{e.status}</Badge>
          </div>
        ))}
      </div>
    </>) : viewMode==="list" ? (
      <div className="card" style={{overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr>{["Event","Type","Date","Spend","Meetings","Pipeline","ROI","Status"].map(h=><th key={h} style={{textAlign:"left",fontSize:10,textTransform:"uppercase",letterSpacing:".5px",fontWeight:700,color:C.warmGrayLight,padding:"10px 14px",borderBottom:`1px solid ${C.borderLight}`,background:C.petal}}>{h}</th>)}</tr></thead>
          <tbody>{list.map(e=><tr key={e.id} style={{cursor:"pointer"}} onClick={()=>nav("ev-det",e.id)} onMouseOver={e2=>e2.currentTarget.style.background="rgba(250,250,248,.5)"} onMouseOut={e2=>e2.currentTarget.style.background="transparent"}>
            <td style={{padding:"10px 14px",fontWeight:700,fontSize:13,borderBottom:`1px solid ${C.borderLight}`}}>{e.name}</td>
            <td style={{padding:"10px 14px",borderBottom:`1px solid ${C.borderLight}`}}><Badge type="ink">{e.type}</Badge></td>
            <td style={{padding:"10px 14px",fontSize:12,color:C.warmGray,borderBottom:`1px solid ${C.borderLight}`}}>{new Date(e.date).toLocaleDateString("en-US",{month:"short",year:"numeric"})}</td>
            <td style={{padding:"10px 14px",fontSize:13,borderBottom:`1px solid ${C.borderLight}`}}>{fmt(e.spend)}</td>
            <td style={{padding:"10px 14px",fontSize:13,borderBottom:`1px solid ${C.borderLight}`}}>{e.meetings}</td>
            <td style={{padding:"10px 14px",fontSize:13,fontWeight:700,color:C.coral,borderBottom:`1px solid ${C.borderLight}`}}>{fmt(e.pipeInfluenced)}</td>
            <td style={{padding:"10px 14px",borderBottom:`1px solid ${C.borderLight}`}}><ScoreRing score={e.roi} size={30}/></td>
            <td style={{padding:"10px 14px",borderBottom:`1px solid ${C.borderLight}`}}><Badge type={e.status==="Completed"?"green":"amber"}>{e.status}</Badge></td>
          </tr>)}</tbody>
        </table>
      </div>
    ) : (
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(330px,1fr))",gap:14}}>
      {list.map((e,i)=>(<div key={e.id} className={`card fade-up d${(i%4)+1}`} style={{cursor:"pointer",overflow:"hidden"}} onClick={()=>nav("ev-det",e.id)}>
        <div style={{padding:"18px 20px 14px",display:"flex",gap:14,alignItems:"flex-start"}}>
          <ScoreRing score={e.roi}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontWeight:600,fontSize:14.5,marginBottom:2}}>{e.name}</div>
            <div style={{fontSize:11.5,color:C.warmGray,display:"flex",gap:8,flexWrap:"wrap"}}>
              <span>{e.location}</span>·<span>{new Date(e.date).toLocaleDateString("en-US",{month:"short",year:"numeric"})}</span>
            </div>
            <div style={{display:"flex",gap:6,marginTop:6}}><Badge type="ink">{e.type}</Badge><Badge type={e.status==="Completed"?"green":"amber"}>{e.status}</Badge></div>
          </div>
        </div>
        <div style={{padding:"0 20px 16px",display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,textAlign:"center"}}>
          {[{l:"Spend",v:fmt(e.spend)},{l:"Meetings",v:e.meetings},{l:"Pipeline",v:fmt(e.pipeInfluenced),c:C.coral},{l:"Revenue",v:fmt(e.revenue),c:C.green}].map((m,j)=>(
            <div key={j} style={{padding:"8px 4px",background:C.petal,borderRadius:6}}>
              <div style={{fontFamily:"var(--serif)",fontSize:15,color:m.c||C.ink}}>{m.v}</div>
              <div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",letterSpacing:".3px",marginTop:1}}>{m.l}</div>
            </div>
          ))}
        </div>
        <div style={{padding:"0 20px 14px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div style={{fontSize:11,color:C.warmGray}}>{e.accounts} accounts · {e.oppsAccelerated} opps accelerated</div>
          <Spark data={e.trend} h={22}/>
        </div>
      </div>))}
    </div>
    )}
  </div>);
};

// 3. ACCOUNTS - Kanban board by progression stage
const AccountsPage = ({nav}) => {
  const stages = ["Closing","Accelerated","Pipeline","Engaged","Early Stage","Stalled"];
  const stageColors = {Closing:C.green,Accelerated:"#2D8A56",Pipeline:C.amber,Engaged:C.roseDeep,"Early Stage":C.warmGray,Stalled:C.coral};
  const healthBuckets = [{label:"Strong (80+)",count:ACCOUNTS.filter(a=>a.health>=80).length,color:C.green},{label:"Healthy (50-79)",count:ACCOUNTS.filter(a=>a.health>=50&&a.health<80).length,color:C.amber},{label:"At Risk (<50)",count:ACCOUNTS.filter(a=>a.health<50).length,color:C.coral}];
  const totalAccs = ACCOUNTS.length;

  return (<div className="pg">
    <div className="pg-head"><h2>Accounts</h2><p>Account-based engagement intelligence</p></div>

    {/* Health distribution bar */}
    <div className="card fade-up d1" style={{padding:"16px 20px",marginBottom:16,display:"flex",alignItems:"center",gap:20}}>
      <div style={{flex:1}}>
        <div style={{display:"flex",borderRadius:6,overflow:"hidden",height:8}}>
          {healthBuckets.map((b,i)=><div key={i} style={{width:`${b.count/totalAccs*100}%`,background:b.color,transition:"width .4s"}}/>)}
        </div>
      </div>
      <div style={{display:"flex",gap:16}}>
        {healthBuckets.map((b,i)=><div key={i} style={{display:"flex",alignItems:"center",gap:5,fontSize:11.5,fontWeight:600}}>
          <div style={{width:8,height:8,borderRadius:"50%",background:b.color}}/>{b.count} {b.label}
        </div>)}
      </div>
    </div>

    <div className="kanban">
      {stages.map(stg=>{
        const accs=ACCOUNTS.filter(a=>a.stage===stg);
        return (<div key={stg} className="kanban-col">
          <div className="kanban-col-head" style={{color:stageColors[stg]}}>
            {stg} <span>{accs.length}</span>
          </div>
          {accs.map(a=>(<div key={a.id} className="kanban-card" onClick={()=>nav("acc-det",a.id)}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
              <div style={{fontWeight:600,fontSize:13}}>{a.name}</div>
              {a.target&&<span style={{fontSize:8,background:C.coralSoft,color:C.coral,padding:"1px 5px",borderRadius:4,fontWeight:700}}>TARGET</span>}
            </div>
            <div style={{fontSize:11,color:C.warmGray,marginBottom:8}}>{a.industry} · {a.segment}</div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{display:"flex",gap:10,fontSize:10.5,color:C.warmGrayLight}}>
                <span>{a.events.length} events</span>
                <span>{a.meetings} mtgs</span>
              </div>
              <div style={{width:32,height:32,borderRadius:"50%",background:C.petal,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:a.health>=80?C.green:a.health>=50?C.amber:C.coral}}>{a.health}</div>
            </div>
            {a.competitor!=="–"&&<div style={{fontSize:10,color:C.warmGrayLight,marginTop:6,borderTop:`1px solid ${C.borderLight}`,paddingTop:6,display:"flex",alignItems:"center",gap:4}}><Icon name="sword" size={11} color={C.warmGrayLight}/> {a.competitor}</div>}
          </div>))}
        </div>);
      })}
    </div>
  </div>);
};

// 4. OPPORTUNITIES - Pipeline funnel + deal cards
const OppsPage = ({nav}) => {
  const stages = ["Discovery","Evaluation","Proposal","Negotiation","Closing","Stalled"];
  const stageColors = ["#9A9090","#D690A0","#C09840","#CC6B85","#2D8A56","#777"];
  const [selStage, setSelStage] = useState(null);
  const filtered = selStage?OPPORTUNITIES.filter(o=>o.stage===selStage):OPPORTUNITIES;
  const totalAmt = OPPORTUNITIES.reduce((s,o)=>s+o.amount,0);
  const wtdConf = OPPORTUNITIES.reduce((s,o)=>s+o.amount*o.confidence/100,0);

  return (<div className="pg">
    <div className="pg-head"><h2>Pipeline</h2><p>Event-influenced deals with transparent attribution</p></div>

    {/* Pipeline summary */}
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:16}}>
      <div className="card fade-up d1" style={{padding:"16px 20px"}}><div style={{fontSize:9.5,textTransform:"uppercase",letterSpacing:".8px",color:C.warmGrayLight,fontWeight:700,marginBottom:6}}>Total Pipeline</div><div style={{fontFamily:"var(--serif)",fontSize:28,letterSpacing:"-.5px"}}>{fmt(totalAmt)}</div></div>
      <div className="card fade-up d2" style={{padding:"16px 20px"}}><div style={{fontSize:9.5,textTransform:"uppercase",letterSpacing:".8px",color:C.warmGrayLight,fontWeight:700,marginBottom:6}}>Weighted Pipeline</div><div style={{fontFamily:"var(--serif)",fontSize:28,letterSpacing:"-.5px",color:C.coral}}>{fmt(Math.round(wtdConf))}</div></div>
      <div className="card fade-up d3" style={{padding:"16px 20px"}}><div style={{fontSize:9.5,textTransform:"uppercase",letterSpacing:".8px",color:C.warmGrayLight,fontWeight:700,marginBottom:6}}>Avg Confidence</div><div style={{fontFamily:"var(--serif)",fontSize:28,letterSpacing:"-.5px"}}>{Math.round(OPPORTUNITIES.reduce((s,o)=>s+o.confidence,0)/OPPORTUNITIES.length)}%</div></div>
    </div>

    {/* Funnel */}
    <div className="funnel">
      {stages.map((stg,i)=>{
        const opps=OPPORTUNITIES.filter(o=>o.stage===stg);
        const total=opps.reduce((s,o)=>s+o.amount,0);
        return (<div key={stg} className="funnel-stage" style={{background:stageColors[i],opacity:selStage&&selStage!==stg?.7:1}} onClick={()=>setSelStage(selStage===stg?null:stg)}>
          <div className="funnel-val">{opps.length}</div>
          <div className="funnel-lbl">{stg}</div>
          <div className="funnel-amt">{fmt(total)}</div>
        </div>);
      })}
    </div>

    {/* Deal Cards */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))",gap:12}}>
      {filtered.map((o,i)=>(<div key={o.id} className={`card fade-up d${(i%4)+1}`} style={{cursor:"pointer"}} onClick={()=>nav("opp-det",o.id)}>
        <div className="card-p">
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
            <div><div style={{fontWeight:600,fontSize:14}}>{o.name}</div>
            <div style={{fontSize:11.5,color:C.warmGray}}>{o.account}</div></div>
            <Badge type={o.stage==="Closing"?"green":o.stage==="Stalled"?"coral":o.stage==="Negotiation"?"coral":"amber"}>{o.stage}</Badge>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:10}}>
            <div style={{background:C.petal,borderRadius:6,padding:"8px",textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:17}}>{fmt(o.amount)}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Value</div></div>
            <div style={{background:C.petal,borderRadius:6,padding:"8px",textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:17}}>{o.confidence}%</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Confidence</div></div>
            <div style={{background:C.petal,borderRadius:6,padding:"8px",textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:17}}>{o.events.length}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Touchpoints</div></div>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",fontSize:11,color:C.warmGray}}>
            <span><Badge type="rose">{o.source}</Badge></span>
            <span>Close: {new Date(o.close).toLocaleDateString("en-US",{month:"short",day:"numeric"})}</span>
          </div>
          <div style={{display:"flex",gap:4,marginTop:8}}>{o.events.map((eid,j)=>{const ev=EVENTS.find(e=>e.id===eid);return ev?<span key={j} style={{fontSize:9.5,background:j===0?C.coralSoft:C.petal,color:j===0?C.coral:C.warmGray,padding:"2px 7px",borderRadius:4,fontWeight:500}}>{ev.name}</span>:null})}</div>
        </div>
      </div>))}
    </div>
    <AttrBox/>
  </div>);
};

// 5. MEETINGS - Intelligence dossier timeline
const MeetingsPage = ({nav}) => {
  const [filter, setFilter] = useState("All");
  const prios = ["All","Critical","High","Medium"];
  const sorted = [...MEETINGS].sort((a,b)=>new Date(b.date)-new Date(a.date));
  const filtered = filter==="All"?sorted:sorted.filter(m=>m.priority===filter);
  const completed = MEETINGS.filter(m=>m.status==="Completed").length;
  const avgSentiment = Math.round(MEETINGS.reduce((s,m)=>s+m.sentiment,0)/MEETINGS.length);

  return (<div className="pg">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:14}}>
      <div className="pg-head" style={{marginBottom:0}}><h2>Meetings</h2><p>Intelligence from every event conversation</p></div>
      <div style={{display:"flex",gap:6}}>{prios.map(p=><button key={p} onClick={()=>setFilter(p)}
        style={{padding:"5px 14px",fontSize:11.5,borderRadius:20,border:`1px solid ${filter===p?C.coral:C.border}`,background:filter===p?C.coralSoft:"#fff",color:filter===p?C.coral:C.warmGray,cursor:"pointer",fontFamily:"var(--sans)",fontWeight:600}}>{p}</button>)}</div>
    </div>

    {/* Stats header */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:18}}>
      {[{l:"Total Meetings",v:MEETINGS.length},{l:"Follow-ups Complete",v:`${completed}/${MEETINGS.length}`},{l:"Avg Sentiment",v:avgSentiment,c:avgSentiment>=80?C.green:C.amber},{l:"Critical Priority",v:MEETINGS.filter(m=>m.priority==="Critical").length,c:C.coral}].map((s,i)=>(
        <div key={i} className={`card fade-up d${i+1}`} style={{padding:"12px 16px"}}>
          <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:".6px",color:C.warmGrayLight,fontWeight:700,marginBottom:4}}>{s.l}</div>
          <div style={{fontFamily:"var(--serif)",fontSize:22,color:s.c||C.ink}}>{s.v}</div>
        </div>
      ))}
    </div>

    <div className="timeline" style={{maxWidth:800}}>
      {filtered.map((m,i)=>(<div key={m.id} className={`tl-item fade-up d${(i%4)+1}`} onClick={()=>nav("m-det",m.id)} style={{cursor:"pointer"}}>
        <div className={`tl-dot ${m.priority==="Critical"?"critical":m.priority==="High"?"high":"completed"}`}/>
        <div className="card" style={{marginBottom:0}}>
          <div className="card-p">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
              <div>
                <div style={{fontWeight:600,fontSize:14.5}}>{m.contact}</div>
                <div style={{fontSize:12,color:C.warmGray}}>{m.role} · {m.company}</div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{fontSize:11,color:C.warmGrayLight}}>{new Date(m.date).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</div>
                <Badge type={m.priority==="Critical"?"coral":m.priority==="High"?"amber":"gray"}>{m.priority}</Badge>
              </div>
            </div>
            <div style={{fontSize:12.5,color:C.warmGray,lineHeight:1.5,marginBottom:8}}>{m.summary}</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <div style={{background:C.petal,borderRadius:6,padding:"8px 10px"}}><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:600,marginBottom:2}}>Buying Signal</div><div style={{fontSize:11.5,lineHeight:1.4}}>{m.signals.slice(0,60)}…</div></div>
              <div style={{background:C.petal,borderRadius:6,padding:"8px 10px"}}><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:600,marginBottom:2}}>Outcome</div><div style={{fontSize:11.5,lineHeight:1.4}}>{m.outcome}</div></div>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:8,paddingTop:8,borderTop:`1px solid ${C.borderLight}`}}>
              <div style={{display:"flex",gap:6}}>
                <Badge type="ink">{m.type}</Badge>
                <Badge type="ink">{m.event}</Badge>
              </div>
              <Badge type={m.status==="Completed"?"green":"amber"}>{m.status}</Badge>
            </div>
            {/* Sentiment bar */}
            <div style={{marginTop:8,display:"flex",alignItems:"center",gap:8}}>
              <div style={{flex:1,height:4,borderRadius:2,background:C.borderLight,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${m.sentiment}%`,borderRadius:2,background:m.sentiment>=85?C.green:m.sentiment>=60?C.amber:C.coral}}/>
              </div>
              <span style={{fontSize:10,fontWeight:600,color:m.sentiment>=85?C.green:m.sentiment>=60?C.amber:C.coral}}>{m.sentiment}</span>
            </div>
          </div>
        </div>
      </div>))}
    </div>
  </div>);
};

// 6. COMPETITORS - War room with threat matrix
const CompPage = ({toast, onAdd}) => {
  const threatOrder = ["Critical","High","Medium","Low"];
  const sorted = [...COMPETITORS].sort((a,b)=>threatOrder.indexOf(a.threat)-threatOrder.indexOf(b.threat));

  return (<div className="pg">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:18}}>
      <div className="pg-head" style={{marginBottom:0}}><h2>Competitor Intelligence</h2><p>Field signals from conferences and events - your competitive war room</p></div>
      <button className="tbtn tbtn-p" onClick={onAdd} style={{display:"flex",alignItems:"center",gap:5}}><Icon name="competitors" size={13} color="#fff"/> Log Observation</button>
    </div>

    {/* Threat summary strip */}
    <div style={{display:"flex",gap:8,marginBottom:20}}>
      {threatOrder.map(t=>{
        const count=COMPETITORS.filter(c=>c.threat===t).length;
        if(!count)return null;
        const col=t==="Critical"?C.coral:t==="High"?C.amber:t==="Medium"?C.roseDeep:C.warmGray;
        return (<div key={t} style={{padding:"10px 16px",borderRadius:8,background:`${col}10`,border:`1px solid ${col}20`,display:"flex",alignItems:"center",gap:8}}>
          <span style={{width:8,height:8,borderRadius:"50%",background:col}}/><span style={{fontSize:12,fontWeight:600,color:col}}>{count}</span><span style={{fontSize:11.5,color:C.warmGray}}>{t} Threat</span>
        </div>);
      })}
    </div>

    <div className="threat-matrix">
      {sorted.map((c,i)=>{
        const col=c.threat==="Critical"?C.coral:c.threat==="High"?C.amber:c.threat==="Medium"?C.roseDeep:C.warmGray;
        return (<div key={c.id} className={`threat-card fade-up d${(i%4)+1}`}>
          <div className="threat-bar" style={{background:col}}/>
          <div className="threat-card-top">
            <div><div style={{fontWeight:600,fontSize:16}}>{c.name}</div>
            <div style={{fontSize:11.5,color:C.warmGray,marginTop:2}}>{c.events.map(eid=>EVENTS.find(e=>e.id===eid)?.name).join(", ")}</div></div>
            <Badge type={c.threat==="Critical"?"coral":c.threat==="High"?"amber":c.threat==="Medium"?"rose":"gray"}>{c.threat}</Badge>
          </div>
          <div className="threat-card-body">
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>
              <div className="threat-field"><div className="threat-field-l">Booth</div><div className="threat-field-v">{c.booth?"Yes":"No"}</div></div>
              <div className="threat-field"><div className="threat-field-l">Talks</div><div className="threat-field-v">{c.talks} sessions</div></div>
              <div className="threat-field"><div className="threat-field-l">Traffic</div><div className="threat-field-v">{c.traffic}</div></div>
              <div className="threat-field"><div className="threat-field-l">Announce</div><div className="threat-field-v">{c.announce}</div></div>
            </div>
            <div className="threat-field"><div className="threat-field-l">Messaging</div><div className="threat-field-v">{c.theme}</div></div>
            <div style={{marginTop:10,padding:12,background:C.petal,borderRadius:8,borderLeft:`3px solid ${col}`}}>
              <div style={{fontSize:9.5,textTransform:"uppercase",letterSpacing:".5px",fontWeight:600,color:C.warmGrayLight,marginBottom:3}}>Intelligence Note</div>
              <div style={{fontSize:12,lineHeight:1.5}}>{c.notes}</div>
            </div>
          </div>
        </div>);
      })}
    </div>
  </div>);
};

// 7. REPORTS - Magazine layout with full-bleed charts
const ReportsPage = () => {
  const scatter=EVENTS.map(e=>({name:e.name,spend:e.spend,inf:e.pipeInfluenced,roi:e.roi,mtg:e.meetings}));
  const typePerf=[{type:"Hosted",roi:93.5,pipe:1375},{type:"CAB",roi:82,pipe:1100},{type:"Conference",roi:79.8,pipe:2400},{type:"Summit",roi:68,pipe:1400}];
  const reps=[{name:"Sarah Chen",mtg:15,pipe:5800000,accts:12,rate:93},{name:"Marcus Rivera",mtg:14,pipe:4850000,accts:10,rate:89},{name:"Jordan Park",mtg:12,pipe:3610000,accts:8,rate:85}];

  return (<div className="pg">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:18}}>
      <div className="pg-head" style={{marginBottom:0}}><h2>Reports</h2><p>Executive reporting and strategic analysis</p></div>
      <button className="tbtn" style={{display:"flex",alignItems:"center",gap:5}}><Icon name="reports" size={13}/> Export All</button>
    </div>

    {/* Full-width hero chart */}
    <div className="card card-p" style={{marginBottom:14}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
        <div><div style={{fontSize:15,fontWeight:600}}>Spend vs. Pipeline Influence</div><div style={{fontSize:11.5,color:C.warmGrayLight}}>Bubble size = meetings booked · hover for details</div></div>
        <div style={{display:"flex",gap:4}}><Badge type="ink">All Events</Badge><Badge type="ink">2025</Badge></div>
      </div>
      <ResponsiveContainer width="100%" height={340}>
        <ScatterChart><CartesianGrid strokeDasharray="3 3" stroke={C.borderLight}/>
          <XAxis dataKey="spend" name="Spend" tick={{fontSize:10,fill:C.warmGray}} tickFormatter={fmtN} axisLine={{stroke:C.border}} tickLine={false} label={{value:"Event Spend →",position:"insideBottom",offset:-5,fontSize:10,fill:C.warmGrayLight}}/>
          <YAxis dataKey="inf" name="Pipeline" tick={{fontSize:10,fill:C.warmGray}} tickFormatter={fmtN} axisLine={false} tickLine={false} label={{value:"Pipeline Influenced →",angle:-90,position:"insideLeft",fontSize:10,fill:C.warmGrayLight}}/>
          <ZAxis dataKey="mtg" range={[80,400]} name="Meetings"/>
          <Tooltip content={({active,payload})=>{if(!active||!payload?.length)return null;const d=payload[0].payload;return(<div style={{background:"linear-gradient(135deg,#252336,#342F48)",color:"#fff",padding:"10px 14px",borderRadius:8,fontSize:12}}><div style={{fontWeight:600,marginBottom:4}}>{d.name}</div><div>Spend: {fmt(d.spend)}</div><div>Pipeline: {fmt(d.inf)}</div><div>Meetings: {d.mtg}</div><div>ROI: {d.roi}</div></div>);}}/>
          <Scatter data={scatter} fill={C.coral}/>
        </ScatterChart>
      </ResponsiveContainer>
    </div>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:14}}>
      <div className="card card-p">
        <div style={{fontSize:15,fontWeight:600,marginBottom:2}}>Format Performance</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:16}}>ROI by event type</div>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={typePerf} layout="vertical" barSize={18}><CartesianGrid strokeDasharray="3 3" stroke={C.borderLight} horizontal={false}/>
            <XAxis type="number" tick={{fontSize:10,fill:C.warmGray}} axisLine={{stroke:C.border}} tickLine={false}/>
            <YAxis type="category" dataKey="type" tick={{fontSize:11.5,fill:C.ink}} axisLine={false} tickLine={false} width={80}/>
            <Tooltip content={<Tip/>}/><Bar dataKey="roi" name="Avg ROI" fill={C.coral} radius={[0,4,4,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="card card-p">
        <div style={{fontSize:15,fontWeight:600,marginBottom:2}}>Attribution Breakdown</div>
        <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:16}}>Sourced vs Influenced vs Accelerated</div>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={EVENTS.map(e=>({n:e.name.length>10?e.name.slice(0,10)+"…":e.name,src:e.pipeSourced,inf:e.pipeInfluenced-e.pipeSourced,acc:e.oppsAccelerated*100000}))}>
            <CartesianGrid strokeDasharray="3 3" stroke={C.borderLight}/><XAxis dataKey="n" tick={{fontSize:9,fill:C.warmGray}} axisLine={{stroke:C.border}} tickLine={false}/>
            <YAxis tick={{fontSize:10,fill:C.warmGray}} axisLine={false} tickLine={false} tickFormatter={fmtN}/><Tooltip content={<Tip/>}/>
            <Bar dataKey="src" name="Sourced" stackId="a" fill={C.inkLight}/><Bar dataKey="inf" name="Influenced" stackId="a" fill={C.coral}/><Bar dataKey="acc" name="Accel (est)" stackId="a" fill={C.rose} radius={[4,4,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>

    {/* Rep Performance - leaderboard style */}
    <div className="card card-p">
      <div style={{fontSize:15,fontWeight:600,marginBottom:2}}>Team Performance</div>
      <div style={{fontSize:11.5,color:C.warmGrayLight,marginBottom:16}}>Sales team event follow-up outcomes</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
        {reps.map((r,i)=>(<div key={r.name} style={{background:C.petal,borderRadius:12,padding:20,position:"relative",overflow:"hidden"}}>
          {i===0&&<div style={{position:"absolute",top:0,left:0,right:0,height:3,background:C.coral}}/>}
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
            <div style={{width:36,height:36,borderRadius:"50%",background:i===0?C.coral:i===1?C.rose:C.blush,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:700,color:i===0?"#fff":C.ink}}>{i+1}</div>
            <div><div style={{fontWeight:600,fontSize:14}}>{r.name}</div></div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div><div style={{fontFamily:"var(--serif)",fontSize:20}}>{r.mtg}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Meetings</div></div>
            <div><div style={{fontFamily:"var(--serif)",fontSize:20,color:C.coral}}>{fmt(r.pipe)}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Pipeline</div></div>
            <div><div style={{fontFamily:"var(--serif)",fontSize:20}}>{r.accts}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Accounts</div></div>
            <div><div style={{fontFamily:"var(--serif)",fontSize:20,color:C.green}}>{r.rate}%</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase"}}>Follow-up</div></div>
          </div>
        </div>))}
      </div>
    </div>
  </div>);
};

// 8. INSIGHTS - Priority-sorted with metric sparklines
const InsightsPage = () => {
  const order = ["critical","high","medium"];
  const sorted = [...INSIGHTS].sort((a,b)=>order.indexOf(a.priority)-order.indexOf(b.priority));
  return (<div className="pg">
    <div className="pg-head"><h2>Strategic Recommendations</h2><p>Data-driven insights to optimize your event strategy</p></div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
      {sorted.map((ins,i)=>{
        const col=ins.priority==="critical"?C.coral:ins.priority==="high"?C.amber:C.roseDeep;
        return (<div key={ins.id} className={`card fade-up d${(i%4)+1}`} style={{overflow:"hidden"}}>
          <div style={{height:3,background:col}}/>
          <div className="card-p" style={{display:"flex",gap:16}}>
            <div style={{flex:1}}>
              <div style={{marginBottom:10}}><InsightIcon type={ins.type} size={32}/></div>
              <div style={{fontWeight:600,fontSize:14.5,marginBottom:4}}>{ins.title}</div>
              <div style={{fontSize:12.5,color:C.warmGray,lineHeight:1.55,marginBottom:10}}>{ins.body}</div>
              <Badge type={ins.priority==="critical"?"coral":ins.priority==="high"?"amber":"rose"}>{ins.priority}</Badge>
            </div>
            <div style={{width:90,flexShrink:0,textAlign:"center",display:"flex",flexDirection:"column",justifyContent:"center",background:C.petal,borderRadius:10,padding:"12px 8px"}}>
              <div style={{fontFamily:"var(--serif)",fontSize:24,lineHeight:1}}>{ins.metric}</div>
              <div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",letterSpacing:".3px",marginTop:2}}>{ins.metricLabel}</div>
              <div style={{fontSize:12,fontWeight:700,color:ins.delta.startsWith("+")?C.green:ins.delta.startsWith("-")?C.coral:C.amber,marginTop:4}}>{ins.delta}</div>
            </div>
          </div>
        </div>);
      })}
    </div>
  </div>);
};

// 9. ROI CALCULATOR - Interactive what-if simulator
const ROICalcPage = () => {
  const [spend, setSpend] = useState(150000);
  const [meetings, setMeetings] = useState(40);
  const [accounts, setAccounts] = useState(25);
  const costPerMeeting = Math.round(spend / (meetings || 1));
  const costPerAccount = Math.round(spend / (accounts || 1));
  const estPipeline = Math.round(meetings * 52000);
  const estRevenue = Math.round(estPipeline * 0.32);
  const roi = spend > 0 ? ((estRevenue - spend) / spend * 100).toFixed(0) : 0;
  const breakEven = spend > 0 ? Math.ceil(spend / 52000) : 0;

  return (<div className="pg">
    <div className="pg-head"><h2>ROI Calculator</h2><p>Model event economics before you commit budget</p></div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
      <div className="card card-p">
        <h3 style={{fontFamily:"var(--serif)",fontSize:17,marginBottom:20}}>Input Assumptions</h3>
        {[{l:"Event Spend",v:spend,set:setSpend,min:5000,max:500000,step:5000,fmt:fmt},
          {l:"Expected Meetings",v:meetings,set:setMeetings,min:5,max:200,step:1,fmt:v=>v},
          {l:"Target Accounts Engaged",v:accounts,set:setAccounts,min:3,max:100,step:1,fmt:v=>v},
        ].map((s,i)=>(
          <div key={i} style={{marginBottom:20}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
              <span style={{fontSize:12,fontWeight:700,textTransform:"uppercase",letterSpacing:".4px",color:C.warmGray}}>{s.l}</span>
              <span style={{fontSize:15,fontWeight:700,fontFamily:"var(--serif)"}}>{s.fmt(s.v)}</span>
            </div>
            <input type="range" min={s.min} max={s.max} step={s.step} value={s.v} onChange={e=>s.set(Number(e.target.value))}
              style={{width:"100%",accentColor:C.coral,height:4,cursor:"pointer"}}/>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.warmGrayLight,marginTop:2}}>
              <span>{s.fmt(s.min)}</span><span>{s.fmt(s.max)}</span>
            </div>
          </div>
        ))}
        <div style={{background:C.petal,borderRadius:10,padding:16,marginTop:8}}>
          <div style={{fontSize:10,textTransform:"uppercase",letterSpacing:".5px",color:C.warmGrayLight,fontWeight:700,marginBottom:8}}>Model Assumptions</div>
          <div style={{fontSize:12,color:C.warmGray,lineHeight:1.6,fontWeight:500}}>
            Based on Cipher benchmarks: avg $52K pipeline per qualified meeting, 32% pipeline-to-revenue conversion, 2.1x pipeline multiplier for hosted formats.
          </div>
        </div>
      </div>

      <div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
          {[{l:"Est. Pipeline",v:fmt(estPipeline),c:C.coral},{l:"Est. Revenue",v:fmt(estRevenue),c:C.green},{l:"Projected ROI",v:`${roi}%`,c:Number(roi)>0?C.green:C.coral},{l:"Break-even Meetings",v:breakEven,c:C.ink}].map((m,i)=>(
            <div key={i} className="card card-p" style={{textAlign:"center"}}>
              <div style={{fontFamily:"var(--serif)",fontSize:26,color:m.c}}>{m.v}</div>
              <div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",letterSpacing:".3px",marginTop:3,fontWeight:700}}>{m.l}</div>
            </div>
          ))}
        </div>
        <div className="card card-p">
          <div style={{fontSize:14,fontWeight:700,marginBottom:4}}>Cost Efficiency</div>
          <div style={{fontSize:12,color:C.warmGrayLight,marginBottom:16}}>Unit economics for this event</div>
          {[{l:"Cost per Meeting",v:fmt(costPerMeeting),bench:"$3,100 avg",good:costPerMeeting<3100},
            {l:"Cost per Account Engaged",v:fmt(costPerAccount),bench:"$5,800 avg",good:costPerAccount<5800},
            {l:"Pipeline per Dollar Spent",v:`$${(estPipeline/spend).toFixed(1)}`,bench:"$12.4 avg",good:(estPipeline/spend)>12},
          ].map((m,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:i<2?`1px solid ${C.borderLight}`:"none"}}>
              <span style={{fontSize:13,fontWeight:600}}>{m.l}</span>
              <div style={{textAlign:"right"}}>
                <span style={{fontSize:14,fontWeight:700,color:m.good?C.green:C.coral}}>{m.v}</span>
                <div style={{fontSize:10,color:C.warmGrayLight,fontWeight:500}}>Benchmark: {m.bench}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="card card-p" style={{marginTop:14}}>
          <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>Revenue Waterfall</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={[{n:"Spend",v:spend,fill:C.inkLight},{n:"Pipeline",v:estPipeline,fill:C.coral},{n:"Revenue",v:estRevenue,fill:C.green}]} barSize={40}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.borderLight}/>
              <XAxis dataKey="n" tick={{fontSize:11,fill:C.warmGray,fontWeight:600}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fontSize:10,fill:C.warmGray}} axisLine={false} tickLine={false} tickFormatter={fmtN}/>
              <Tooltip content={<Tip/>}/>
              <Bar dataKey="v" name="Amount" radius={[6,6,0,0]}>
                {[C.inkLight,C.coral,C.green].map((c,i)=><Cell key={i} fill={c}/>)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  </div>);
};

// 10. EVENT COMPARISON - Side-by-side radar + metrics
const EventComparePage = ({nav}) => {
  const [sel, setSel] = useState(["ev3","ev5","ev1"]);
  const selected = sel.map(id=>EVENTS.find(e=>e.id===id)).filter(Boolean);
  const maxPipe = Math.max(...EVENTS.map(e=>e.pipeInfluenced));
  const maxSpend = Math.max(...EVENTS.map(e=>e.spend));
  const maxMtg = Math.max(...EVENTS.map(e=>e.meetings));

  const radarData = ["ROI","Pipeline","Meetings","Accounts","Revenue","Efficiency"].map(dim=>({
    dim,...Object.fromEntries(selected.map((e,i)=>[`e${i}`,
      dim==="ROI"?e.roi:dim==="Pipeline"?Math.round(e.pipeInfluenced/maxPipe*100):dim==="Meetings"?Math.round(e.meetings/maxMtg*100):dim==="Accounts"?Math.round(e.accounts/41*100):dim==="Revenue"?Math.round(e.revenue/2100000*100):Math.round((e.pipeInfluenced/e.spend)/20*100)
    ]))
  }));

  return (<div className="pg">
    <div className="pg-head"><h2>Event Comparison</h2><p>Side-by-side analysis across key performance dimensions</p></div>
    <div style={{display:"flex",gap:8,marginBottom:20,flexWrap:"wrap"}}>
      {EVENTS.map(e=><button key={e.id} onClick={()=>setSel(prev=>prev.includes(e.id)?prev.filter(x=>x!==e.id):[...prev.slice(-2),e.id])}
        style={{padding:"5px 14px",fontSize:11.5,borderRadius:20,border:`1px solid ${sel.includes(e.id)?C.coral:C.border}`,background:sel.includes(e.id)?C.coralSoft:"#fff",color:sel.includes(e.id)?C.coral:C.warmGray,cursor:"pointer",fontFamily:"var(--sans)",fontWeight:600,transition:"all .12s"}}>{e.name}</button>)}
    </div>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
      <div className="card card-p">
        <div style={{fontSize:14,fontWeight:700,marginBottom:4}}>Performance Radar</div>
        <div style={{fontSize:12,color:C.warmGrayLight,marginBottom:12}}>Normalized scores across 6 dimensions</div>
        <ResponsiveContainer width="100%" height={320}>
          <RadarChart data={radarData}>
            <PolarGrid stroke={C.borderLight}/>
            <PolarAngleAxis dataKey="dim" tick={{fontSize:11,fill:C.warmGray,fontWeight:600}}/>
            <PolarRadiusAxis tick={false} axisLine={false} domain={[0,100]}/>
            {selected.map((_,i)=><Radar key={i} name={selected[i]?.name} dataKey={`e${i}`} stroke={CHART_COLORS[i]} fill={CHART_COLORS[i]} fillOpacity={0.12} strokeWidth={2}/>)}
            <Legend iconType="circle" iconSize={8} wrapperStyle={{fontSize:11,fontWeight:600}}/>
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        {selected.map((e,i)=>(
          <div key={e.id} className="card" style={{borderLeft:`4px solid ${CHART_COLORS[i]}`,cursor:"pointer"}} onClick={()=>nav("ev-det",e.id)}>
            <div className="card-p">
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                <div><div style={{fontWeight:700,fontSize:15}}>{e.name}</div><div style={{fontSize:12,color:C.warmGray,fontWeight:500}}>{e.type} · {e.location}</div></div>
                <ScoreRing score={e.roi} size={40}/>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:6,textAlign:"center"}}>
                {[{l:"Spend",v:fmt(e.spend)},{l:"Meetings",v:e.meetings},{l:"Pipeline",v:fmt(e.pipeInfluenced)},{l:"Revenue",v:fmt(e.revenue)},{l:"Cost/Mtg",v:fmt(Math.round(e.spend/e.meetings))}].map((m,j)=>(
                  <div key={j} style={{background:C.petal,borderRadius:6,padding:"6px 4px"}}><div style={{fontFamily:"var(--serif)",fontSize:14}}>{m.v}</div><div style={{fontSize:8,color:C.warmGrayLight,textTransform:"uppercase",letterSpacing:".2px",fontWeight:700}}>{m.l}</div></div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>);
};

// 11. ACCOUNT JOURNEY - Horizontal timeline visualization
const AccountJourneyPage = ({nav}) => {
  const [selAcc, setSelAcc] = useState("acc5");
  const acc = ACCOUNTS.find(a=>a.id===selAcc);
  const accEvents = acc ? EVENTS.filter(e=>acc.events.includes(e.id)).sort((a,b)=>new Date(a.date)-new Date(b.date)) : [];
  const accMeetings = MEETINGS.filter(m=>m.accId===selAcc);
  const accOpps = OPPORTUNITIES.filter(o=>o.accId===selAcc);
  const stages = ["Early Stage","Engaged","Pipeline","Accelerated","Closing","Won"];
  const stageIdx = stages.indexOf(acc?.stage);

  return (<div className="pg">
    <div className="pg-head"><h2>Account Journey</h2><p>Visualize how accounts move through events to revenue</p></div>
    <div style={{display:"flex",gap:8,marginBottom:20,flexWrap:"wrap"}}>
      {ACCOUNTS.filter(a=>a.events.length>=2).map(a=><button key={a.id} onClick={()=>setSelAcc(a.id)}
        style={{padding:"5px 14px",fontSize:11.5,borderRadius:20,border:`1px solid ${selAcc===a.id?C.coral:C.border}`,background:selAcc===a.id?C.coralSoft:"#fff",color:selAcc===a.id?C.coral:C.warmGray,cursor:"pointer",fontFamily:"var(--sans)",fontWeight:600}}>{a.name}</button>)}
    </div>

    {acc && <>
      {/* Journey Bar */}
      <div className="card card-p" style={{marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:700,marginBottom:14}}>Progression Timeline</div>
        <div style={{display:"flex",gap:0,marginBottom:20}}>
          {stages.map((stg,i)=>(
            <div key={i} style={{flex:1,textAlign:"center",position:"relative"}}>
              <div style={{height:6,background:i<=stageIdx?C.coral:C.borderLight,borderRadius:i===0?"3px 0 0 3px":i===stages.length-1?"0 3px 3px 0":"0"}}/>
              <div style={{position:"absolute",top:-8,left:"50%",transform:"translateX(-50%)",width:22,height:22,borderRadius:"50%",background:i<=stageIdx?C.coral:"#fff",border:i<=stageIdx?"none":`2px solid ${C.borderLight}`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                {i<=stageIdx&&<svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2.5 2.5L8 3.5" stroke="#fff" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
              </div>
              <div style={{fontSize:10,fontWeight:i===stageIdx?800:500,color:i<=stageIdx?C.ink:C.warmGrayLight,marginTop:14,textTransform:"uppercase",letterSpacing:".3px"}}>{stg}</div>
            </div>
          ))}
        </div>

        {/* Event touchpoints */}
        <div style={{fontSize:12,fontWeight:700,textTransform:"uppercase",letterSpacing:".5px",color:C.warmGrayLight,marginBottom:10}}>Event Touchpoints</div>
        <div style={{display:"flex",gap:12,overflowX:"auto",paddingBottom:8}}>
          {accEvents.map((e,i)=>(
            <div key={e.id} style={{minWidth:200,background:C.petal,borderRadius:10,padding:16,cursor:"pointer",borderLeft:`3px solid ${CHART_COLORS[i%CHART_COLORS.length]}`,flexShrink:0}} onClick={()=>nav("ev-det",e.id)}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:4}}>{e.name}</div>
              <div style={{fontSize:11,color:C.warmGray,fontWeight:500}}>{new Date(e.date).toLocaleDateString("en-US",{month:"short",year:"numeric"})}</div>
              <div style={{fontSize:11,color:C.warmGray,fontWeight:500,marginTop:4}}>{accMeetings.filter(m=>m.evId===e.id).length} meetings</div>
              <div style={{marginTop:6}}><ScoreRing score={e.roi} size={30}/></div>
            </div>
          ))}
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <div className="card card-p">
          <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>Meeting History</div>
          {accMeetings.map(m=>(
            <div key={m.id} style={{padding:"10px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer"}} onClick={()=>nav("m-det",m.id)}>
              <div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontWeight:700,fontSize:13}}>{m.contact} - {m.role}</span><Badge type={m.priority==="Critical"?"coral":"amber"}>{m.priority}</Badge></div>
              <div style={{fontSize:11.5,color:C.warmGray,fontWeight:500,marginTop:2}}>{m.event} · {m.outcome}</div>
            </div>
          ))}
        </div>
        <div className="card card-p">
          <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>Open Opportunities</div>
          {accOpps.length?accOpps.map(o=>(
            <div key={o.id} style={{padding:"10px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer"}} onClick={()=>nav("opp-det",o.id)}>
              <div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontWeight:700,fontSize:13}}>{o.name}</span><Badge type={o.stage==="Closing"?"green":"amber"}>{o.stage}</Badge></div>
              <div style={{fontSize:11.5,color:C.warmGray,fontWeight:500,marginTop:2}}>{fmt(o.amount)} · {o.confidence}% confidence</div>
            </div>
          )):<div style={{fontSize:13,color:C.warmGrayLight,padding:20,textAlign:"center",fontWeight:500}}>No open opportunities</div>}
          <div style={{marginTop:12}}>
            <div style={{fontSize:11,fontWeight:700,color:C.warmGray,marginBottom:6}}>Account Intelligence</div>
            <div style={{fontSize:12,color:C.warmGray,lineHeight:1.6,fontWeight:500}}>{acc.notes}</div>
            {acc.competitor!=="–"&&<div style={{marginTop:8,display:"flex",alignItems:"center",gap:5,fontSize:12,color:C.warmGray,fontWeight:600}}><Icon name="sword" size={12} color={C.coral}/> Competitor: {acc.competitor}</div>}
          </div>
        </div>
      </div>
    </>}
  </div>);
};

// 12. BUDGET OPTIMIZER - Recommended allocation
const BudgetPage = () => {
  const [totalBudget, setTotalBudget] = useState(500000);
  const typeData = [
    {type:"Conference",avgROI:79.8,avgCostMtg:3500,pipePerDollar:13.2,share:.45},
    {type:"Hosted Dinner",avgROI:93.5,avgCostMtg:2100,pipePerDollar:48.2,share:.25},
    {type:"CAB",avgROI:82,avgCostMtg:3000,pipePerDollar:24.4,share:.15},
    {type:"Summit",avgROI:68,avgCostMtg:3275,pipePerDollar:14.7,share:.15},
  ];
  const recommended = typeData.map(t=>({...t,alloc:Math.round(totalBudget*t.share),estPipe:Math.round(totalBudget*t.share*t.pipePerDollar)}));
  const totalEstPipe = recommended.reduce((s,r)=>s+r.estPipe,0);

  return (<div className="pg">
    <div className="pg-head"><h2>Budget Optimizer</h2><p>Data-driven allocation recommendations based on historical event performance</p></div>

    <div className="card card-p" style={{marginBottom:16}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div><div style={{fontSize:14,fontWeight:700}}>Total Event Budget</div><div style={{fontSize:12,color:C.warmGrayLight,fontWeight:500}}>Adjust to see recommended allocation</div></div>
        <div style={{fontFamily:"var(--serif)",fontSize:32}}>{fmt(totalBudget)}</div>
      </div>
      <input type="range" min={100000} max={2000000} step={50000} value={totalBudget} onChange={e=>setTotalBudget(Number(e.target.value))}
        style={{width:"100%",accentColor:C.coral,height:4,cursor:"pointer"}}/>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.warmGrayLight,marginTop:2,fontWeight:500}}><span>$100K</span><span>$2M</span></div>
    </div>

    <div style={{display:"grid",gridTemplateColumns:"3fr 2fr",gap:16,marginBottom:16}}>
      <div className="card card-p">
        <div style={{fontSize:14,fontWeight:700,marginBottom:4}}>Recommended Allocation</div>
        <div style={{fontSize:12,color:C.warmGrayLight,marginBottom:16,fontWeight:500}}>Optimized by ROI efficiency and pipeline-per-dollar</div>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={recommended} barSize={32}>
            <CartesianGrid strokeDasharray="3 3" stroke={C.borderLight}/>
            <XAxis dataKey="type" tick={{fontSize:11,fill:C.warmGray,fontWeight:600}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fontSize:10,fill:C.warmGray}} axisLine={false} tickLine={false} tickFormatter={fmtN}/>
            <Tooltip content={<Tip/>}/>
            <Bar dataKey="alloc" name="Budget" fill={C.coral} radius={[6,6,0,0]}/>
            <Bar dataKey="estPipe" name="Est. Pipeline" fill={C.rose} radius={[6,6,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div className="card card-p" style={{textAlign:"center",background:"linear-gradient(135deg,#252336,#342F48)",color:"#fff",border:"1px solid rgba(255,255,255,.06)"}}>
          <div style={{fontSize:10,textTransform:"uppercase",letterSpacing:".5px",color:"rgba(255,255,255,.35)",fontWeight:700,marginBottom:6}}>Projected Pipeline</div>
          <div style={{fontFamily:"var(--serif)",fontSize:32}}>{fmt(totalEstPipe)}</div>
          <div style={{fontSize:11,color:"rgba(255,255,255,.4)",marginTop:4,fontWeight:500}}>{(totalEstPipe/totalBudget).toFixed(1)}x return on spend</div>
        </div>
        {recommended.map((r,i)=>(
          <div key={i} className="card card-p" style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div><div style={{fontWeight:700,fontSize:13}}>{r.type}</div><div style={{fontSize:11,color:C.warmGrayLight,fontWeight:500}}>{Math.round(r.share*100)}% of budget</div></div>
            <div style={{textAlign:"right"}}><div style={{fontWeight:700,fontSize:14,fontFamily:"var(--serif)"}}>{fmt(r.alloc)}</div><div style={{fontSize:10,color:C.green,fontWeight:700}}>{fmt(r.estPipe)} pipeline</div></div>
          </div>
        ))}
      </div>
    </div>

    {/* Cipher insight */}
    <div className="card" style={{borderLeft:`4px solid ${C.coral}`,overflow:"hidden"}}>
      <div className="card-p" style={{display:"flex",gap:16,alignItems:"flex-start"}}>
        <InsightIcon type="efficiency" size={36}/>
        <div>
          <div style={{fontWeight:700,fontSize:14,marginBottom:4}}>Cipher Recommendation</div>
          <div style={{fontSize:13,color:C.warmGray,lineHeight:1.6,fontWeight:500}}>Based on your historical data, shifting 15% of conference budget to hosted dinners would increase overall pipeline-per-dollar by 28% while reducing total event spend by $75K. Hosted formats show 4x the ROI efficiency of large conference sponsorships.</div>
        </div>
      </div>
    </div>
  </div>);
};

// 13. PRE-EVENT PLANNING - Target account hitlist + meeting goals
const PreEventPage = ({nav, toast}) => {
  const [selEvent, setSelEvent] = useState("ev2"); // HLTH is "Planned"
  const ev = EVENTS.find(e=>e.id===selEvent);
  const planned = EVENTS.filter(e=>e.status==="Planned"||e.id==="ev2");
  const [targets, setTargets] = useState([
    {id:"t1",acc:"Meridian Health Systems",owner:"Sarah Chen",status:"Outreach sent",priority:"Critical",goal:"Executive dinner invite",contacted:true},
    {id:"t2",acc:"Apex Financial Group",owner:"Marcus Rivera",status:"Meeting confirmed",priority:"High",goal:"CISO 1:1 briefing",contacted:true},
    {id:"t3",acc:"NovaTech Solutions",owner:"Jordan Park",status:"Not started",priority:"Medium",goal:"Product demo",contacted:false},
    {id:"t4",acc:"Summit Healthcare Partners",owner:"Marcus Rivera",status:"Meeting confirmed",priority:"Critical",goal:"Expansion discussion",contacted:true},
    {id:"t5",acc:"BrightPath Education",owner:"Marcus Rivera",status:"Outreach sent",priority:"Medium",goal:"District case study review",contacted:true},
    {id:"t6",acc:"Vanguard Medical",owner:"Jordan Park",status:"Not started",priority:"Low",goal:"Intro meeting",contacted:false},
  ]);
  const [goalMeetings, setGoalMeetings] = useState(35);
  const [goalAccounts, setGoalAccounts] = useState(20);
  const [goalPipeline, setGoalPipeline] = useState(1500000);
  const confirmed = targets.filter(t=>t.status==="Meeting confirmed").length;
  const outreach = targets.filter(t=>t.status==="Outreach sent").length;

  const addTarget = () => {
    const accs = ACCOUNTS.filter(a=>!targets.find(t=>t.acc===a.name));
    if(accs.length){const a=accs[0];setTargets([...targets,{id:"t"+(targets.length+1),acc:a.name,owner:a.owner,status:"Not started",priority:"Medium",goal:"Discovery meeting",contacted:false}]);toast("Target account added");}
  };

  return (<div className="pg">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:18}}>
      <div className="pg-head" style={{marginBottom:0}}><h2>Pre-Event Planning</h2><p>Target accounts, meeting goals, and outreach tracking</p></div>
      <div style={{display:"flex",gap:8}}>
        {planned.map(e=><button key={e.id} onClick={()=>setSelEvent(e.id)} style={{padding:"6px 14px",fontSize:12,borderRadius:8,border:`1px solid ${selEvent===e.id?C.coral:C.border}`,background:selEvent===e.id?C.coralSoft:"#fff",color:selEvent===e.id?C.coral:C.warmGray,cursor:"pointer",fontFamily:"var(--sans)",fontWeight:700}}>{e.name}</button>)}
      </div>
    </div>

    {ev&&<>
    {/* Goals strip */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:16}}>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24}}>{confirmed}/{goalMeetings}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Meeting Goal</div><div style={{height:4,borderRadius:2,background:C.borderLight,marginTop:8,overflow:"hidden"}}><div style={{height:"100%",borderRadius:2,background:confirmed>=goalMeetings?C.green:C.coral,width:`${Math.min(100,confirmed/goalMeetings*100)}%`}}/></div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24}}>{targets.length}/{goalAccounts}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Account Target</div><div style={{height:4,borderRadius:2,background:C.borderLight,marginTop:8,overflow:"hidden"}}><div style={{height:"100%",borderRadius:2,background:targets.length>=goalAccounts?C.green:C.amber,width:`${Math.min(100,targets.length/goalAccounts*100)}%`}}/></div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24,color:C.coral}}>{fmt(goalPipeline)}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Pipeline Target</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24}}>{Math.round(confirmed/targets.length*100)}%</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Outreach Rate</div><div style={{height:4,borderRadius:2,background:C.borderLight,marginTop:8,overflow:"hidden"}}><div style={{height:"100%",borderRadius:2,background:C.green,width:`${Math.round((confirmed+outreach)/targets.length*100)}%`}}/></div></div>
    </div>

    {/* Target account table */}
    <div className="card" style={{marginBottom:16}}>
      <div className="card-p" style={{display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:`1px solid ${C.borderLight}`,paddingBottom:12,marginBottom:12}}>
        <div style={{fontSize:14,fontWeight:700}}>Target Account Hitlist - {ev.name}</div>
        <button onClick={addTarget} style={{padding:"6px 14px",fontSize:12,fontWeight:700,borderRadius:8,border:`1px solid ${C.coral}`,background:C.coral,color:"#fff",cursor:"pointer",fontFamily:"var(--sans)"}}>+ Add Target</button>
      </div>
      <div className="card-p" style={{paddingTop:0}}>
        {targets.map((t,i)=>(
          <div key={t.id} style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1.5fr 1fr auto",gap:12,alignItems:"center",padding:"10px 0",borderBottom:i<targets.length-1?`1px solid ${C.borderLight}`:"none"}}>
            <div><div style={{fontWeight:700,fontSize:13}}>{t.acc}</div></div>
            <div style={{fontSize:12,color:C.warmGray,fontWeight:500}}>{t.owner}</div>
            <Badge type={t.priority==="Critical"?"coral":t.priority==="High"?"amber":"gray"}>{t.priority}</Badge>
            <div style={{fontSize:12,color:C.warmGray,fontWeight:500}}>{t.goal}</div>
            <Badge type={t.status==="Meeting confirmed"?"green":t.status==="Outreach sent"?"amber":"gray"}>{t.status}</Badge>
            <div style={{display:"flex",gap:4}}>
              <button onClick={()=>{const prev=t.status==="Meeting confirmed"?"Outreach sent":t.status==="Outreach sent"?"Not started":t.status;if(prev!==t.status){setTargets(targets.map(x=>x.id===t.id?{...x,status:prev}:x));toast("Moved back to "+prev);}}} disabled={t.status==="Not started"} style={{padding:"4px 8px",fontSize:11,fontWeight:700,borderRadius:6,border:`1px solid ${t.status==="Not started"?C.borderLight:C.border}`,background:"#fff",cursor:t.status==="Not started"?"default":"pointer",fontFamily:"var(--sans)",color:t.status==="Not started"?C.borderLight:C.warmGray,opacity:t.status==="Not started"?.4:1}}>
                <svg width="10" height="10" viewBox="0 0 10 10"><path d="M6 2L3 5l3 3" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button onClick={()=>{const next=t.status==="Not started"?"Outreach sent":t.status==="Outreach sent"?"Meeting confirmed":t.status;if(next!==t.status){setTargets(targets.map(x=>x.id===t.id?{...x,status:next,contacted:true}:x));toast("Advanced to "+next);}}} disabled={t.status==="Meeting confirmed"} style={{padding:"4px 8px",fontSize:11,fontWeight:700,borderRadius:6,border:`1px solid ${t.status==="Meeting confirmed"?C.green+"50":C.coral}`,background:t.status==="Meeting confirmed"?"#fff":C.coralSoft,cursor:t.status==="Meeting confirmed"?"default":"pointer",fontFamily:"var(--sans)",color:t.status==="Meeting confirmed"?C.green:C.coral,opacity:t.status==="Meeting confirmed"?.5:1}}>
                <svg width="10" height="10" viewBox="0 0 10 10"><path d="M4 2l3 3-3 3" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button onClick={()=>{setTargets(targets.filter(x=>x.id!==t.id));toast("Target removed");}} style={{padding:"4px 8px",fontSize:11,fontWeight:700,borderRadius:6,border:`1px solid ${C.borderLight}`,background:"#fff",cursor:"pointer",fontFamily:"var(--sans)",color:C.warmGrayLight}}>
                <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2.5 2.5l5 5M7.5 2.5l-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Pre-event timeline */}
    <div className="card card-p">
      <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>Event Countdown</div>
      <div style={{display:"flex",gap:0}}>
        {["8 weeks","6 weeks","4 weeks","2 weeks","1 week","Event Day","Post-Event"].map((phase,i)=>(
          <div key={i} style={{flex:1,textAlign:"center",position:"relative"}}>
            <div style={{height:4,background:i<=3?C.coral:C.borderLight,borderRadius:i===0?"2px 0 0 2px":i===6?"0 2px 2px 0":"0"}}/>
            <div style={{width:14,height:14,borderRadius:"50%",background:i<=3?C.coral:"#fff",border:i<=3?"none":`2px solid ${C.borderLight}`,position:"absolute",top:-5,left:"50%",transform:"translateX(-50%)"}}/>
            <div style={{fontSize:9,fontWeight:i===3?800:500,color:i<=3?C.ink:C.warmGrayLight,marginTop:12,textTransform:"uppercase",letterSpacing:".2px"}}>{phase}</div>
            <div style={{fontSize:10,color:C.warmGray,marginTop:2,fontWeight:500}}>{["Sponsor","Announce","Outreach","Confirm","Brief","Execute","Follow-up"][i]}</div>
          </div>
        ))}
      </div>
    </div>
    </>}
  </div>);
};

// 14. SANKEY / EVENT FLOW - Account flow from first event touch to revenue
const FlowPage = () => {
  // Simulate Sankey as horizontal stepped flow
  const stages = [
    {name:"First Event Touch",count:10,accounts:ACCOUNTS.map(a=>a.name),color:C.coral},
    {name:"Second+ Event",count:7,accounts:ACCOUNTS.filter(a=>a.events.length>=2).map(a=>a.name),color:C.roseDeep},
    {name:"Meeting Held",count:8,accounts:ACCOUNTS.filter(a=>a.meetings>=3).map(a=>a.name),color:C.amber},
    {name:"Pipeline Created",count:6,accounts:ACCOUNTS.filter(a=>a.stage==="Pipeline"||a.stage==="Accelerated"||a.stage==="Closing").map(a=>a.name),color:"#8B7355"},
    {name:"Accelerated",count:3,accounts:ACCOUNTS.filter(a=>a.stage==="Accelerated"||a.stage==="Closing").map(a=>a.name),color:C.inkLight},
    {name:"Closed-Won",count:1,accounts:["Summit Healthcare Partners"],color:C.green},
  ];
  const maxCount = 10;
  const totalPipe = "$17.3M";
  const totalRev = "$8.9M";

  return (<div className="pg">
    <div className="pg-head"><h2>Event Flow</h2><p>How accounts move from first event touch through pipeline to revenue</p></div>

    {/* Summary strip */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20}}>
      {[{l:"Accounts Touched",v:"10",c:C.ink},{l:"Multi-Event Engaged",v:"7",c:C.roseDeep},{l:"Pipeline Created",v:totalPipe,c:C.coral},{l:"Revenue Won",v:totalRev,c:C.green}].map((m,i)=>(
        <div key={i} className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24,color:m.c}}>{m.v}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>{m.l}</div></div>
      ))}
    </div>

    {/* Flow visualization */}
    <div className="card card-p" style={{marginBottom:16}}>
      <div style={{fontSize:14,fontWeight:700,marginBottom:4}}>Account Flow Visualization</div>
      <div style={{fontSize:12,color:C.warmGrayLight,marginBottom:20,fontWeight:500}}>Width represents volume of accounts at each stage</div>
      <div style={{display:"flex",alignItems:"stretch",gap:4,height:240}}>
        {stages.map((stg,i)=>{
          const height = Math.max(20, (stg.count/maxCount)*200);
          return (<div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",position:"relative"}}>
            {/* Bar */}
            <div style={{width:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",flex:1}}>
              <div style={{width:"80%",height:height,background:`${stg.color}18`,border:`2px solid ${stg.color}`,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",position:"relative",transition:"all .3s"}}>
                <span style={{fontFamily:"var(--serif)",fontSize:22,color:stg.color,fontWeight:400}}>{stg.count}</span>
              </div>
            </div>
            {/* Connector arrow */}
            {i<stages.length-1&&<div style={{position:"absolute",right:-8,top:"50%",transform:"translateY(-50%)",color:C.borderLight,fontSize:16,zIndex:1}}>→</div>}
            {/* Label */}
            <div style={{marginTop:10,textAlign:"center"}}>
              <div style={{fontSize:11,fontWeight:700,color:stg.color}}>{stg.name}</div>
              <div style={{fontSize:9,color:C.warmGrayLight,marginTop:2,fontWeight:500}}>{Math.round(stg.count/maxCount*100)}% of total</div>
            </div>
          </div>);
        })}
      </div>
    </div>

    {/* Conversion rates between stages */}
    <div className="card card-p" style={{marginBottom:16}}>
      <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>Stage Conversion Rates</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:8}}>
        {stages.slice(0,-1).map((stg,i)=>{
          const next = stages[i+1];
          const rate = Math.round(next.count/stg.count*100);
          return (<div key={i} style={{background:C.petal,borderRadius:8,padding:"12px 8px",textAlign:"center"}}>
            <div style={{fontSize:10,fontWeight:700,color:C.warmGrayLight,textTransform:"uppercase",letterSpacing:".3px",marginBottom:4}}>{stg.name.split(" ").slice(0,2).join(" ")} →</div>
            <div style={{fontFamily:"var(--serif)",fontSize:24,color:rate>=70?C.green:rate>=40?C.amber:C.coral}}>{rate}%</div>
            <div style={{fontSize:10,color:C.warmGray,fontWeight:500,marginTop:2}}>{stg.count} → {next.count}</div>
          </div>);
        })}
      </div>
    </div>

    {/* Accounts at each stage */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
      {stages.filter(s=>s.accounts.length<=5).slice(3).map(stg=>(
        <div key={stg.name} className="card card-p">
          <div style={{fontSize:13,fontWeight:700,marginBottom:8,color:stg.color}}>{stg.name}</div>
          {stg.accounts.map((a,i)=><div key={i} style={{fontSize:12,padding:"4px 0",borderBottom:i<stg.accounts.length-1?`1px solid ${C.borderLight}`:"none",fontWeight:500}}>{a}</div>)}
        </div>
      ))}
    </div>
  </div>);
};

// 15. POST-EVENT PLAYBOOKS - Automated follow-up workflows
const PlaybookPage = ({toast}) => {
  const [tasks, setTasks] = useState([
    {id:"pb1",type:"Critical Follow-up",desc:"Send executive summary to Dr. Lisa Chen (Meridian Health)",owner:"Sarah Chen",due:"Within 24 hours",status:"completed",event:"HIMSS 2025"},
    {id:"pb2",type:"Critical Follow-up",desc:"Send expansion proposal to Robert Kim (Summit Healthcare)",owner:"Marcus Rivera",due:"Within 24 hours",status:"completed",event:"Executive Dinner - NYC"},
    {id:"pb3",type:"Demo Scheduled",desc:"Technical demo for James Morrison (Apex Financial)",owner:"Marcus Rivera",due:"Within 48 hours",status:"in-progress",event:"RSAC 2025"},
    {id:"pb4",type:"Trial Setup",desc:"Provision trial environment for Elena Volkov (Ironclad)",owner:"Jordan Park",due:"Within 48 hours",status:"in-progress",event:"RSAC 2025"},
    {id:"pb5",type:"Content Send",desc:"Send district case studies to Tom Hartley (BrightPath)",owner:"Marcus Rivera",due:"Within 1 week",status:"pending",event:"ASU+GSV Summit"},
    {id:"pb6",type:"Multi-year Proposal",desc:"Prepare multi-year pricing for Sarah Blackwell (Atlas Cloud)",owner:"Sarah Chen",due:"Within 1 week",status:"pending",event:"Executive Dinner - NYC"},
    {id:"pb7",type:"Comp Intel Brief",desc:"Brief sales team on Palo Alto competitive activity at RSAC",owner:"Jordan Park",due:"Within 24 hours",status:"completed",event:"RSAC 2025"},
    {id:"pb8",type:"Reference Request",desc:"Invite Dr. Amy Wu (Summit Healthcare) to case study program",owner:"Marcus Rivera",due:"Within 2 weeks",status:"pending",event:"CIO Roundtable"},
  ]);

  const toggle = (id) => {
    setTasks(tasks.map(t=>t.id===id?{...t,status:t.status==="pending"?"in-progress":t.status==="in-progress"?"completed":"pending"}:t));
    toast("Task updated");
  };

  const completed = tasks.filter(t=>t.status==="completed").length;
  const byEvent = {};
  tasks.forEach(t=>{if(!byEvent[t.event])byEvent[t.event]=[];byEvent[t.event].push(t);});

  return (<div className="pg">
    <div className="pg-head"><h2>Post-Event Playbooks</h2><p>Automated follow-up workflows generated from meeting outcomes</p></div>

    {/* Progress */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:16}}>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:28,color:C.green}}>{completed}/{tasks.length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Tasks Complete</div><div style={{height:4,borderRadius:2,background:C.borderLight,marginTop:8,overflow:"hidden"}}><div style={{height:"100%",borderRadius:2,background:C.green,width:`${completed/tasks.length*100}%`}}/></div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:28,color:C.amber}}>{tasks.filter(t=>t.status==="in-progress").length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>In Progress</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:28,color:C.coral}}>{tasks.filter(t=>t.status==="pending").length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Pending</div></div>
    </div>

    {/* Tasks grouped by event */}
    {Object.entries(byEvent).map(([event, eventTasks])=>(
      <div key={event} className="card" style={{marginBottom:12}}>
        <div className="card-p" style={{paddingBottom:8,borderBottom:`1px solid ${C.borderLight}`}}>
          <div style={{fontSize:14,fontWeight:700}}>{event}</div>
          <div style={{fontSize:11,color:C.warmGrayLight,fontWeight:500}}>{eventTasks.filter(t=>t.status==="completed").length} of {eventTasks.length} complete</div>
        </div>
        <div className="card-p" style={{paddingTop:4}}>
          {eventTasks.map(t=>(
            <div key={t.id} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer"}} onClick={()=>toggle(t.id)}>
              <div style={{width:22,height:22,borderRadius:6,border:`2px solid ${t.status==="completed"?C.green:t.status==="in-progress"?C.amber:C.border}`,background:t.status==="completed"?C.green:"#fff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {t.status==="completed"&&<svg width="12" height="12" viewBox="0 0 12 12"><path d="M3 6l2.5 2.5L9 4" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                {t.status==="in-progress"&&<div style={{width:8,height:8,borderRadius:3,background:C.amber}}/>}
              </div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:13,textDecoration:t.status==="completed"?"line-through":"none",color:t.status==="completed"?C.warmGrayLight:C.ink}}>{t.desc}</div>
                <div style={{fontSize:11,color:C.warmGrayLight,fontWeight:500,marginTop:1}}>{t.type} · {t.owner} · {t.due}</div>
              </div>
              <Badge type={t.status==="completed"?"green":t.status==="in-progress"?"amber":"gray"}>{t.status==="in-progress"?"In Progress":t.status==="completed"?"Done":"Pending"}</Badge>
            </div>
          ))}
        </div>
      </div>
    ))}
  </div>);
};

// 16. INTELLIGENCE FEED - Live, contextual signal stream
const FeedPage = ({nav}) => {
  const signals = [
    {id:"s1",type:"opportunity",time:"12 min ago",title:"Summit Healthcare moving to contract review",body:"Robert Kim (CEO) confirmed verbal commitment at NYC dinner. Legal reviewing MSA. Expected close by July 31.",link:{page:"opp-det",id:"opp4"},priority:"critical",account:"Summit Healthcare Partners"},
    {id:"s2",type:"competitive",time:"2 hours ago",title:"Palo Alto Networks targeting Apex Financial",body:"Competitive displacement campaign detected at RSAC. Apex CISO received direct outreach. Recommend immediate executive engagement.",link:{page:"acc-det",id:"acc2"},priority:"critical",account:"Apex Financial Group"},
    {id:"s3",type:"registration",time:"4 hours ago",title:"3 target accounts registered for HLTH 2025",body:"Meridian Health, Vanguard Medical, and NovaTech Solutions confirmed registration. Pre-event outreach window opens now.",link:{page:"pre-event",id:null},priority:"high",account:"Multiple"},
    {id:"s4",type:"meeting",time:"Yesterday",title:"Atlas Cloud CTO requested multi-year proposal",body:"Sarah Blackwell asked about enterprise licensing and volume discounts at NYC dinner. Strong buying signal - AWS contract up for renewal.",link:{page:"m-det",id:"m7"},priority:"high",account:"Atlas Cloud Infrastructure"},
    {id:"s5",type:"insight",time:"Yesterday",title:"Healthcare conferences outperforming Q1 forecast",body:"HIMSS + ViVE combined $4.45M influenced pipeline, 28% above Q1 forecast. Recommend increasing H1 healthcare event allocation.",link:{page:"insights",id:null},priority:"medium",account:null},
    {id:"s6",type:"followup",time:"2 days ago",title:"Follow-up overdue: NovaTech analytics demo",body:"Jordan Park has not completed scheduled technical demo with NovaTech. Original commitment was within 1 week of HIMSS. Now 3 weeks overdue.",link:{page:"acc-det",id:"acc3"},priority:"high",account:"NovaTech Solutions"},
    {id:"s7",type:"acceleration",time:"2 days ago",title:"Ironclad Security deal accelerated by 3 weeks",body:"RSAC meetings with VP Product led to trial approval. CrowdStrike contract expires Q4 - displacement window confirmed.",link:{page:"opp-det",id:"opp5"},priority:"medium",account:"Ironclad Security"},
    {id:"s8",type:"milestone",time:"3 days ago",title:"$15M cumulative pipeline influenced milestone",body:"Cipher has now tracked $15M in event-influenced pipeline across 9 events. That's 8.5x total event spend.",link:{page:"dashboard",id:null},priority:"medium",account:null},
  ];
  const typeColors = {opportunity:C.green,competitive:C.coral,registration:C.amber,meeting:C.roseDeep,insight:C.inkLight,followup:C.coral,acceleration:C.green,milestone:C.amber};
  const typeIcons = {opportunity:"opportunities",competitive:"sword",registration:"events",meeting:"meetings",insight:"insights",followup:"alert",acceleration:"trend",milestone:"performance"};

  return (<div className="pg">
    <div className="pg-head"><h2>Intelligence Feed</h2><p>Live signals and contextual intelligence from your event data</p></div>

    {/* Urgency strip */}
    <div style={{display:"flex",gap:8,marginBottom:16}}>
      {[{l:"Urgent",count:signals.filter(s=>s.priority==="critical").length,c:C.coral},{l:"Action Needed",count:signals.filter(s=>s.priority==="high").length,c:C.amber},{l:"Informational",count:signals.filter(s=>s.priority==="medium").length,c:C.warmGray}].map((u,i)=>(
        <div key={i} className="card fade-up d1" style={{padding:"10px 16px",display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:8,height:8,borderRadius:"50%",background:u.c,boxShadow:u.c===C.coral?`0 0 6px ${u.c}40`:"none"}}/><span style={{fontFamily:"var(--serif)",fontSize:18}}>{u.count}</span><span style={{fontSize:11.5,color:C.warmGray,fontWeight:600}}>{u.l}</span>
        </div>
      ))}
    </div>

    <div style={{maxWidth:760}}>
      {signals.map((s,i)=>(
        <div key={s.id} className={`card fade-up d${(i%4)+1}`} style={{marginBottom:10,cursor:"pointer",borderLeft:`3px solid ${typeColors[s.type]}`}} onClick={()=>s.link&&nav(s.link.page,s.link.id)}>
          <div className="card-p">
            <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
              <div style={{width:32,height:32,borderRadius:8,background:`${typeColors[s.type]}12`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2}}>
                <Icon name={typeIcons[s.type]} size={16} color={typeColors[s.type]}/>
              </div>
              <div style={{flex:1}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:3}}>
                  <div style={{fontWeight:700,fontSize:14}}>{s.title}</div>
                  <div style={{display:"flex",gap:6,alignItems:"center",flexShrink:0}}>
                    <span style={{fontSize:11,color:C.warmGrayLight,fontWeight:500}}>{s.time}</span>
                    {s.priority==="critical"&&<Badge type="coral">Urgent</Badge>}
                  </div>
                </div>
                <div style={{fontSize:12.5,color:C.warmGray,lineHeight:1.55,fontWeight:500}}>{s.body}</div>
                {s.account&&<div style={{fontSize:11,color:C.warmGrayLight,fontWeight:600,marginTop:6}}>{s.account}</div>}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>);
};

// 17. CALENDAR HEATMAP - Event activity density
const CalendarPage = () => {
  // Generate 52 weeks x 7 days of activity data
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const eventWeeks = {3:4,7:3,9:5,13:4,14:3,16:5,17:4,20:2,24:3,28:2,29:3,37:4,38:3,42:3};
  const weeks = Array.from({length:52},(_,w)=>{
    const intensity = eventWeeks[w]||0;
    return {week:w,intensity,month:months[Math.floor(w/4.33)]};
  });

  return (<div className="pg">
    <div className="pg-head"><h2>Event Calendar</h2><p>Activity density and event presence across the year</p></div>

    {/* Heatmap */}
    <div className="card card-p" style={{marginBottom:16}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
        <div><div style={{fontSize:14,fontWeight:700}}>2025 Event Activity</div><div style={{fontSize:12,color:C.warmGrayLight,fontWeight:500}}>Darker cells indicate higher event activity</div></div>
        <div style={{display:"flex",gap:4,alignItems:"center",fontSize:10,color:C.warmGrayLight,fontWeight:600}}>
          <span>Less</span>
          {[0,1,2,3,4,5].map(i=><div key={i} style={{width:12,height:12,borderRadius:3,background:i===0?C.borderLight:`rgba(204,107,133,${i*0.2})`}}/>)}
          <span>More</span>
        </div>
      </div>
      <div style={{display:"flex",gap:2,overflowX:"auto",paddingBottom:8}}>
        {weeks.map(w=>(
          <div key={w.week} style={{display:"flex",flexDirection:"column",gap:2}}>
            {[0,1,2,3,4].map(d=>(
              <div key={d} style={{width:14,height:14,borderRadius:3,background:w.intensity===0?C.borderLight:`rgba(204,107,133,${Math.min(1,w.intensity*0.2)})`,cursor:"pointer",transition:"transform .1s"}}
                title={`Week ${w.week+1}: ${w.intensity>0?w.intensity+" activities":"No activity"}`}
                onMouseOver={e=>e.target.style.transform="scale(1.3)"} onMouseOut={e=>e.target.style.transform="scale(1)"}/>
            ))}
          </div>
        ))}
      </div>
      {/* Month labels */}
      <div style={{display:"flex",marginTop:4}}>
        {months.map((m,i)=><div key={i} style={{flex:1,fontSize:10,color:C.warmGrayLight,fontWeight:600,textAlign:"center"}}>{m}</div>)}
      </div>
    </div>

    {/* Event timeline */}
    <div className="card card-p">
      <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>Event Schedule</div>
      <div style={{position:"relative"}}>
        {EVENTS.sort((a,b)=>new Date(a.date)-new Date(b.date)).map((e,i)=>(
          <div key={e.id} style={{display:"flex",gap:14,alignItems:"center",padding:"10px 0",borderBottom:i<EVENTS.length-1?`1px solid ${C.borderLight}`:"none"}}>
            <div style={{width:48,textAlign:"center",flexShrink:0}}>
              <div style={{fontSize:18,fontWeight:700,fontFamily:"var(--serif)",lineHeight:1}}>{new Date(e.date).getDate()}</div>
              <div style={{fontSize:10,color:C.warmGrayLight,fontWeight:600,textTransform:"uppercase"}}>{new Date(e.date).toLocaleDateString("en-US",{month:"short"})}</div>
            </div>
            <div style={{width:4,height:36,borderRadius:2,background:e.status==="Completed"?C.green:C.amber,flexShrink:0}}/>
            <div style={{flex:1}}>
              <div style={{fontWeight:700,fontSize:13}}>{e.name}</div>
              <div style={{fontSize:11,color:C.warmGray,fontWeight:500}}>{e.location} · {e.type}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:12,fontWeight:700}}>{fmt(e.spend)}</div>
              <div style={{fontSize:10,color:C.warmGrayLight,fontWeight:500}}>{e.meetings} meetings</div>
            </div>
            <Badge type={e.status==="Completed"?"green":"amber"}>{e.status}</Badge>
          </div>
        ))}
      </div>
    </div>
  </div>);
};

const SettingsPage = ({toast}) => {
  const [sfConnected, setSfConnected] = useState(true);
  const [hubConnected, setHubConnected] = useState(false);
  return (<div className="pg">
  <div className="pg-head"><h2>Settings</h2><p>Configure your Cipher workspace</p></div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,maxWidth:900}}>
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div className="card card-p">
        <h3 style={{fontFamily:"var(--serif)",fontSize:17,marginBottom:14}}>ROI Score Weights</h3>
        {[{l:"Pipeline Influenced",w:30},{l:"Sourced Pipeline",w:25},{l:"Opps Accelerated",w:20},{l:"Account Engagement",w:15},{l:"Meeting Quality",w:10}].map((w,i)=>(
          <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:i<4?`1px solid ${C.borderLight}`:"none"}}>
            <span style={{fontSize:13,fontWeight:600}}>{w.l}</span>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:60,height:4,borderRadius:2,background:C.borderLight,overflow:"hidden"}}><div style={{height:"100%",width:`${w.w*3.3}%`,borderRadius:2,background:C.coral}}/></div>
              <span style={{fontWeight:700,fontSize:13,color:C.coral,width:30,textAlign:"right"}}>{w.w}%</span>
            </div>
          </div>
        ))}
      </div>
      <div className="card card-p">
        <h3 style={{fontFamily:"var(--serif)",fontSize:17,marginBottom:14}}>Workspace</h3>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`}}><span style={{fontSize:13,fontWeight:600}}>Organization</span><span style={{fontSize:13}}>Cipher Demo Corp</span></div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`}}><span style={{fontSize:13,fontWeight:600}}>Plan</span><Badge type="coral">Pro Trial - 14 days</Badge></div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`}}><span style={{fontSize:13,fontWeight:600}}>Monthly price</span><span style={{fontSize:13,fontWeight:700}}>$1,190<span style={{fontWeight:500,color:C.warmGrayLight}}>/mo</span></span></div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0"}}><span style={{fontSize:13,fontWeight:600}}>Team</span><span style={{fontSize:13}}>3 of 8 seats</span></div>
      </div>
    </div>
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div className="card card-p">
        <h3 style={{fontFamily:"var(--serif)",fontSize:17,marginBottom:14}}>Data Connections</h3>
        {/* Salesforce - connected */}
        <div style={{padding:"12px",borderRadius:10,border:`1px solid ${sfConnected?C.green+"30":C.borderLight}`,background:sfConnected?"rgba(45,138,86,0.04)":"#fff",marginBottom:10}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:28,height:28,borderRadius:6,background:"#00A1E0",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:"#fff"}}>SF</div><div><div style={{fontSize:13,fontWeight:700}}>Salesforce</div><div style={{fontSize:10,color:sfConnected?C.green:C.warmGrayLight,fontWeight:600}}>{sfConnected?"Connected":"Not connected"}</div></div></div>
            <button onClick={()=>{setSfConnected(!sfConnected);toast(sfConnected?"Salesforce disconnected":"Salesforce connected")}} style={{padding:"5px 12px",fontSize:11,fontWeight:700,borderRadius:6,border:`1px solid ${sfConnected?C.border:C.coral}`,background:sfConnected?"#fff":C.coral,color:sfConnected?C.warmGray:"#fff",cursor:"pointer",fontFamily:"var(--sans)"}}>{sfConnected?"Disconnect":"Connect"}</button>
          </div>
          {sfConnected&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:8}}>
            <div style={{background:"rgba(45,138,86,0.06)",borderRadius:6,padding:"6px 8px"}}><div style={{fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:".4px",color:C.warmGrayLight}}>Last synced</div><div style={{fontSize:12,fontWeight:600}}>2 min ago</div></div>
            <div style={{background:"rgba(45,138,86,0.06)",borderRadius:6,padding:"6px 8px"}}><div style={{fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:".4px",color:C.warmGrayLight}}>Records synced</div><div style={{fontSize:12,fontWeight:600}}>2,847</div></div>
            <div style={{background:"rgba(45,138,86,0.06)",borderRadius:6,padding:"6px 8px"}}><div style={{fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:".4px",color:C.warmGrayLight}}>Mapped fields</div><div style={{fontSize:12,fontWeight:600}}>18 of 24</div></div>
            <div style={{background:"rgba(45,138,86,0.06)",borderRadius:6,padding:"6px 8px"}}><div style={{fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:".4px",color:C.warmGrayLight}}>Sync status</div><div style={{fontSize:12,fontWeight:600,color:C.green}}>Healthy</div></div>
          </div>}
        </div>
        {/* HubSpot */}
        <div style={{padding:"12px",borderRadius:10,border:`1px solid ${hubConnected?C.green+"30":C.borderLight}`,background:hubConnected?"rgba(45,138,86,0.04)":"#fff",marginBottom:10}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:28,height:28,borderRadius:6,background:"#FF7A59",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:"#fff"}}>HS</div><div><div style={{fontSize:13,fontWeight:700}}>HubSpot</div><div style={{fontSize:10,color:hubConnected?C.green:C.warmGrayLight,fontWeight:600}}>{hubConnected?"Connected":"Not connected"}</div></div></div>
            <button onClick={()=>{setHubConnected(!hubConnected);toast(hubConnected?"HubSpot disconnected":"HubSpot connected")}} style={{padding:"5px 12px",fontSize:11,fontWeight:700,borderRadius:6,border:`1px solid ${hubConnected?C.border:C.coral}`,background:hubConnected?"#fff":C.coral,color:hubConnected?C.warmGray:"#fff",cursor:"pointer",fontFamily:"var(--sans)"}}>{hubConnected?"Disconnect":"Connect"}</button>
          </div>
        </div>
        {/* Others */}
        {[{n:"Granola",bg:"#1A1A1A",ab:"GR",desc:"Meeting intelligence via Zapier"},{n:"Slack",bg:"#4A154B",ab:"SL"},{n:"Google Calendar",bg:"#4285F4",ab:"GC"},{n:"Marketo",bg:"#5C4C9F",ab:"MK"}].map((s,i)=>(
          <div key={s.n} style={{padding:"12px",borderRadius:10,border:`1px solid ${C.borderLight}`,marginBottom:i<3?10:0,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:28,height:28,borderRadius:6,background:s.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:"#fff"}}>{s.ab}</div><div><div style={{fontSize:13,fontWeight:700}}>{s.n}</div><div style={{fontSize:10,color:s.n==="Granola"?C.coral:C.warmGrayLight,fontWeight:600}}>{s.desc||"Coming soon"}</div></div></div>
            <Badge type={s.n==="Granola"?"coral":"gray"}>{s.n==="Granola"?"Beta":"Q2 2026"}</Badge>
          </div>
        ))}
      </div>
    </div>
  </div>
</div>);
};

// --- DETAIL PAGES ---
const EventDetail = ({id,nav,toast,onNote,onMeeting,onShare}) => {
  const e=EVENTS.find(x=>x.id===id); if(!e) return <div className="pg">Not found</div>;
  const ms=MEETINGS.filter(m=>m.evId===id), as=ACCOUNTS.filter(a=>a.events.includes(id)), os=OPPORTUNITIES.filter(o=>o.events.includes(id)), cs=COMPETITORS.filter(c=>c.events.includes(id));
  const isPlanned = e.status==="Planned";
  const [tab, setTab] = useState(isPlanned?"planning":"performance");

  // Planning state
  const [targets, setTargets] = useState([
    {id:"t1",acc:"Meridian Health Systems",owner:"Sarah Chen",status:"Outreach sent",priority:"Critical",goal:"Executive dinner invite"},
    {id:"t2",acc:"Apex Financial Group",owner:"Marcus Rivera",status:"Meeting confirmed",priority:"High",goal:"CISO 1:1 briefing"},
    {id:"t3",acc:"NovaTech Solutions",owner:"Jordan Park",status:"Not started",priority:"Medium",goal:"Product demo"},
  ]);
  // Playbook state
  const [tasks, setTasks] = useState([
    {id:"pb1",desc:"Send executive summary to key contacts",owner:"Sarah Chen",due:"Within 24 hours",status:"completed"},
    {id:"pb2",desc:"Schedule follow-up demos for interested accounts",owner:"Marcus Rivera",due:"Within 48 hours",status:"in-progress"},
    {id:"pb3",desc:"Brief sales team on competitive observations",owner:"Jordan Park",due:"Within 24 hours",status:"completed"},
    {id:"pb4",desc:"Send case studies to engaged prospects",owner:"Sarah Chen",due:"Within 1 week",status:"pending"},
  ]);

  const tabs = isPlanned ? ["planning","performance"] : ["performance","planning","follow-up"];

  return (<div className="pg">
    <div className="back" onClick={()=>nav("events")}>← Events</div>
    <div className="det-hero"><div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
      <div><h2>{e.name}</h2><div className="det-meta"><span style={{display:"flex",alignItems:"center",gap:4}}><Icon name="pin" size={13} color={C.warmGray}/> {e.location}</span><span style={{display:"flex",alignItems:"center",gap:4}}><Icon name="calendar" size={13} color={C.warmGray}/> {new Date(e.date).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}</span><Badge type="ink">{e.type}</Badge><Badge type={e.status==="Completed"?"green":"amber"}>{e.status}</Badge></div>
        <ActionBar onNote={()=>onNote(e.name)} onMeeting={onMeeting} onShare={()=>onShare(e.name)}/>
      </div>
      <ScoreRing score={e.roi} size={64}/>
    </div></div>

    {/* Tabs */}
    <div style={{display:"flex",gap:0,borderBottom:`1px solid ${C.borderLight}`,marginBottom:18}}>
      {tabs.map(t=><button key={t} onClick={()=>setTab(t)} style={{padding:"10px 20px",fontSize:13,fontWeight:tab===t?700:500,color:tab===t?C.coral:C.warmGray,borderBottom:tab===t?`2px solid ${C.coral}`:"2px solid transparent",background:"none",border:"none",borderBottomStyle:"solid",borderBottomWidth:2,borderBottomColor:tab===t?C.coral:"transparent",cursor:"pointer",fontFamily:"var(--sans)",textTransform:"capitalize",transition:"all .15s"}}>{t==="follow-up"?"Follow-up":t}</button>)}
    </div>

    {/* PERFORMANCE TAB */}
    {tab==="performance"&&<>
    <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:10,marginBottom:18}}>{[{l:"Spend",v:fmt(e.spend)},{l:"Meetings",v:e.meetings},{l:"Accounts",v:e.accounts},{l:"Pipeline",v:fmt(e.pipeInfluenced),c:C.coral},{l:"Sourced",v:fmt(e.pipeSourced)},{l:"Revenue",v:fmt(e.revenue),c:C.green}].map((m,i)=>(<div key={i} className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:20,color:m.c||C.ink}}>{m.v}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",marginTop:2}}>{m.l}</div></div>))}</div>
    <div className="det-grid">
      <div>
        <div className="det-section"><h3>Meetings ({ms.length})</h3>{ms.length?ms.map(m=>(<div key={m.id} style={{padding:"10px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer",display:"flex",justifyContent:"space-between"}} onClick={()=>nav("m-det",m.id)}><div><div style={{fontWeight:600,fontSize:13}}>{m.contact} - {m.company}</div><div style={{fontSize:11.5,color:C.warmGray}}>{m.role} · {m.type}</div></div><Badge type={m.priority==="Critical"?"coral":"amber"}>{m.priority}</Badge></div>)):<div style={{padding:20,textAlign:"center",color:C.warmGrayLight,fontSize:13}}>No meetings recorded yet</div>}</div>
        <div className="det-section"><h3>Engaged Accounts ({as.length})</h3>{as.map(a=>(<div key={a.id} style={{padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer",display:"flex",justifyContent:"space-between"}} onClick={()=>nav("acc-det",a.id)}><div><div style={{fontWeight:600,fontSize:13}}>{a.name}</div><div style={{fontSize:11,color:C.warmGray}}>{a.industry} · {a.segment}</div></div><Badge type={a.stage==="Closing"||a.stage==="Accelerated"?"green":a.stage==="Pipeline"?"amber":"gray"}>{a.stage}</Badge></div>))}</div>
        <div className="det-section"><h3>Influenced Opportunities ({os.length})</h3>{os.map(o=>(<div key={o.id} style={{padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer",display:"flex",justifyContent:"space-between"}} onClick={()=>nav("opp-det",o.id)}><div><div style={{fontWeight:600,fontSize:13}}>{o.name}</div><div style={{fontSize:11,color:C.warmGray}}>{o.account} · {fmt(o.amount)}</div></div><Badge type={o.stage==="Closing"?"green":"amber"}>{o.stage}</Badge></div>))}</div>
      </div>
      <div>
        <div className="det-section"><h3>Recommendation</h3><p style={{fontSize:13,lineHeight:1.6}}>{e.rec}</p></div>
        <div className="det-section"><h3>Notes</h3><p style={{fontSize:13,lineHeight:1.6,color:C.warmGray}}>{e.notes}</p></div>
        {cs.length>0&&<div className="det-section"><h3>Competitor Intel</h3>{cs.map(c=>(<div key={c.id} style={{marginBottom:10}}><div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontWeight:600,fontSize:13}}>{c.name}</span><Badge type={c.threat==="Critical"?"coral":"amber"}>{c.threat}</Badge></div><div style={{fontSize:12,color:C.warmGray,marginTop:2}}>{c.notes}</div></div>))}</div>}
        <AttrBox/>
      </div>
    </div>
    </>}

    {/* PLANNING TAB */}
    {tab==="planning"&&<>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:16}}>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24}}>{targets.filter(t=>t.status==="Meeting confirmed").length}/{targets.length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Meetings Confirmed</div><div style={{height:4,borderRadius:2,background:C.borderLight,marginTop:8,overflow:"hidden"}}><div style={{height:"100%",borderRadius:2,background:C.green,width:`${targets.filter(t=>t.status==="Meeting confirmed").length/Math.max(1,targets.length)*100}%`}}/></div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24}}>{Math.round((targets.filter(t=>t.status!=="Not started").length)/Math.max(1,targets.length)*100)}%</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Outreach Rate</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24}}>{targets.length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Target Accounts</div></div>
    </div>
    <div className="card">
      <div className="card-p" style={{display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:`1px solid ${C.borderLight}`,paddingBottom:12,marginBottom:0}}>
        <div style={{fontSize:14,fontWeight:700}}>Target Account Hitlist</div>
        <button onClick={()=>{const accs=ACCOUNTS.filter(a=>!targets.find(t=>t.acc===a.name));if(accs.length){setTargets([...targets,{id:"t"+(targets.length+1),acc:accs[0].name,owner:accs[0].owner,status:"Not started",priority:"Medium",goal:"Discovery"}]);toast("Target added");}}} style={{padding:"6px 14px",fontSize:12,fontWeight:700,borderRadius:8,border:"none",background:C.coral,color:"#fff",cursor:"pointer",fontFamily:"var(--sans)"}}>+ Add Target</button>
      </div>
      <div className="card-p" style={{paddingTop:8}}>
        {targets.map((t,i)=>(
          <div key={t.id} style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1.5fr 1fr auto",gap:10,alignItems:"center",padding:"10px 0",borderBottom:i<targets.length-1?`1px solid ${C.borderLight}`:"none"}}>
            <div style={{fontWeight:700,fontSize:13}}>{t.acc}</div>
            <div style={{fontSize:12,color:C.warmGray,fontWeight:500}}>{t.owner}</div>
            <Badge type={t.priority==="Critical"?"coral":t.priority==="High"?"amber":"gray"}>{t.priority}</Badge>
            <div style={{fontSize:12,color:C.warmGray,fontWeight:500}}>{t.goal}</div>
            <Badge type={t.status==="Meeting confirmed"?"green":t.status==="Outreach sent"?"amber":"gray"}>{t.status}</Badge>
            <div style={{display:"flex",gap:3}}>
              <button onClick={()=>{const prev=t.status==="Meeting confirmed"?"Outreach sent":t.status==="Outreach sent"?"Not started":t.status;if(prev!==t.status){setTargets(targets.map(x=>x.id===t.id?{...x,status:prev}:x));toast("Moved back");}}} disabled={t.status==="Not started"} style={{padding:"3px 7px",fontSize:10,borderRadius:5,border:`1px solid ${t.status==="Not started"?C.borderLight:C.border}`,background:"#fff",cursor:t.status==="Not started"?"default":"pointer",fontFamily:"var(--sans)",opacity:t.status==="Not started"?.3:1}}>
                <svg width="9" height="9" viewBox="0 0 10 10"><path d="M6 2L3 5l3 3" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button onClick={()=>{const next=t.status==="Not started"?"Outreach sent":t.status==="Outreach sent"?"Meeting confirmed":t.status;if(next!==t.status){setTargets(targets.map(x=>x.id===t.id?{...x,status:next}:x));toast("Advanced");}}} disabled={t.status==="Meeting confirmed"} style={{padding:"3px 7px",fontSize:10,borderRadius:5,border:`1px solid ${t.status==="Meeting confirmed"?C.green+"40":C.coral}`,background:t.status==="Meeting confirmed"?"#fff":C.coralSoft,cursor:t.status==="Meeting confirmed"?"default":"pointer",fontFamily:"var(--sans)",color:t.status==="Meeting confirmed"?C.green:C.coral,opacity:t.status==="Meeting confirmed"?.4:1}}>
                <svg width="9" height="9" viewBox="0 0 10 10"><path d="M4 2l3 3-3 3" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button onClick={()=>{setTargets(targets.filter(x=>x.id!==t.id));toast("Removed");}} style={{padding:"3px 7px",fontSize:10,borderRadius:5,border:`1px solid ${C.borderLight}`,background:"#fff",cursor:"pointer",fontFamily:"var(--sans)",color:C.warmGrayLight}}>
                <svg width="9" height="9" viewBox="0 0 10 10"><path d="M2.5 2.5l5 5M7.5 2.5l-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
    </>}

    {/* FOLLOW-UP TAB */}
    {tab==="follow-up"&&<>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:16}}>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24,color:C.green}}>{tasks.filter(t=>t.status==="completed").length}/{tasks.length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Tasks Complete</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24,color:C.amber}}>{tasks.filter(t=>t.status==="in-progress").length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>In Progress</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:24,color:C.coral}}>{tasks.filter(t=>t.status==="pending").length}</div><div style={{fontSize:10,color:C.warmGrayLight,textTransform:"uppercase",fontWeight:700,marginTop:2}}>Pending</div></div>
    </div>
    <div className="card card-p">
      {tasks.map((t,i)=>(
        <div key={t.id} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderBottom:i<tasks.length-1?`1px solid ${C.borderLight}`:"none",cursor:"pointer"}} onClick={()=>{setTasks(tasks.map(x=>x.id===t.id?{...x,status:x.status==="pending"?"in-progress":x.status==="in-progress"?"completed":"pending"}:x));toast("Task updated");}}>
          <div style={{width:20,height:20,borderRadius:6,border:`2px solid ${t.status==="completed"?C.green:t.status==="in-progress"?C.amber:C.border}`,background:t.status==="completed"?C.green:"#fff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            {t.status==="completed"&&<svg width="10" height="10" viewBox="0 0 12 12"><path d="M3 6l2.5 2.5L9 4" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
            {t.status==="in-progress"&&<div style={{width:7,height:7,borderRadius:3,background:C.amber}}/>}
          </div>
          <div style={{flex:1}}>
            <div style={{fontWeight:700,fontSize:13,textDecoration:t.status==="completed"?"line-through":"none",color:t.status==="completed"?C.warmGrayLight:C.ink}}>{t.desc}</div>
            <div style={{fontSize:11,color:C.warmGrayLight,fontWeight:500,marginTop:1}}>{t.owner} · {t.due}</div>
          </div>
          <Badge type={t.status==="completed"?"green":t.status==="in-progress"?"amber":"gray"}>{t.status==="in-progress"?"In Progress":t.status==="completed"?"Done":"Pending"}</Badge>
        </div>
      ))}
    </div>
    </>}
  </div>);
};

const AccDetail = ({id,nav,toast,onNote,onShare}) => {
  const a=ACCOUNTS.find(x=>x.id===id); if(!a) return <div className="pg">Not found</div>;
  const evs=EVENTS.filter(e=>a.events.includes(e.id)), ms=MEETINGS.filter(m=>m.accId===id), os=OPPORTUNITIES.filter(o=>o.accId===id);
  return (<div className="pg">
    <div className="back" onClick={()=>nav("accounts")}>← Accounts</div>
    <div className="det-hero"><div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
      <div><h2>{a.name}{a.target&&<span style={{color:C.coral,fontSize:11,marginLeft:8,fontWeight:800,fontFamily:"var(--sans)",textTransform:"uppercase",letterSpacing:".5px"}}> Target Account</span>}</h2><div className="det-meta"><span>{a.industry}</span><span>{a.segment}</span><span>{a.arr} ARR</span><span>Owner: <b>{a.owner}</b></span><Badge type="ink">{a.tier}</Badge></div><ActionBar onNote={()=>onNote(a.name)} onShare={()=>onShare(a.name)}/></div>
      <div style={{textAlign:"center"}}><div style={{width:48,height:48,borderRadius:"50%",background:a.health>=80?C.greenSoft:a.health>=50?C.amberSoft:C.coralSoft,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,fontWeight:700,color:a.health>=80?C.green:a.health>=50?C.amber:C.coral}}>{a.health}</div><div style={{fontSize:9,color:C.warmGrayLight,marginTop:3}}>HEALTH</div></div>
    </div></div>
    <div className="det-grid">
      <div>
        <div className="det-section"><h3>Event Timeline</h3>{evs.map(e=>(<div key={e.id} style={{padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}} onClick={()=>nav("ev-det",e.id)}><div><div style={{fontWeight:600,fontSize:13}}>{e.name}</div><div style={{fontSize:11,color:C.warmGray}}>{new Date(e.date).toLocaleDateString("en-US",{month:"short",year:"numeric"})} · {e.type}</div></div><ScoreRing score={e.roi} size={36}/></div>))}</div>
        <div className="det-section"><h3>Meetings ({ms.length})</h3>{ms.map(m=>(<div key={m.id} style={{padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer"}} onClick={()=>nav("m-det",m.id)}><div style={{fontWeight:600,fontSize:13}}>{m.contact} - {m.role}</div><div style={{fontSize:11,color:C.warmGray}}>{m.event} · {m.outcome}</div></div>))}</div>
        <div className="det-section"><h3>Opportunities ({os.length})</h3>{os.map(o=>(<div key={o.id} style={{padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer",display:"flex",justifyContent:"space-between"}} onClick={()=>nav("opp-det",o.id)}><div><div style={{fontWeight:600,fontSize:13}}>{o.name}</div><div style={{fontSize:11,color:C.warmGray}}>{fmt(o.amount)}</div></div><Badge type={o.stage==="Closing"?"green":"amber"}>{o.stage}</Badge></div>))}</div>
      </div>
      <div>
        <div className="det-section"><h3>Intelligence</h3><div className="det-f"><div className="det-fl">Competitor</div><div className="det-fv">{a.competitor}</div></div><div className="det-f"><div className="det-fl">Notes</div><div className="det-fv" style={{color:C.warmGray,lineHeight:1.6}}>{a.notes}</div></div></div>
        <AttrBox/>
      </div>
    </div>
  </div>);
};

const OppDetail = ({id,nav,toast,onNote,onShare}) => {
  const o=OPPORTUNITIES.find(x=>x.id===id); if(!o) return <div className="pg">Not found</div>;
  const evs=EVENTS.filter(e=>o.events.includes(e.id)), ms=MEETINGS.filter(m=>o.events.includes(m.evId)&&m.accId===o.accId);
  return (<div className="pg">
    <div className="back" onClick={()=>nav("opportunities")}>← Opportunities</div>
    <div className="det-hero"><h2>{o.name}</h2><div className="det-meta"><span style={{cursor:"pointer",color:C.coral}} onClick={()=>nav("acc-det",o.accId)}>{o.account}</span><Badge type={o.stage==="Closing"?"green":"amber"}>{o.stage}</Badge><span style={{fontFamily:"var(--serif)",fontSize:18}}>{fmt(o.amount)}</span><span>Owner: <b>{o.owner}</b></span><span>Close: {new Date(o.close).toLocaleDateString("en-US",{month:"long",day:"numeric"})}</span></div>
      <ActionBar onNote={()=>onNote(o.name)} onShare={()=>onShare(o.name)}/></div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:18}}>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:22}}>{o.confidence}%</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",marginTop:2}}>Confidence</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><div style={{fontFamily:"var(--serif)",fontSize:22}}>{o.events.length}</div><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",marginTop:2}}>Touchpoints</div></div>
      <div className="card card-p" style={{textAlign:"center"}}><Badge type={o.accel==="Accelerated"?"green":o.accel==="Stalled"?"coral":"gray"}>{o.accel}</Badge><div style={{fontSize:9,color:C.warmGrayLight,textTransform:"uppercase",marginTop:6}}>Acceleration</div></div>
    </div>
    <div className="det-grid">
      <div>
        <div className="det-section"><h3>Event Influence Timeline</h3>{evs.map((e,i)=>(<div key={e.id} style={{padding:"10px 0",borderBottom:`1px solid ${C.borderLight}`,display:"flex",gap:12,cursor:"pointer"}} onClick={()=>nav("ev-det",e.id)}><div style={{width:22,height:22,borderRadius:"50%",background:i===0?C.coral:C.rose,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,flexShrink:0}}>{i+1}</div><div><div style={{fontWeight:600,fontSize:13}}>{e.name}</div><div style={{fontSize:11,color:C.warmGray}}>{new Date(e.date).toLocaleDateString("en-US",{month:"long",year:"numeric"})} · {i===0?"Source Event":"Influence"}</div></div></div>))}</div>
        <div className="det-section"><h3>Meetings ({ms.length})</h3>{ms.map(m=>(<div key={m.id} style={{padding:"8px 0",borderBottom:`1px solid ${C.borderLight}`,cursor:"pointer"}} onClick={()=>nav("m-det",m.id)}><div style={{fontWeight:600,fontSize:13}}>{m.contact} - {m.role}</div><div style={{fontSize:11,color:C.warmGray}}>{m.event} · {m.outcome}</div></div>))}</div>
      </div>
      <div>
        <div className="det-section"><h3>Intelligence</h3><div className="det-f"><div className="det-fl">Source</div><div className="det-fv"><Badge type="rose">{o.source}</Badge></div></div><div className="det-f"><div className="det-fl">Source Event</div><div className="det-fv">{o.sourceEvent}</div></div><div className="det-f"><div className="det-fl">Notes</div><div className="det-fv" style={{color:C.warmGray,lineHeight:1.6}}>{o.notes}</div></div></div>
        <AttrBox/>
      </div>
    </div>
  </div>);
};

const MeetingDetail = ({id,nav,toast,onNote,onShare}) => {
  const m=MEETINGS.find(x=>x.id===id); if(!m) return <div className="pg">Not found</div>;
  return (<div className="pg">
    <div className="back" onClick={()=>nav("meetings")}>← Meetings</div>
    <div className="det-hero"><div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
      <div><h2>{m.contact}</h2><div className="det-meta"><span>{m.role} · <b style={{cursor:"pointer",color:C.coral}} onClick={()=>nav("acc-det",m.accId)}>{m.company}</b></span><span style={{display:"flex",alignItems:"center",gap:4}}><Icon name="calendar" size={13} color={C.warmGray}/> {new Date(m.date).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}</span><Badge type="ink">{m.event}</Badge><Badge type={m.priority==="Critical"?"coral":"amber"}>{m.priority}</Badge></div></div>
      <div style={{textAlign:"center"}}><div style={{width:48,height:48,borderRadius:"50%",background:m.sentiment>=85?C.greenSoft:m.sentiment>=60?C.amberSoft:C.coralSoft,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:700,color:m.sentiment>=85?C.green:m.sentiment>=60?C.amber:C.coral}}>{m.sentiment}</div><div style={{fontSize:9,color:C.warmGrayLight,marginTop:3}}>SENTIMENT</div></div>
    </div></div>
    <div className="det-grid">
      <div>
        <div className="det-section"><h3>Summary</h3><p style={{fontSize:13.5,lineHeight:1.7,color:C.warmGray}}>{m.summary}</p></div>
        <div className="det-section"><h3>Intelligence Card</h3>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            {[{l:"Buying Signals",v:m.signals},{l:"Objections",v:m.objections},{l:"Competitor Mentions",v:m.competitor},{l:"Next Steps",v:m.next}].map((f,i)=>(<div key={i} style={{background:C.petal,borderRadius:8,padding:"10px 12px"}}><div style={{fontSize:9,textTransform:"uppercase",letterSpacing:".5px",color:C.warmGrayLight,fontWeight:600,marginBottom:3}}>{f.l}</div><div style={{fontSize:12.5,lineHeight:1.5}}>{f.v}</div></div>))}
          </div>
        </div>
        <div className="det-section"><h3>Notes</h3><p style={{fontSize:13,lineHeight:1.7,color:C.warmGray}}>{m.notes}</p></div>
      </div>
      <div>
        <div className="det-section"><h3>Details</h3>
          {[{l:"Type",v:m.type},{l:"Outcome",v:m.outcome},{l:"Urgency"},{l:"Follow-up",v:m.status},{l:"Owner",v:m.owner}].map((f,i)=>(<div key={i} className="det-f"><div className="det-fl">{f.l}</div><div className="det-fv">{f.l==="Urgency"?<Badge type={m.urgency==="Critical"?"coral":m.urgency==="High"?"amber":"gray"}>{m.urgency}</Badge>:f.l==="Follow-up"?<Badge type={f.v==="Completed"?"green":"amber"}>{f.v}</Badge>:f.v}</div></div>))}
        </div>
      </div>
    </div>
  </div>);
};

// ACCOUNT STORY - The "aha moment" page
const AccountStoryPage = ({nav}) => {
  const a = ACCOUNTS.find(x=>x.id==="acc4"); // Summit Healthcare Partners
  const story = [
    {date:"Jan 15",event:"HIMSS 2025",type:"Conference",icon:"events",what:"First Touch",detail:"Sarah Chen met Robert Kim (COO) at the Cipher booth. 12-minute conversation about event attribution gaps. He mentioned evaluating 3 vendors. CRM source field: 'Inbound - Website'.",signal:"Buying Signal: Active evaluation",color:C.rose},
    {date:"Feb 22",event:"ViVE 2025",type:"Conference",icon:"meetings",what:"Deep Engagement",detail:"Scheduled 1:1 with Robert Kim + VP Revenue Lisa Tran. 45-minute deep dive on ROI methodology. Lisa shared internal spreadsheet showing manual event tracking across 14 conferences. First mention of budget approval timeline.",signal:"Buying Signal: Shared internal docs",color:C.roseDeep},
    {date:"Mar 8",event:null,type:"Pipeline",icon:"opportunities",what:"Opportunity Created",detail:"AE Marcus Rivera created $840K opportunity in Salesforce. Source field set to 'Outbound - SDR Sequence'. No event attribution. Cipher detected: 2 events, 3 meetings, 4 stakeholder touches.",signal:"CRM Gap: Source field missed 2 events",color:C.coral},
    {date:"Apr 12",event:"Healthcare Innovation Summit",type:"Summit",icon:"meetings",what:"Multi-Stakeholder Access",detail:"Robert Kim brought CFO David Park to the executive dinner. First time Cipher had direct CFO engagement. David asked about integration timeline and SOC 2 compliance. Deal moved from Evaluation to Proposal.",signal:"Buying Signal: CFO involvement + compliance questions",color:C.coral},
    {date:"May 3",event:null,type:"Acceleration",icon:"trend",what:"Deal Accelerated",detail:"Proposal submitted. David Park referenced the dinner conversation as the reason for fast-tracking legal review. What would have been a 6-week review cycle compressed to 10 days.",signal:"Event Impact: 4 weeks saved in deal cycle",color:C.green},
    {date:"May 18",event:"Customer Advisory Board",type:"CAB",icon:"performance",what:"Sealed the Deal",detail:"Robert Kim attended CAB alongside 3 existing customers. Heard directly from peers about implementation experience. Verbal commitment given that evening. Contract signed May 28.",signal:"Closed Won: $840K Annual Contract",color:C.green},
    {date:"Jul 1",event:null,type:"Expansion",icon:"opportunities",what:"Expansion Pipeline",detail:"Summit Healthcare expanded to enterprise tier. $2.1M expansion opportunity created based on Robert Kim's internal championship. He cited 'the journey from HIMSS to CAB' as the reason he trusted Cipher.",signal:"Upsell: $2.1M expansion in pipeline",color:C.amber},
  ];

  return (<div className="pg" style={{maxWidth:900}}>
    <div style={{marginBottom:28}}>
      <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:6}}>
        <Badge type="coral">Cipher Exclusive</Badge>
        <span style={{fontSize:11,color:C.warmGrayLight,fontWeight:500}}>Auto-generated from CRM + event data</span>
      </div>
      <h2 style={{fontFamily:"var(--serif)",fontSize:32,letterSpacing:"-.5px",marginBottom:4}}>Summit Healthcare Partners</h2>
      <p style={{fontSize:14,color:C.warmGray,lineHeight:1.6,maxWidth:640}}>From first handshake at HIMSS to an $840K closed deal and $2.1M expansion - every event touchpoint your CRM missed, connected into one story.</p>
    </div>

    {/* Hero outcome strip */}
    <div className="card fade-up d1" style={{padding:0,overflow:"hidden",marginBottom:24}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",borderBottom:`1px solid ${C.borderLight}`}}>
        {[{l:"CRM Says",v:"Outbound",sub:"SDR Sequence",dark:false,strike:true},{l:"Cipher Found",v:"4 Events",sub:"6 months of influence",dark:true},{l:"Contract Value",v:"$840K",sub:"Closed May 28",dark:false,green:true},{l:"Expansion",v:"$2.1M",sub:"In pipeline",dark:false,amber:true}].map((k,i)=>(<div key={i} style={{padding:"20px 22px",borderRight:i<3?`1px solid ${C.borderLight}`:"none",...(k.dark?{background:"linear-gradient(135deg,#252336,#342F48)",color:"#fff"}:{})}}>
          <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:".8px",color:k.dark?"rgba(255,255,255,.35)":C.warmGrayLight,fontWeight:700,marginBottom:6}}>{k.l}</div>
          <div style={{fontFamily:"var(--serif)",fontSize:26,letterSpacing:"-.5px",color:k.strike?C.warmGrayLight:k.green?C.green:k.amber?C.amber:k.dark?"#fff":C.ink,textDecoration:k.strike?"line-through":"none"}}>{k.v}</div>
          <div style={{fontSize:11,color:k.dark?"rgba(255,255,255,.3)":C.warmGray,marginTop:2,fontWeight:500}}>{k.sub}</div>
        </div>))}
      </div>
      <div style={{padding:"14px 22px",background:C.petal,display:"flex",alignItems:"center",gap:8}}>
        <Icon name="alert" size={14} color={C.coral}/>
        <span style={{fontSize:12,fontWeight:600,color:C.ink}}>Without Cipher, this $840K deal would be attributed to "Outbound - SDR Sequence" with zero event credit.</span>
      </div>
    </div>

    {/* Timeline */}
    <div style={{position:"relative",paddingLeft:28}}>
      {/* Vertical line - animated gradient */}
      <div style={{position:"absolute",left:11,top:8,bottom:8,width:2,background:`linear-gradient(180deg,${C.rose},${C.coral},${C.green})`,borderRadius:1,animation:"fadeUp 1s ease both"}}/>
      
      {story.map((s,i)=>(<div key={i} className={`slide-r d${i+1}`} style={{position:"relative",marginBottom:i<story.length-1?20:0}}>
        {/* Dot - pulsing on latest */}
        <div style={{position:"absolute",left:-22,top:18,width:12,height:12,borderRadius:"50%",background:s.color,border:"3px solid #fff",boxShadow:`0 0 0 1px ${C.borderLight}`,animation:i===story.length-1?"dotPulse 2s ease-in-out infinite":"none"}}/>

        <div className="card hover-lift" style={{overflow:"hidden"}}>
          {/* Header bar */}
          <div style={{padding:"14px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:`1px solid ${C.borderLight}`}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:28,height:28,borderRadius:7,background:`${s.color}14`,display:"flex",alignItems:"center",justifyContent:"center"}}><Icon name={s.icon} size={14} color={s.color}/></div>
              <div>
                <div style={{fontSize:14,fontWeight:700}}>{s.what}</div>
                <div style={{fontSize:11,color:C.warmGray,fontWeight:500}}>{s.date}{s.event?` · ${s.event}`:""}{s.type&&s.event?` · ${s.type}`:""}</div>
              </div>
            </div>
            {s.event&&<Badge type={s.type==="Conference"?"ink":s.type==="Summit"?"coral":s.type==="CAB"?"amber":"gray"}>{s.type}</Badge>}
          </div>
          {/* Body */}
          <div style={{padding:"14px 20px"}}>
            <p style={{fontSize:13,lineHeight:1.65,color:C.warmGray,fontWeight:500,marginBottom:10}}>{s.detail}</p>
            <div style={{display:"inline-flex",alignItems:"center",gap:6,padding:"6px 12px",borderRadius:8,background:`${s.color}10`,border:`1px solid ${s.color}20`}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:s.color}}/>
              <span style={{fontSize:11.5,fontWeight:700,color:s.color}}>{s.signal}</span>
            </div>
          </div>
        </div>
      </div>))}
    </div>

    {/* Bottom insight */}
    <div className="card fade-up d3" style={{marginTop:24,padding:0,overflow:"hidden"}}>
      <div style={{background:"linear-gradient(135deg,#252336,#342F48)",padding:"28px 28px",color:"#fff"}}>
        <div style={{fontSize:10,textTransform:"uppercase",letterSpacing:"1px",color:"rgba(255,255,255,.3)",fontWeight:700,marginBottom:10}}>What Cipher Decoded</div>
        <div style={{fontFamily:"var(--serif)",fontSize:22,lineHeight:1.3,marginBottom:16}}>This deal had <span style={{color:C.coral}}>4 event touchpoints</span> across <span style={{color:C.coral}}>6 months</span> - none of which appeared in Salesforce attribution.</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
          {[{l:"Events Involved",v:"4"},{l:"Stakeholders Met",v:"3"},{l:"Meetings Logged",v:"6"},{l:"Days Saved",v:"28"}].map((m,i)=>(<div key={i} style={{padding:"12px",background:"rgba(255,255,255,.05)",borderRadius:8,textAlign:"center"}}>
            <div style={{fontFamily:"var(--serif)",fontSize:22,color:C.coral}}>{m.v}</div>
            <div style={{fontSize:9,color:"rgba(255,255,255,.3)",textTransform:"uppercase",letterSpacing:".3px",marginTop:2,fontWeight:600}}>{m.l}</div>
          </div>))}
        </div>
      </div>
      <div style={{padding:"16px 28px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{fontSize:12,color:C.warmGray,fontWeight:500}}>This story was automatically assembled by Cipher from your CRM, calendar, and event registration data.</span>
        <div style={{display:"flex",gap:6}}>
          <button style={{padding:"6px 14px",fontSize:12,fontWeight:700,borderRadius:8,border:`1px solid ${C.border}`,background:"#fff",cursor:"pointer",fontFamily:"var(--sans)"}} onClick={()=>nav("acc-det","acc4")}>View Account</button>
          <button style={{padding:"6px 14px",fontSize:12,fontWeight:700,borderRadius:8,border:"none",background:C.coral,color:"#fff",cursor:"pointer",fontFamily:"var(--sans)"}}>Share Story</button>
        </div>
      </div>
    </div>
  </div>);
};

// --- MARKETING SITE (multi-page) ---
const MarketingNav = ({page, setPage, onApp, onDemo}) => (
  <nav className="land-nav">
    <div className="land-nav-b" onClick={()=>setPage("home")}>C<i>i</i>pher</div>
    <div className="land-nav-r">
      <span className={`land-nav-l ${page==="product"?"active":""}`} onClick={()=>setPage("product")}>Product</span>
      <span className={`land-nav-l ${page==="pricing"?"active":""}`} onClick={()=>setPage("pricing")}>Pricing</span>
      <span className="land-nav-l" onClick={onApp} style={{cursor:"pointer"}}>Log In</span>
      <button className="land-btn land-btn-p" onClick={onDemo}>Get a Demo</button>
    </div>
  </nav>
);

const MarketingFooter = ({setPage}) => (
  <>
    <div className="land-cta-sec">
      <h2>Ready to decode your event revenue?</h2>
      <p>Join the B2B teams that stopped guessing and started proving ROI.</p>
      <button className="land-btn land-btn-p" onClick={()=>setPage("home")} style={{fontSize:15,padding:"16px 36px",position:"relative",zIndex:1}}>Get a Demo</button>
      <div style={{marginTop:16,fontSize:12,color:C.warmGrayLight,fontWeight:500,position:"relative",zIndex:1}}>Personalized walkthrough · No commitment · See your data</div>
    </div>
    <footer className="land-foot">
      <div className="land-foot-b">C<i>i</i>pher</div>
      <div className="land-foot-links">
        <span className="land-foot-link" onClick={()=>setPage("product")}>Product</span>
        <span className="land-foot-link" onClick={()=>setPage("pricing")}>Pricing</span>
        <span className="land-foot-link">Privacy</span>
        <span className="land-foot-link">Terms</span>
        <span className="land-foot-link">Security</span>
      </div>
    </footer>
  </>
);

// HOME
const HomePage = ({onApp, onDemo}) => {
  const [tick, setTick] = useState(0);
  useEffect(()=>{const t=setInterval(()=>setTick(p=>p+1),3000);return()=>clearInterval(t)},[]);
  const heroStats = [{v:"$17.3M",l:"Pipeline Found",pct:92,color:C.coral},{v:"$4.8M",l:"Revenue Influenced",pct:68,color:C.green},{v:"47",l:"Meetings Tracked",pct:85,color:C.rose}];

  return (
  <>
    <div className="land-hero-c" style={{maxWidth:"none",display:"grid",gridTemplateColumns:"1fr 1fr",gap:60,alignItems:"center"}}>
      <div style={{maxWidth:580}}>
        <div className="land-tag">Event Revenue Intelligence</div>
        <h1 style={{fontSize:56}}>Decode the <i>signals</i> behind your event revenue</h1>
        <p className="sub">Your CRM tracks leads. Cipher tracks what actually matters - which events influence pipeline, accelerate deals, and drive real revenue outcomes.</p>
        <div className="land-ctas">
          <button className="land-btn land-btn-p" onClick={onDemo}>Get a Demo</button>
        </div>
        <div style={{marginTop:48,display:"flex",alignItems:"center",gap:16}}>
          <div style={{display:"flex"}}>
            {["SC","MR","JP","AK"].map((init,i)=><div key={i} style={{width:28,height:28,borderRadius:"50%",background:`linear-gradient(135deg,${[C.coral,C.roseDeep,"#8B7068",C.amber][i]},${[C.coralHover,C.coral,"#6B5A45",C.roseDeep][i]})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:"#fff",border:"2px solid #fff",marginLeft:i>0?-8:0,boxShadow:"0 1px 3px rgba(0,0,0,.08)"}}>{init}</div>)}
          </div>
          <div style={{fontSize:12,color:C.warmGrayLight,fontWeight:500}}>Trusted by marketing and revenue teams at B2B companies</div>
        </div>
      </div>

      {/* Animated hero visual */}
      <div style={{position:"relative"}}>
        {/* Mock platform card */}
        <div style={{background:"linear-gradient(135deg,#252336,#342F48)",borderRadius:20,padding:"28px 28px 20px",color:"#fff",boxShadow:"0 24px 80px rgba(37,35,54,.3),0 0 0 1px rgba(255,255,255,.04) inset",animation:"fadeUp .8s cubic-bezier(.22,.61,.36,1) .2s both",position:"relative",overflow:"hidden"}}>
          {/* Shimmer sweep */}
          <div style={{position:"absolute",inset:0,background:"linear-gradient(105deg,transparent 40%,rgba(255,255,255,.03) 50%,transparent 60%)",backgroundSize:"200% 100%",animation:"shimmer 4s ease-in-out infinite"}}/>

          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,position:"relative"}}>
            <div style={{fontSize:10,textTransform:"uppercase",letterSpacing:"1.5px",color:"rgba(255,255,255,.3)",fontWeight:700}}>Cipher Dashboard</div>
            <div style={{display:"flex",gap:4}}>{[1,2,3].map(d=><div key={d} style={{width:8,height:8,borderRadius:"50%",background:`rgba(255,255,255,${d===1?.3:.08})`}}/>)}</div>
          </div>

          {/* Animated stats */}
          {heroStats.map((s,i)=>(
            <div key={i} style={{marginBottom:i<2?16:0,animation:`slideRight .5s cubic-bezier(.22,.61,.36,1) ${.4+i*.15}s both`,position:"relative"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                <div style={{fontSize:11,color:"rgba(255,255,255,.4)",fontWeight:600}}>{s.l}</div>
                <div style={{fontFamily:"var(--serif)",fontSize:24,letterSpacing:"-.5px",transition:"opacity .5s",opacity:tick>0?1:.3}}>{s.v}</div>
              </div>
              <div style={{height:4,borderRadius:2,background:"rgba(255,255,255,.06)",overflow:"hidden"}}>
                <div style={{height:"100%",borderRadius:2,background:s.color,width:`${s.pct}%`,animation:`barGrow 1s cubic-bezier(.22,.61,.36,1) ${.6+i*.2}s both`,["--bar-w"]:`${s.pct}%`}}/>
              </div>
            </div>
          ))}

          {/* CRM gap reveal */}
          <div style={{marginTop:20,padding:"14px 16px",background:"rgba(204,107,133,.08)",borderRadius:10,border:"1px solid rgba(204,107,133,.1)",animation:`fadeUp .5s cubic-bezier(.22,.61,.36,1) 1.2s both`,position:"relative"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:9,textTransform:"uppercase",letterSpacing:"1px",color:"rgba(255,255,255,.25)",fontWeight:700,marginBottom:3}}>CRM Attribution Gap</div>
                <div style={{fontSize:13,fontWeight:600,color:"#fff"}}>Your CRM shows <span style={{color:"rgba(255,255,255,.35)",textDecoration:"line-through"}}>5%</span> → Cipher found <span style={{color:C.coral,fontWeight:800}}>92%</span></div>
              </div>
              <div style={{width:36,height:36,borderRadius:10,background:"rgba(204,107,133,.12)",display:"flex",alignItems:"center",justifyContent:"center",animation:"dotPulse 2s ease-in-out infinite"}}>
                <svg width="16" height="16" viewBox="0 0 16 16"><path d="M4 8l3 3 5-6" stroke={C.coral} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
            </div>
          </div>
        </div>

        {/* Floating accent cards */}
        <div style={{position:"absolute",top:-16,right:-20,background:"#fff",borderRadius:12,padding:"10px 14px",boxShadow:"0 8px 32px rgba(0,0,0,.08)",animation:"fadeUp .5s cubic-bezier(.22,.61,.36,1) 1.5s both,orbFloat 6s ease-in-out infinite",display:"flex",alignItems:"center",gap:8,zIndex:2}}>
          <div style={{width:24,height:24,borderRadius:6,background:C.greenSoft,display:"flex",alignItems:"center",justifyContent:"center"}}><svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 6l3 3 5-6" stroke={C.green} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg></div>
          <div><div style={{fontSize:11,fontWeight:700,color:C.ink}}>Deal Closed</div><div style={{fontSize:9,color:C.warmGrayLight,fontWeight:500}}>$840K · Summit Healthcare</div></div>
        </div>

        <div style={{position:"absolute",bottom:-12,left:-16,background:"#fff",borderRadius:12,padding:"10px 14px",boxShadow:"0 8px 32px rgba(0,0,0,.08)",animation:"fadeUp .5s cubic-bezier(.22,.61,.36,1) 1.8s both,orbFloat 8s ease-in-out infinite reverse",display:"flex",alignItems:"center",gap:8,zIndex:2}}>
          <div style={{width:24,height:24,borderRadius:6,background:C.coralSoft,display:"flex",alignItems:"center",justifyContent:"center"}}><Icon name="alert" size={12} color={C.coral}/></div>
          <div><div style={{fontSize:11,fontWeight:700,color:C.ink}}>Signal Detected</div><div style={{fontSize:9,color:C.warmGrayLight,fontWeight:500}}>CFO engagement at dinner</div></div>
        </div>
      </div>
    </div>
  </>
  );
};

// PRODUCT PAGE
const ProductPage = () => (
  <>
    <div className="prod-hero">
      <div className="land-tag" style={{marginBottom:16}}>The Platform</div>
      <h1>Every module built for <i>event intelligence</i></h1>
      <p className="sub">Cipher replaces disconnected spreadsheets and CRM workarounds with a purpose-built system that connects events to revenue outcomes.</p>
    </div>

    {/* How it works strip */}
    <div className="land-sec land-sec-white" style={{paddingBottom:40}}>
      <h2 style={{marginBottom:40}}>How Cipher works</h2>
      <div className="how-strip">
        {[
          {n:"1",t:"Connect",d:"Sync your CRM, calendar, and event registration data"},
          {n:"2",t:"Track",d:"Log meetings, signals, and competitor intel at every event"},
          {n:"3",t:"Attribute",d:"Cipher maps event touches to pipeline and deal progression"},
          {n:"4",t:"Optimize",d:"Get strategic insights on where to invest your event budget"},
        ].map((s,i)=>(
          <div key={i} className="how-step">
            <div className="how-step-num">{s.n}</div>
            <h4>{s.t}</h4>
            <p>{s.d}</p>
          </div>
        ))}
      </div>
    </div>

    {/* Modules grid */}
    <div className="land-sec land-sec-light" style={{paddingTop:48}}>
      <h2 style={{marginBottom:8}}>Core modules</h2>
      <p className="sec-sub">Six integrated modules that work together to give you complete event intelligence.</p>
      <div className="mod-grid">
        {[
          {i:"dashboard",n:"01",t:"Executive Dashboard",d:"A real-time command center for event performance. KPIs, ROI rankings, trend lines, and pipeline attribution - all in one view designed for leadership reporting.",feats:["Pipeline influenced & sourced metrics","Event ROI scoring with weighted formula","Trend analysis across quarters","Strategic insight cards"]},
          {i:"events",n:"02",t:"Event Intelligence",d:"Every event gets a rich detail page showing meetings held, accounts engaged, opportunities influenced, competitor activity, and strategic recommendations.",feats:["Event scorecard with ROI ring","Budget vs. pipeline analysis","Competitor observation log","Year-over-year recommendations"]},
          {i:"accounts",n:"03",t:"Account Intelligence",d:"Account-based, not lead-based. See exactly how target accounts engage across your event portfolio and move through your pipeline.",feats:["Kanban board by progression stage","Account health scoring","Multi-event engagement timeline","Competitive threat tracking"]},
          {i:"opportunities",n:"04",t:"Pipeline Attribution",d:"Transparent attribution that distinguishes between sourced, influenced, and accelerated pipeline. Finally answer which events actually drive revenue.",feats:["Visual pipeline funnel","Sourced vs influenced vs accelerated","Multi-touch event mapping","Confidence scoring"]},
          {i:"meetings",n:"05",t:"Meeting Intelligence",d:"Every event conversation becomes a structured intelligence card with buying signals, objections, competitive mentions, and follow-up tracking.",feats:["Sentiment scoring","Buying signal capture","Competitor mention alerts","Follow-up workflow tracking"]},
          {i:"competitors",n:"06",t:"Competitive War Room",d:"Conferences are competitive intelligence goldmines. Track competitor presence, messaging, product announcements, and threat levels across every event.",feats:["Threat level matrix","Messaging theme tracking","Product announcement log","Competitive trend analysis"]},
        ].map((m,i)=>(
          <div key={i} className="mod-card">
            <div className="mod-card-num">{m.n}</div>
            <h3 style={{display:"flex",alignItems:"center",gap:10}}><Icon name={m.i} size={20} color={C.coral}/> {m.t}</h3>
            <p>{m.d}</p>
            <ul>{m.feats.map((f,j)=><li key={j}>{f}</li>)}</ul>
          </div>
        ))}
      </div>
    </div>

    {/* Attribution deep-dive */}
    <div className="land-sec land-sec-dark">
      <h2 style={{color:"#fff"}}>Transparent attribution, not a black box</h2>
      <p className="sec-sub">Cipher uses a clear, auditable model so you can explain event ROI to your CFO with confidence.</p>
      <div className="feat-grid" style={{maxWidth:900}}>
        {[
          {t:"Sourced",d:"First meaningful engagement originated from the event. The account didn't know you existed until they met your team at the conference.",c:C.green},
          {t:"Influenced",d:"The event materially impacted account progression. A target account was already in your funnel, but the event deepened the relationship or advanced the conversation.",c:C.coral},
          {t:"Accelerated",d:"The opportunity stage moved faster after event engagement. A deal that was stalling got unstuck because of a dinner conversation or executive meeting.",c:C.amber},
        ].map((a,i)=>(
          <div key={i} className="feat-card" style={{borderTop:`3px solid ${a.c}`}}>
            <h3 style={{color:a.c}}>{a.t}</h3>
            <p>{a.d}</p>
          </div>
        ))}
      </div>
    </div>

    {/* ROI formula */}
    <div className="land-sec land-sec-white">
      <h2>A ROI formula you can trust</h2>
      <p className="sec-sub">Our weighted scoring model balances multiple signals to give each event a credible, defensible ROI score.</p>
      <div style={{maxWidth:520,margin:"0 auto",background:C.petal,borderRadius:14,padding:"32px 36px",border:`1px solid ${C.border}`}}>
        {[
          {l:"Pipeline Influenced",w:30},{l:"Sourced Pipeline",w:25},{l:"Opportunities Accelerated",w:20},{l:"Target Account Engagement",w:15},{l:"Meeting Quality & Follow-up",w:10}
        ].map((w,i)=>(
          <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:i<4?`1px solid ${C.border}`:"none"}}>
            <span style={{fontSize:14,fontWeight:600}}>{w.l}</span>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:80,height:6,borderRadius:3,background:C.borderLight,overflow:"hidden"}}><div style={{height:"100%",width:`${w.w*3.3}%`,borderRadius:3,background:C.coral}}/></div>
              <span style={{fontWeight:800,fontSize:14,color:C.coral,width:36,textAlign:"right"}}>{w.w}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  </>
);

// PRICING PAGE
const PricingPage = ({onApp}) => {
  const [openFaq, setOpenFaq] = useState(null);
  const faqs = [
    {q:"What counts as an 'event' in Cipher?",a:"Any conference, trade show, hosted dinner, roundtable, summit, field event, customer advisory board, or sponsorship activation. Both large conferences and intimate dinners are tracked."},
    {q:"How does attribution work?",a:"Cipher uses a transparent model with three types: Sourced (first touch from event), Influenced (event advanced an existing relationship), and Accelerated (event sped up deal progression). All attribution is auditable."},
    {q:"Can I import existing event data?",a:"Yes. Cipher supports CSV import and has native integrations with Salesforce, HubSpot, and major event platforms. Our onboarding team helps migrate your historical data."},
    {q:"How long does setup take?",a:"Most teams are up and running in under a week. Connect your CRM, import past events, and start tracking. Full onboarding with historical data typically takes 2-3 weeks."},
    {q:"How does the demo process work?",a:"Book a demo and we'll walk you through a personalized session using your event data. If it's a fit, we'll onboard your team with a dedicated implementation specialist. Most teams are live within a week."},
    {q:"What about data security?",a:"Cipher is SOC 2 Type II compliant with enterprise-grade encryption. Your data is isolated per tenant and never shared. We support SSO and SCIM provisioning on Enterprise plans."},
    {q:"How does Cipher compare to event management platforms like Bizzabo or Cvent?",a:"Cipher doesn't replace your event management platform - it sits alongside it. Bizzabo and Cvent handle registration, ticketing, and logistics. Cipher handles what happens after: connecting event activity to pipeline, account engagement, and revenue outcomes. Think of it as the intelligence layer on top of your event stack."},
    {q:"Can I switch plans later?",a:"Yes. You can upgrade or downgrade at any time. When upgrading, the new features activate immediately and billing is prorated. Downgrading takes effect at the next billing cycle."},
  ];

  return (
    <>
      <div className="price-hero">
        <div className="land-tag" style={{marginBottom:16}}>Pricing</div>
        <h1>Plans that scale with your <i>event portfolio</i></h1>
        <p className="sub">Transparent pricing for every stage of growth.</p>
      </div>

      <div style={{background:C.petal,paddingBottom:80}}>
        <div className="price-grid">
          {[
            {name:"Starter",desc:"For teams getting started with event tracking",price:"$349",per:"/mo, billed annually",annual:"$4,188/yr",pop:false,cta:"Get a Demo",feats:[
              {t:"Up to 10 events per year",on:true},{t:"3 team members",on:true},{t:"Executive dashboard",on:true},{t:"Event & meeting tracking",on:true},{t:"Basic ROI scoring",on:true},{t:"CSV export",on:true},{t:"CRM integrations",on:false},{t:"Competitive intelligence",on:false},{t:"AI insights",on:false},{t:"Custom attribution models",on:false},
            ]},
            {name:"Pro",desc:"For serious B2B teams running 20+ events a year",price:"$1,190",per:"/mo, billed annually",annual:"$14,280/yr",pop:true,cta:"Get a Demo",feats:[
              {t:"Unlimited events",on:true},{t:"8 team members",on:true},{t:"Executive dashboard",on:true},{t:"Event & meeting intelligence",on:true},{t:"Advanced ROI scoring",on:true},{t:"Salesforce & HubSpot sync",on:true},{t:"Competitive war room",on:true},{t:"Pipeline attribution",on:true},{t:"AI-powered insights",on:true},{t:"Custom attribution models",on:false},
            ]},
            {name:"Enterprise",desc:"For organizations with complex event portfolios",price:"Custom",per:"tailored to your needs",annual:null,pop:false,cta:"Talk to Sales",feats:[
              {t:"Unlimited everything",on:true},{t:"Unlimited team members",on:true},{t:"Executive dashboard + custom",on:true},{t:"Full intelligence suite",on:true},{t:"Custom ROI models",on:true},{t:"All CRM integrations",on:true},{t:"Competitive intelligence",on:true},{t:"Multi-touch attribution",on:true},{t:"AI insights + recommendations",on:true},{t:"SSO, SCIM, audit logs",on:true},
            ]},
          ].map((plan,i)=>(
            <div key={i} className={`price-card ${plan.pop?"pop":""}`}>
              {plan.pop && <div className="price-card-badge">Most Popular</div>}
              <h3>{plan.name}</h3>
              <div className="price-desc">{plan.desc}</div>
              <div className="price-val">{plan.price}</div>
              <div className="price-per">{plan.per}</div>
              {plan.annual && <div style={{fontSize:11,color:C.warmGrayLight,marginBottom:20,marginTop:-4,fontWeight:500}}>{plan.annual} · Save 15% vs monthly</div>}
              {!plan.annual && plan.name==="Enterprise" && <div style={{fontSize:11,color:C.warmGrayLight,marginBottom:20,marginTop:-4,fontWeight:500}}>Volume discounts · Multi-year options</div>}
              <div className="price-feats">
                {plan.feats.map((f,j)=>(
                  <div key={j} className="price-feat"><span className={f.on?"ck":"no"}>{f.on?"✓":"–"}</span>{f.t}</div>
                ))}
              </div>
              <button className={`price-cta ${plan.pop?"price-cta-p":"price-cta-s"}`} onClick={onApp}>{plan.cta}</button>
              <div style={{textAlign:"center",marginTop:8,fontSize:10.5,color:C.warmGrayLight,fontWeight:500}}>{plan.name!=="Enterprise"?"See it in action with your data":"Includes dedicated onboarding"}</div>
            </div>
          ))}
        </div>
      </div>

      {/* FAQ */}
      <div className="land-sec land-sec-white">
        <h2>Frequently asked questions</h2>
        <p className="sec-sub">Everything you need to know about Cipher.</p>
        <div className="faq-grid">
          {faqs.map((f,i)=>(
            <div key={i} className="faq-item" onClick={()=>setOpenFaq(openFaq===i?null:i)}>
              <div className="faq-q">{f.q}<span style={{color:C.coral,fontSize:18,fontWeight:800,transition:"transform .2s",transform:openFaq===i?"rotate(45deg)":"none"}}>+</span></div>
              {openFaq===i && <div className="faq-a">{f.a}</div>}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

// CUSTOMERS PAGE
const CustomersPage = () => (
  <>
    <div className="cust-hero">
      <div className="land-tag" style={{marginBottom:16}}>Customers</div>
      <h1>Trusted by the teams that <i>run events</i></h1>
      <p className="sub">B2B marketing teams, RevOps leaders, and growth executives use Cipher to prove event ROI and make smarter investment decisions.</p>
    </div>

    {/* Logo strip */}
    <div className="land-sec land-sec-white" style={{paddingTop:48,paddingBottom:48}}>
      <p className="sec-sub" style={{marginBottom:32,fontSize:12,textTransform:"uppercase",letterSpacing:"1.5px",fontWeight:700,color:C.warmGrayLight}}>Trusted by leading B2B teams</p>
      <div className="logo-strip">
        {["Meridian Health","Atlas Cloud","NovaTech","Summit Partners","Ironclad","BrightPath","Apex Financial","Vanguard"].map((n,i)=>(
          <div key={i} className="logo-item">{n}</div>
        ))}
      </div>
    </div>

    {/* Testimonials */}
    <div className="land-sec land-sec-light">
      <h2>What our customers say</h2>
      <p className="sec-sub">From conference-heavy SaaS to healthcare enterprise, Cipher transforms how teams think about events.</p>
      <div className="test-grid">
        {[
          {q:"Before Cipher, we had spreadsheets for every conference with no way to connect events to pipeline. Now our CMO can see exactly which events influence revenue - and our board loves the reporting.",name:"Sarah Martinez",role:"VP Marketing · Meridian Health Systems",color:C.coral},
          {q:"We were spending $800K/year on events and couldn't tell leadership which ones mattered. Cipher showed us that our $28K executive dinners outperformed our $200K conference booths. That insight alone paid for the platform.",name:"David Chen",role:"Head of Revenue Operations · Atlas Cloud",color:C.roseDeep},
          {q:"The competitive intelligence module is a game-changer. We track competitor presence, messaging, and threat levels across every event. Our sales team goes into deals armed with insights no one else has.",name:"Priya Kapoor",role:"Director of Growth · Ironclad Security",color:C.inkLight},
          {q:"Cipher changed how our sales team follows up after events. The meeting intelligence cards mean nothing falls through the cracks, and we can see exactly which conversations turned into pipeline.",name:"Marcus Johnson",role:"VP Sales · Summit Healthcare Partners",color:C.amber},
          {q:"As a founder, I needed to justify our event budget to investors. Cipher gave me a clear, data-backed story: here's what we spent, here's the pipeline it influenced, and here's the ROI. Fundraising got easier.",name:"Rachel Torres",role:"CEO · BrightPath Education",color:"#7B6E5D"},
          {q:"The account-based view is exactly what ABM teams need. We can see how target accounts engage across multiple events and track their progression from awareness to closed-won. It's ABM intelligence, not just lead tracking.",name:"Alex Novak",role:"Senior Director, ABM · NovaTech Solutions",color:C.green},
        ].map((t,i)=>(
          <div key={i} className="test-card">
            <div className="test-card-quote">{t.q}</div>
            <div className="test-card-person">
              <div className="test-card-av" style={{background:t.color}}>{t.name.split(" ").map(w=>w[0]).join("")}</div>
              <div><div className="test-card-name">{t.name}</div><div className="test-card-role">{t.role}</div></div>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Case Studies */}
    <div className="land-sec land-sec-white">
      <h2>Customer results</h2>
      <p className="sec-sub">Real outcomes from teams using Cipher to optimize their event strategy.</p>
      <div className="case-grid">
        {[
          {name:"Meridian Health Systems",ind:"Healthcare · Enterprise",desc:"Meridian used Cipher to audit their $1.2M annual event portfolio. They discovered hosted executive dinners generated 4x the pipeline per dollar compared to large conference sponsorships - and reallocated $340K in budget accordingly.",stats:[{v:"4.2x",l:"ROI Improvement"},{v:"$2.8M",l:"Pipeline Found"},{v:"47%",l:"Cost Reduction"}]},
          {name:"Atlas Cloud Infrastructure",ind:"Technology · Enterprise",desc:"Atlas Cloud's RevOps team connected Cipher to Salesforce and mapped event touchpoints to their full pipeline. They identified 3 enterprise deals worth $4.5M that were directly accelerated by conference meetings - deals their CRM showed as 'inbound'.",stats:[{v:"$4.5M",l:"Reclassified Pipeline"},{v:"12",l:"Deals Accelerated"},{v:"89%",l:"Attribution Clarity"}]},
          {name:"Ironclad Security",ind:"Cybersecurity · Enterprise",desc:"Ironclad's growth team used Cipher's competitive intelligence module to track competitor activity across RSAC and regional events. They identified 3 at-risk accounts being targeted by competitors and launched a retention program that saved $1.8M in renewals.",stats:[{v:"$1.8M",l:"Renewals Saved"},{v:"3",l:"At-Risk Accounts"},{v:"100%",l:"Retention Rate"}]},
          {name:"BrightPath Education",ind:"Education · Mid-Market",desc:"BrightPath was attending 15+ education conferences a year with no way to measure impact. Cipher revealed that only 4 events generated meaningful pipeline. They cut 8 events, invested more in the top 4, and increased sourced pipeline by 62%.",stats:[{v:"62%",l:"Pipeline Increase"},{v:"8",l:"Events Cut"},{v:"$180K",l:"Budget Saved"}]},
        ].map((c,i)=>(
          <div key={i} className="case-card">
            <div className="case-card-top">
              <div><h3>{c.name}</h3><div className="ind">{c.ind}</div></div>
            </div>
            <div className="case-card-body">
              <p>{c.desc}</p>
              <div className="case-stats">
                {c.stats.map((s,j)=>(
                  <div key={j} className="case-stat"><div className="case-stat-v">{s.v}</div><div className="case-stat-l">{s.l}</div></div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Impact stats */}
    <div className="land-sec land-sec-dark">
      <h2 style={{color:"#fff"}}>The Cipher impact</h2>
      <p className="sec-sub">Aggregate outcomes across all Cipher customers.</p>
      <div className="stats-row">
        <div><div className="stat-v">$47M</div><div className="stat-l" style={{color:"rgba(255,255,255,.35)"}}>Pipeline attributed</div></div>
        <div><div className="stat-v">340+</div><div className="stat-l" style={{color:"rgba(255,255,255,.35)"}}>Events tracked</div></div>
        <div><div className="stat-v">3.2x</div><div className="stat-l" style={{color:"rgba(255,255,255,.35)"}}>Avg ROI improvement</div></div>
        <div><div className="stat-v">89%</div><div className="stat-l" style={{color:"rgba(255,255,255,.35)"}}>Say "can't go back"</div></div>
      </div>
    </div>
  </>
);

// Demo Request Modal
const DemoModal = ({open, onClose}) => {
  const [form, setForm] = useState({name:"",email:"",company:"",role:"",plan:"",events:"",notes:""});
  const [sent, setSent] = useState(false);
  const up = (k,v) => setForm(prev=>({...prev,[k]:v}));
  const handleSubmit = () => {
    const subject = encodeURIComponent(`Cipher Demo Request - ${form.company}`);
    const body = encodeURIComponent(`New demo request from Cipher landing page:\n\nName: ${form.name}\nEmail: ${form.email}\nCompany: ${form.company}\nRole: ${form.role}\nPlan Interest: ${form.plan||"Not specified"}\nAnnual Events: ${form.events||"Not specified"}\nNotes: ${form.notes||"None"}`);
    window.open(`mailto:victoria@cipherstrategy.io?subject=${subject}&body=${body}`,"_blank");
    setSent(true);
  };
  if(!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{width:480}} onClick={e=>e.stopPropagation()}>
        <div className="modal-head">
          <h3>{sent?"We'll be in touch":"Get a Demo"}</h3>
          <button className="modal-close" onClick={()=>{onClose();setTimeout(()=>setSent(false),300)}}>×</button>
        </div>
        <div className="modal-body">
          {sent ? (
            <div style={{textAlign:"center",padding:"24px 0"}}>
              <div style={{width:48,height:48,borderRadius:"50%",background:C.greenSoft,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 16px"}}>
                <svg width="20" height="20" viewBox="0 0 20 20"><path d="M4 10l4 4 8-8" stroke={C.green} strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
              <div style={{fontSize:16,fontWeight:700,marginBottom:6}}>Request received</div>
              <div style={{fontSize:13,color:C.warmGray,lineHeight:1.6}}>We'll reach out within 24 hours to schedule your personalized demo. Check your inbox for a confirmation.</div>
            </div>
          ) : (
            <>
              <div style={{fontSize:13,color:C.warmGray,marginBottom:16,lineHeight:1.5}}>See how Cipher connects your events to pipeline and revenue. Fill out the form and we'll schedule a personalized walkthrough.</div>
              <div className="form-row">
                <div className="form-group"><label className="form-label">Full Name *</label><input className="form-input" value={form.name} onChange={e=>up("name",e.target.value)} placeholder="Sarah Chen"/></div>
                <div className="form-group"><label className="form-label">Work Email *</label><input className="form-input" type="email" value={form.email} onChange={e=>up("email",e.target.value)} placeholder="sarah@company.com"/></div>
              </div>
              <div className="form-row">
                <div className="form-group"><label className="form-label">Company *</label><input className="form-input" value={form.company} onChange={e=>up("company",e.target.value)} placeholder="Acme Corp"/></div>
                <div className="form-group"><label className="form-label">Role</label><input className="form-input" value={form.role} onChange={e=>up("role",e.target.value)} placeholder="VP Marketing"/></div>
              </div>
              <div className="form-row">
                <div className="form-group"><label className="form-label">Which plan interests you?</label>
                  <select className="form-select" value={form.plan} onChange={e=>up("plan",e.target.value)}>
                    <option value="">Select...</option>
                    <option>Starter ($349/mo)</option>
                    <option>Pro ($1,190/mo)</option>
                    <option>Enterprise (Custom)</option>
                    <option>Not sure yet</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Events per year?</label>
                  <select className="form-select" value={form.events} onChange={e=>up("events",e.target.value)}>
                    <option value="">Select...</option>
                    <option>1-5 events</option>
                    <option>6-15 events</option>
                    <option>16-30 events</option>
                    <option>30+ events</option>
                  </select>
                </div>
              </div>
              <div className="form-group"><label className="form-label">Anything specific you'd like to see?</label><textarea className="form-textarea" value={form.notes} onChange={e=>up("notes",e.target.value)} placeholder="E.g. pipeline attribution, competitive intelligence, ROI reporting..." style={{minHeight:60}}/></div>
            </>
          )}
        </div>
        {!sent && <div className="modal-foot">
          <button className="modal-btn modal-btn-s" onClick={onClose}>Cancel</button>
          <button className="modal-btn modal-btn-p" onClick={handleSubmit} disabled={!form.name||!form.email||!form.company} style={{opacity:(!form.name||!form.email||!form.company)?.5:1}}>Request Demo</button>
        </div>}
      </div>
    </div>
  );
};

const Landing = ({go}) => {
  const [mktPage, setMktPage] = useState("home");
  const [demoOpen, setDemoOpen] = useState(false);

  return (
    <div className="landing">
      <div className="land-hero" style={{minHeight:mktPage==="home"?"100vh":"auto"}}>
        <MarketingNav page={mktPage} setPage={(p)=>{setMktPage(p);window.scrollTo(0,0)}} onApp={go} onDemo={()=>setDemoOpen(true)}/>
        {mktPage==="home" && <HomePage onApp={go} onDemo={()=>setDemoOpen(true)}/>}
      </div>
      {mktPage==="product" && <ProductPage/>}
      {mktPage==="pricing" && <PricingPage onApp={go}/>}

      {/* Homepage-only sections */}
      {mktPage==="home" && <>
        {/* Stats - dramatic numbers */}
        <div className="land-sec land-sec-dark">
          <div style={{textAlign:"center",marginBottom:56}}>
            <div className="land-tag" style={{justifyContent:"center",color:"rgba(255,255,255,.3)"}}>By the numbers</div>
            <h2 style={{color:"#fff"}}>Event intelligence that compounds</h2>
          </div>
          <div className="stats-row"><div><div className="stat-v">92%</div><div className="stat-l" style={{color:"rgba(255,255,255,.3)"}}>Pipeline your CRM misses</div></div><div><div className="stat-v">3.2x</div><div className="stat-l" style={{color:"rgba(255,255,255,.3)"}}>Avg pipeline multiplier</div></div><div><div className="stat-v">$2.1M</div><div className="stat-l" style={{color:"rgba(255,255,255,.3)"}}>Avg hidden pipeline found</div></div><div><div className="stat-v">14d</div><div className="stat-l" style={{color:"rgba(255,255,255,.3)"}}>Time to first insight</div></div></div>
        </div>

        {/* Problem statement */}
        <div className="land-sec land-sec-white" style={{textAlign:"center"}}>
          <div className="land-tag" style={{justifyContent:"center",marginBottom:20}}>The problem</div>
          <h2 style={{maxWidth:640,margin:"0 auto 20px"}}>Your CRM says 5% of pipeline came from events</h2>
          <p className="sec-sub" style={{marginBottom:40}}>Because badge scans don't capture executive dinners. Source fields don't track deal acceleration. And nobody connects the RSAC meeting to the contract that closed 3 months later.</p>
          <div style={{display:"grid",gridTemplateColumns:"1fr auto 1fr",gap:24,maxWidth:700,margin:"0 auto",alignItems:"center"}}>
            <div style={{padding:24,borderRadius:14,background:C.petal,border:`1px solid ${C.borderLight}`,textAlign:"center"}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:".6px",color:C.warmGrayLight,marginBottom:8}}>What your CRM shows</div>
              <div style={{fontFamily:"var(--serif)",fontSize:36,color:C.warmGray}}>5%</div>
              <div style={{fontSize:12,color:C.warmGrayLight,fontWeight:500,marginTop:4}}>pipeline from events</div>
            </div>
            <div style={{fontSize:24,color:C.border}}>→</div>
            <div style={{padding:24,borderRadius:14,background:"linear-gradient(135deg,#252336,#342F48)",color:"#fff",textAlign:"center",boxShadow:"0 8px 32px rgba(0,0,0,.15)"}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:".6px",color:"rgba(255,255,255,.35)",marginBottom:8}}>What Cipher finds</div>
              <div style={{fontFamily:"var(--serif)",fontSize:36,color:C.coral}}>92%</div>
              <div style={{fontSize:12,color:"rgba(255,255,255,.4)",fontWeight:500,marginTop:4}}>pipeline event-influenced</div>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="land-sec land-sec-light">
          <h2>Built for how B2B teams actually work</h2>
          <p className="sec-sub">From marketing to sales leadership, Cipher gives every team the event intelligence they need.</p>
          <div className="feat-grid">
            {[{ic:"dashboard",t:"Executive Dashboard",d:"Real-time KPIs, ROI rankings, and pipeline attribution - in one view built for leadership."},{ic:"accounts",t:"Account Intelligence",d:"Track how target accounts engage across events and progress through your pipeline."},{ic:"opportunities",t:"Pipeline Attribution",d:"Transparent sourced, influenced, and accelerated logic. Auditable by your CFO."},{ic:"meetings",t:"Meeting Intelligence",d:"Every conversation becomes a structured intelligence card with buying signals."},{ic:"competitors",t:"Competitive War Room",d:"Track competitor presence, messaging, and threats from every event."},{ic:"insights",t:"Strategic Recommendations",d:"Data-driven insights on which events to invest in and which to cut."}].map((f,i)=>(<div key={i} className="feat-card"><div className="feat-card-i"><Icon name={f.ic} size={20} color={C.coral}/></div><h3>{f.t}</h3><p>{f.d}</p></div>))}
          </div>
        </div>
      </>}

      <MarketingFooter setPage={(p)=>{setMktPage(p);window.scrollTo(0,0)}}/>
      <DemoModal open={demoOpen} onClose={()=>setDemoOpen(false)}/>
    </div>
  );
};

// --- LOGIN ---
const Login = ({go}) => (<div className="login">
  <div className="login-l"><div className="login-brand">C<i>i</i>pher</div><div className="login-tag">Decode the signals behind your event revenue. The intelligence platform for conference-heavy B2B teams.</div></div>
  <div className="login-r"><h2>Welcome back</h2><p>Sign in to your workspace</p><input className="login-in" defaultValue="demo@cipherstrategy.io" placeholder="Email"/><input className="login-in" type="password" defaultValue="••••••••" placeholder="Password"/><button className="login-go" onClick={go}>Sign In</button><p style={{textAlign:"center",fontSize:11,color:C.warmGrayLight,marginTop:14}}>Demo - click Sign In</p></div>
</div>);

// ==================== APP ====================
const NAV = [
  {k:"dashboard",l:"Dashboard",ic:"dashboard"},
  {k:"story",l:"Account Story",ic:"journey",featured:true},
  {k:"events",l:"Events",ic:"events"},
  {k:"accounts",l:"Accounts",ic:"accounts"},
  {k:"opportunities",l:"Pipeline",ic:"opportunities"},
  {k:"meetings",l:"Meetings",ic:"meetings"},
  {k:"competitors",l:"Competitors",ic:"competitors"},
  {k:"feed",l:"Intel Feed",ic:"alert"},
  {k:"reports",l:"Reports",ic:"reports"},
  {k:"insights",l:"Insights",ic:"insights"},
  {k:"compare",l:"Event Compare",ic:"compare"},
  {k:"flow",l:"Event Flow",ic:"trend"},
  {k:"roi-calc",l:"ROI Calculator",ic:"calculator"},
  {k:"budget",l:"Budget Planner",ic:"budget"},
];

const pageTitle = p => ({dashboard:"Dashboard",story:"Account Story",events:"Events","ev-det":"Event Detail",accounts:"Accounts","acc-det":"Account Detail",opportunities:"Pipeline","opp-det":"Opportunity Detail",meetings:"Meetings","m-det":"Meeting Detail",competitors:"Competitor Intelligence",reports:"Reports",insights:"Strategic Insights",feed:"Intelligence Feed","roi-calc":"ROI Calculator",compare:"Event Comparison",flow:"Event Flow",budget:"Budget Planner",settings:"Settings"}[p]||"Cipher");

export default function App() {
  const [view, setView] = useState("landing");
  const [page, setPage] = useState("dashboard");
  const [detId, setDetId] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mtgModal, setMtgModal] = useState(false);
  const [noteModal, setNoteModal] = useState(null);
  const [shareModal, setShareModal] = useState(null);
  const [eventModal, setEventModal] = useState(false);
  const [compModal, setCompModal] = useState(false);
  const { show: toast, ToastContainer } = useToast();

  const nav = useCallback((p,id=null)=>{setPage(p);setDetId(id);window.scrollTo(0,0)},[]);
  const activeNav = page==="story"?"story":page.includes("ev")?"events":page.includes("acc")?"accounts":page.includes("opp")?"opportunities":page.includes("m-")?"meetings":page;

  useEffect(()=>{
    const handler = (e) => {
      if((e.metaKey||e.ctrlKey)&&e.key==="k"){e.preventDefault();setSearchOpen(true)}
      if(e.key==="Escape"){setSearchOpen(false)}
    };
    window.addEventListener("keydown",handler);
    return ()=>window.removeEventListener("keydown",handler);
  },[]);

  if(view==="landing") return <><style>{css}</style><Landing go={()=>setView("login")}/></>;
  if(view==="login") return <><style>{css}</style><Login go={()=>setView("app")}/></>;

  return (<><style>{css}</style>
    <div className="app">
      <aside className="side">
        <div className="side-brand"><h1>C<i>i</i>pher</h1><p>Event Intelligence</p></div>
        <nav className="side-nav">
          {NAV.slice(0,2).map(n=><div key={n.k} className={`side-item ${activeNav===n.k?"on":""}`} onClick={()=>nav(n.k)} style={n.featured?{background:activeNav===n.k?`rgba(204,107,133,.06)`:C.petal,fontWeight:600}:{}}>
            <span className="si"><Icon name={n.ic} size={16}/></span>{n.l}
            {n.featured&&activeNav!==n.k&&<span style={{marginLeft:"auto",fontSize:8,background:C.coral,color:"#fff",padding:"1px 6px",borderRadius:4,fontWeight:800}}>NEW</span>}
          </div>)}
          <div style={{height:1,background:C.borderLight,margin:"6px 10px 8px"}}/>
          {NAV.slice(2,8).map(n=><div key={n.k} className={`side-item ${activeNav===n.k?"on":""}`} onClick={()=>nav(n.k)}><span className="si"><Icon name={n.ic} size={16}/></span>{n.l}</div>)}
          <div style={{height:1,background:C.borderLight,margin:"6px 10px 8px"}}/>
          {NAV.slice(8).map(n=><div key={n.k} className={`side-item ${activeNav===n.k?"on":""}`} onClick={()=>nav(n.k)}><span className="si"><Icon name={n.ic} size={16}/></span>{n.l}</div>)}
          <div style={{flex:1}}/>
          <div className={`side-item ${activeNav==="settings"?"on":""}`} onClick={()=>nav("settings")}><span className="si"><Icon name="settings" size={16}/></span>Settings</div>
        </nav>
        <div className="side-foot"><div className="side-av">SC</div><div><div className="side-fn">Sarah Chen</div><div className="side-fr">VP Marketing</div></div></div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div className="topbar-t">{pageTitle(page)}</div>
          <div className="topbar-r">
            <div className="searchbox" onClick={()=>setSearchOpen(true)}><Icon name="search" size={14} color={C.warmGrayLight}/> Search… <span style={{marginLeft:"auto",fontSize:10,color:C.warmGrayLight,background:C.petal,padding:"2px 6px",borderRadius:4,fontWeight:700}}>⌘K</span></div>
            <button className="tbtn" onClick={()=>setMtgModal(true)} style={{display:"flex",alignItems:"center",gap:4}}><Icon name="meetings" size={13}/> Log Meeting</button>
            <button className="tbtn" onClick={()=>setView("landing")}><Icon name="globe" size={14}/></button>
            <button className="tbtn tbtn-p" onClick={()=>setEventModal(true)}>+ Add Event</button>
          </div>
        </header>
        {page==="dashboard"&&<Dashboard nav={nav} toast={toast} onMeeting={()=>setMtgModal(true)}/>}
        {page==="story"&&<AccountStoryPage nav={nav}/>}
        {page==="events"&&<EventsPage nav={nav}/>}
        {page==="ev-det"&&<EventDetail id={detId} nav={nav} toast={toast} onNote={n=>setNoteModal(n)} onMeeting={()=>setMtgModal(true)} onShare={t=>setShareModal(t)}/>}
        {page==="accounts"&&<AccountsPage nav={nav}/>}
        {page==="acc-det"&&<AccDetail id={detId} nav={nav} toast={toast} onNote={n=>setNoteModal(n)} onShare={t=>setShareModal(t)}/>}
        {page==="opportunities"&&<OppsPage nav={nav}/>}
        {page==="opp-det"&&<OppDetail id={detId} nav={nav} toast={toast} onNote={n=>setNoteModal(n)} onShare={t=>setShareModal(t)}/>}
        {page==="meetings"&&<MeetingsPage nav={nav}/>}
        {page==="m-det"&&<MeetingDetail id={detId} nav={nav} toast={toast} onNote={n=>setNoteModal(n)} onShare={t=>setShareModal(t)}/>}
        {page==="competitors"&&<CompPage toast={toast} onAdd={()=>setCompModal(true)}/>}
        {page==="reports"&&<ReportsPage toast={toast} onShare={t=>setShareModal(t)}/>}
        {page==="insights"&&<InsightsPage/>}
        {page==="feed"&&<FeedPage nav={nav}/>}
        {page==="roi-calc"&&<ROICalcPage/>}
        {page==="compare"&&<EventComparePage nav={nav}/>}
        {page==="journey"&&<AccountJourneyPage nav={nav}/>}
        {page==="flow"&&<FlowPage/>}
        {page==="budget"&&<BudgetPage/>}
        {page==="settings"&&<SettingsPage toast={toast}/>}
      </main>
    </div>

    {/* Global modals */}
    <SearchModal open={searchOpen} onClose={()=>setSearchOpen(false)} nav={(p,id)=>{nav(p,id);setSearchOpen(false)}}/>
    <LogMeetingModal open={mtgModal} onClose={()=>setMtgModal(false)} toast={toast}/>
    <AddNoteModal open={!!noteModal} onClose={()=>setNoteModal(null)} toast={toast} target={noteModal}/>
    <ShareModal open={!!shareModal} onClose={()=>setShareModal(null)} toast={toast} title={shareModal}/>
    <AddEventModal open={eventModal} onClose={()=>setEventModal(false)} toast={toast}/>
    <AddObservationModal open={compModal} onClose={()=>setCompModal(false)} toast={toast}/>
    <ToastContainer/>
  </>);
}
